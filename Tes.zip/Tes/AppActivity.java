/****************************************************************************
 Copyright (c) 2015-2016 Chukong Technologies Inc.
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
package org.cocos2dx.cpp;

import static java.security.AccessController.getContext;

import org.cocos2dx.lib.Cocos2dxHandler.DialogMessage;
import org.cocos2dx.lib.Cocos2dxHelper.Cocos2dxHelperListener;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Bundle;
import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxVideoView;

import android.net.Uri;
import android.os.FileUtils;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
//import android.support.annotation.NonNull;
import android.preference.PreferenceActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.FrameLayout;
import android.os.Handler;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
//import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
//import com.google.android.gms.ads.rewarded.RewardedAdCallback;
import com.google.android.gms.ads.AdError;

import android.os.Build;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

import androidx.annotation.NonNull;

import org.cocos2dx.lib.Cocos2dxActivity;

public class AppActivity extends Cocos2dxActivity {

    private static AdView top_banner_ads;
    private static AdView bottom_banner_ads;
    private static InterstitialAd ad_interstitial;

    FrameLayout.LayoutParams bottom_adParams;
    FrameLayout.LayoutParams top_adParams;

    private static Activity activity;
    private static final String TAG = Cocos2dxActivity.class.getSimpleName();
    private static Activity self = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        activity = this;

        super.setEnableVirtualButton(false);
        super.onCreate(savedInstanceState);
        // Workaround in https://stackoverflow.com/questions/16283079/re-launch-of-activity-on-home-button-but-only-the-first-time/16447508
        if (!isTaskRoot()) {
            // Android launched another instance of the root activity into an existing task
            //  so just quietly finish and go away, dropping the user back into the activity
            //  at the top of the stack (ie: the last state of this task)
            // Don't need to finish it again since it's finished in super.onCreate .
            return;
        }
        // Make sure we're running on Pie or higher to change cutout mode
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Enable rendering into the cutout area
            LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        //cek_Google_Mobile_Ads_SDK
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                activity.runOnUiThread(new Runnable() {
                    public void run() {
//                        Toast.makeText(getContext(),"IKBAL WAHYUDI",Toast.LENGTH_LONG).show();
                    }
                });
                //load_interAds();
            }
        });


        ///*
        //ads_code
        {
            //create_banner_bottom
            AdSize ukuran_banner = new AdSize(300, 50);
            bottom_banner_ads = new AdView(this);
            bottom_banner_ads.setAdSize(ukuran_banner);
            //adView.setAdSize(AdSize.SMART_BANNER);
            bottom_banner_ads.setAdUnitId("ca-app-pub-4624753443839313/4619559487");

            //load_banner
            AdRequest adRequestz = new AdRequest.Builder().build();
            bottom_banner_ads.loadAd(adRequestz);

            //desain_posisi_bannerBottom
            bottom_adParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);

            //addchill->banner
            activity.addContentView(bottom_banner_ads, bottom_adParams);


            //create_banner_top
            AdSize ukuran_banner2 = new AdSize(300, 50);
            top_banner_ads = new AdView(this);
            top_banner_ads.setAdSize(ukuran_banner2);
            //adView.setAdSize(AdSize.SMART_BANNER);
            top_banner_ads.setAdUnitId("ca-app-pub-4624753443839313/4619559487");

            //load_banner
            AdRequest adRequestz2 = new AdRequest.Builder().build();
            top_banner_ads.loadAd(adRequestz2);

            //desain_posisi_bannerTop
            top_adParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.CENTER_HORIZONTAL);

            //addchill->banner
            activity.addContentView(top_banner_ads, top_adParams);


            //iklan_tampil_otomatis_diawal_maka_harus_di_sembunyikan_dulu
            //hide_bannerAds();


        }

        //*/

    }

    ///*
    public static void show_ads_bannerBottom() {
        if (bottom_banner_ads != null) {

            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!bottom_banner_ads.isEnabled())
                        bottom_banner_ads.setEnabled(true);
                    if (bottom_banner_ads.getVisibility() == View.INVISIBLE)
                        bottom_banner_ads.setVisibility(View.VISIBLE);
                }
            });
        }

    }


    public static void show_ads_bannerTop() {

        if (top_banner_ads != null)
        {
            activity.runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    //AdRequest adRequestz2 = new AdRequest.Builder().build();
                    //top_banner_ads.loadAd(adRequestz2);

                    if (!top_banner_ads.isEnabled())
                        top_banner_ads.setEnabled(true);
                    if (top_banner_ads.getVisibility() == View.INVISIBLE )
                        top_banner_ads.setVisibility(View.VISIBLE);
                }
            });
        }

    }

    public static void hide_bannerAds() {

        //hide_banner_top
        if (top_banner_ads != null) {

            activity.runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    if (top_banner_ads.isEnabled())
                        top_banner_ads.setEnabled(false);
                    if (top_banner_ads.getVisibility() == View.VISIBLE )
                        top_banner_ads.setVisibility(View.INVISIBLE);
                }
            });
        };

        //hide_banner_bottom
        if (bottom_banner_ads != null) {
            activity.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    if (bottom_banner_ads.isEnabled())
                        bottom_banner_ads.setEnabled(false);
                    if (bottom_banner_ads.getVisibility() == View.VISIBLE)
                        bottom_banner_ads.setVisibility(View.INVISIBLE);
                }
            });
        };

    }

    private static void show_interAds()
    {
        activity.runOnUiThread(new Runnable()
        {
            public void run() {
                if(ad_interstitial != null)
                {
                    ad_interstitial.show(activity);

                }
                else
                {
                    Toast.makeText(getContext(),"iklan inter belum dimuat",Toast.LENGTH_LONG).show();
                    load_interAds();
                }
            }
        });


    }

    public static void load_interAds()
    {
        //cretae_ad_inter
        AdRequest adRequest = new AdRequest.Builder().build();
        ad_interstitial.load(getContext(),
                "ca-app-pub-4624753443839313/2402505979",
                adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd interstitialAd) {

                        ad_interstitial = interstitialAd;

                        ad_interstitial.setFullScreenContentCallback(new FullScreenContentCallback(){
                            @Override
                            public void onAdClicked() {
                                // Called when a click is recorded for an ad.
                                Log.d(TAG, "Ad was clicked.");
                                activity.runOnUiThread(new Runnable()
                                {
                                    public void run() {
                                        Toast.makeText(getContext(),"iklan di click",Toast.LENGTH_LONG).show();
                                    }
                                });
                            }

                            @Override
                            public void onAdDismissedFullScreenContent() {
                                // Called when ad is dismissed.
                                // Set the ad reference to null so you don't show the ad a second time.
                                Log.d(TAG, "Ad dismissed fullscreen content.");
                                ad_interstitial = null;
                                activity.runOnUiThread(new Runnable()
                                {
                                    public void run() {
                                        Toast.makeText(getContext(),"Ad dismissed fullscreen content.",Toast.LENGTH_LONG).show();
                                    }
                                });
                                load_interAds();
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                // Called when ad fails to show.
                                Log.e(TAG, "Ad failed to show fullscreen content.");
                                ad_interstitial = null;
                                activity.runOnUiThread(new Runnable()
                                {
                                    public void run() {
                                        Toast.makeText(getContext(),"Ad failed to show fullscreen content.",Toast.LENGTH_LONG).show();
                                    }
                                });
                            }

                            @Override
                            public void onAdImpression() {
                                // Called when an impression is recorded for an ad.
                                Log.d(TAG, "Ad recorded an impression.");
                                activity.runOnUiThread(new Runnable()
                                {
                                    public void run() {
                                        Toast.makeText(getContext(),"Ad recorded an impression.",Toast.LENGTH_LONG).show();
                                    }
                                });
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                // Called when ad is shown.
                                Log.d(TAG, "Ad showed fullscreen content.");
                                activity.runOnUiThread(new Runnable()
                                {
                                    public void run() {
                                        Toast.makeText(getContext(),"Ad showed fullscreen content.",Toast.LENGTH_LONG).show();
                                    }
                                });
                            }

                        });

                        //show_interAds();
                        // Metode onAdLoaded() dijalankan saat iklan selesai dimuat.
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getContext(),"iklan inter berhasil di muat",Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                        // ketika iklan gagal di muat
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getContext(),"iklan GAGAL di muat",Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                });

    }

    //*/

}
