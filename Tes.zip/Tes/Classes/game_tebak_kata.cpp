/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "game_tebak_kata.h"
#include "menu_pilih.h"
#include "coba_2.h"
#include "ActionShake.h"
#include "cocos/platform/CCDevice.h"
#include "SimpleAudioEngine.h"
#include "pilihan_bermain.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* game_tebak_kata::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = game_tebak_kata::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

void game_tebak_kata::random(int x)
{
    if(x == 2)
    {
        get_rand_hewan[2] = RandomHelper::random_int(0, 25);

        if (get_rand_hewan[0] == get_rand_hewan[1])
        {
            get_rand_hewan[1] = RandomHelper::random_int(0, 25);
            log("ada nilai yang sama");
            random(2);
        };
    }
    if(x == 3)
    {
        get_rand_hewan[3] = RandomHelper::random_int(0, 25);

        if (get_rand_hewan[0] == get_rand_hewan[1])
        {
            get_rand_hewan[1] = RandomHelper::random_int(0, 25);
            log("ada nilai yang sama");
            random(3);
        };
        if (get_rand_hewan[1] == get_rand_hewan[2])
        {
            get_rand_hewan[2] = RandomHelper::random_int(0, 25);
            log("nilai kedua ada yang sama");
            random(3);
        };
        if (get_rand_hewan[0] == get_rand_hewan[2])
        {
            get_rand_hewan[2] = RandomHelper::random_int(0, 25);
            log("ada nilai ketiga yang sama");
            random(3);
        }
    }

}
const std::string indo[] =
        {
                "Anjing",
                "Babi",
                "Belalang",
                "Burung Hupu",
                "Domba",
                "Gagak",
                "Gajah",
                "Ikan",
                "Kambing",
                "Katak",
                "Keledai",
                "Kera",
                "Kuda",
                "Kutu",
                "Laba-laba",
                "Lalat",
                "Lebah",
                "Nyamuk",
                "Puyuh",
                "Rayap",
                "Sapi",
                "Semut",
                "Serigala",
                "Singa",
                "Ular",
                "Unta"
        };
const std::string inggris[] =
        {
                "Dog",
                "Pig",
                "Grasshopper",
                "Hupu",
                "Sheep",
                "Crow",
                "Elephant",
                "Fish",
                "Goat",
                "Frog",
                "Donkey",
                "Monkey",
                "Horse",
                "Louse",
                "Spider",
                "Fly",
                "Bee",
                "Musquito",
                "Quail",
                "Termite",
                "Cow",
                "Ant",
                "Wolf",
                "Lion",
                "Snake",
                "Camel"
        };
const std::string name_hewan[] =
        {
                "hewan/anjeng",
                "hewan/babi",
                "hewan/belalang",
                "hewan/burung",
                "hewan/domba",
                "hewan/gagak",
                "hewan/gajah",
                "hewan/ikan",
                "hewan/kambing",
                "hewan/katak",
                "hewan/keledai",
                "hewan/kera",
                "hewan/kuda",
                "hewan/kutu",
                "hewan/laba_laba",
                "hewan/lalat",
                "hewan/lebah",
                "hewan/nyamuk",
                "hewan/puyuh",
                "hewan/rayap",
                "hewan/sapi",
                "hewan/semut",
                "hewan/serigala",
                "hewan/singa",
                "hewan/ular",
                "hewan/unta"
        };

const std::string suara_hewan[] =
{
        "sound/hewan_indonesia/anjing",
        "sound/hewan_indonesia/babi",
        "sound/hewan_indonesia/belalang",
        "sound/hewan_indonesia/burung hupu",
        "sound/hewan_indonesia/domba",
        "sound/hewan_indonesia/gagak",
        "sound/hewan_indonesia/gajah",
        "sound/hewan_indonesia/ikan",
        "sound/hewan_indonesia/kambing",
        "sound/hewan_indonesia/katak",
        "sound/hewan_indonesia/keledai",
        "sound/hewan_indonesia/kera",
        "sound/hewan_indonesia/kuda",
        "sound/hewan_indonesia/kutu",
        "sound/hewan_indonesia/labalaba",
        "sound/hewan_indonesia/lalat",
        "sound/hewan_indonesia/lebah",
        "sound/hewan_indonesia/nyamuk",
        "sound/hewan_indonesia/puyuh",
        "sound/hewan_indonesia/rayap",
        "sound/hewan_indonesia/sapi",
        "sound/hewan_indonesia/semut",
        "sound/hewan_indonesia/serigala",
        "sound/hewan_indonesia/singa",
        "sound/hewan_indonesia/ular",
        "sound/hewan_indonesia/unta"
};

const std::string arab[] =
        {
                "teks_arab/anjing",
                "teks_arab/babi",
                "teks_arab/belalang",
                "teks_arab/burung_hupu",
                "teks_arab/domba",
                "teks_arab/gagak",
                "teks_arab/gajah",
                "teks_arab/ikan",
                "teks_arab/kambing",
                "teks_arab/katak",
                "teks_arab/keledai",
                "teks_arab/kera",
                "teks_arab/kuda",
                "teks_arab/kutu",
                "teks_arab/laba",
                "teks_arab/lalat",
                "teks_arab/lebah",
                "teks_arab/nyamuk",
                "teks_arab/puyuh",
                "teks_arab/rayap",
                "teks_arab/sapi",
                "teks_arab/semut",
                "teks_arab/serigala",
                "teks_arab/singa",
                "teks_arab/ular",
                "teks_arab/unta"
        };

bool game_tebak_kata::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("bermain/tebak_kata/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel_besar = Sprite::create("bermain/tebak_kata/Pannel_besar.png");
    panel_besar->setScale(1.4);
    panel_besar->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y + 100));
    this->addChild(panel_besar);

    waktu = Sprite::create("bermain/pasang_suara/Pannel_waktu.png");
    waktu->setAnchorPoint(Point(0.5, 1));
    waktu->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height + origin.y - 20));
    this->addChild(waktu);

    poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
    poin->setAnchorPoint(Point(0.5, 1));
    poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 20));
    this->addChild(poin);

    l_waktu = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    l_waktu->setString(__String::createWithFormat("%i", i_waktu)->getCString());
    l_waktu->setPosition(Vec2(waktu->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
    l_waktu->setTextColor(Color4B::BLACK);
    waktu->addChild(l_waktu);

    l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
    l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
    l_poin->setTextColor(Color4B::BLACK);
    poin->addChild(l_poin);

    b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk main tbk kt.mp3");


    this->runAction(Sequence::create(DelayTime::create(2), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_indo, this, 2)), nullptr));

    this->runAction(Sequence::create(DelayTime::create(2), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::untuk_manggil, this)), nullptr));

    return true;
}
void game_tebak_kata::untuk_manggil() {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    this->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_waktu, this)), nullptr)));
}
void game_tebak_kata::fungsi_waktu()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 1; i++)
    {
        if (i_waktu == 0)
        {
            gambar_kedua[0]->setScale(0);
            gambar_kedua[1]->setScale(0);
            gambar_kedua[2]->setScale(0);
            gambar_pertama->setScale(0);
            break;
        }
        i_waktu--;
        l_waktu->setString(__String::createWithFormat("%i", i_waktu)->getCString());

        if (i_waktu == 0)
        {
            /*fungsi_menang();*/
            game_selesai();
        }
    }
}
void game_tebak_kata::manggil()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    otomatis_aktif == true;
    if(i_poin <= 6)
    {
        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_indo, this, 2)), nullptr));
        log("1");
    }
    if(i_poin >= 7 && i_poin <= 12)
    {
        this->removeChild(l_poin);

        poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
        poin->setAnchorPoint(Point(0.5, 1));
        poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 20));
        this->addChild(poin);
        l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
        l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
        l_poin->setTextColor(Color4B::BLACK);
        poin->addChild(l_poin);
        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_inggris, this, 2)), nullptr));
        log("2");
    }
    if(i_poin >= 13 && i_poin <= 17)
    {
        this->removeChild(l_poin);

        poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
        poin->setAnchorPoint(Point(0.5, 1));
        poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 20));
        this->addChild(poin);
        l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
        l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
        l_poin->setTextColor(Color4B::BLACK);
        poin->addChild(l_poin);
        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_arab, this, 2)), nullptr));
        log("3");
    }
    if(i_poin >= 18 && i_poin <= 22)
    {
        this->removeChild(l_poin);

        poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
        poin->setAnchorPoint(Point(0.5, 1));
        poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 20));
        this->addChild(poin);
        l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
        l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
        l_poin->setTextColor(Color4B::BLACK);
        poin->addChild(l_poin);
        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_indo, this, 3)), nullptr));
        log("4");
    }
    if(i_poin >= 23 && i_poin <= 27)
    {
        this->removeChild(l_poin);

        poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
        poin->setAnchorPoint(Point(0.5, 1));
        poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 20));
        this->addChild(poin);
        l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
        l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
        l_poin->setTextColor(Color4B::BLACK);
        poin->addChild(l_poin);
        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_inggris, this, 3)), nullptr));
        log("5");
    }
    if(i_poin >= 28)
    {
        this->removeChild(l_poin);
        poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
        poin->setAnchorPoint(Point(0.5, 1));
        poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 20));
        this->addChild(poin);
        l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
        l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
        l_poin->setTextColor(Color4B::BLACK);
        poin->addChild(l_poin);
        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::muncul_arab, this, 3)), nullptr));
        log("6");
    }

}
void game_tebak_kata::fungsi_khusus()
{
    otomatis_aktif = false;
}
void game_tebak_kata::muncul_indo(int x) {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    if (x == 2) {

        for (int i = 0; i < 2; ++i) {
            panel_kecil_2[i] = Sprite::create("bermain/tebak_kata/Pannel_kecil.png");
            this->addChild(panel_kecil_2[i]);
            panel_kecil_2[i]->setScale(1.2);
        }
        panel_kecil_2[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350,visibleSize.height / 2 + origin.y - 250));
        panel_kecil_2[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350,visibleSize.height / 2 + origin.y - 250));

        this->runAction(Sequence::create(DelayTime::create(0.9), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_khusus, this)), nullptr));

        for (int i = 0; i < 2; ++i) {



            get_rand_hewan[i] = RandomHelper::random_int(0, 25);

            if (get_rand_hewan[0] == get_rand_hewan[1]) {
                get_rand_hewan[1] = RandomHelper::random_int(0, 25);
                log("ada nilai yang sama");
                random(2);
            };

            hewan_yang_benar = RandomHelper::random_int(0, 1);

            

            panel_bantuan[i] = Button::create("bermain/tebak_kata/Pannel_kecil.png");
            panel_bantuan[i]->setOpacity(0);
            panel_bantuan[i]->setAnchorPoint(Point(0.5, 0.5));
            panel_bantuan[i]->setPosition(Vec2(panel_kecil_2[i]->getContentSize() / 2));
            panel_bantuan[i]->setScale(0);
            panel_bantuan[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.7)));
            panel_kecil_2[i]->addChild(panel_bantuan[i]);
            panel_bantuan[i]->setZoomScale(-0.1);
            panel_bantuan[i]->addClickEventListener([=](Ref *Sender) {
                if (otomatis_aktif == false) {
                    if (i == hewan_yang_benar) {
                        otomatis_aktif = true;
                        berhasil++;
                        i_poin++;
                        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
                        if (berhasil == 1) {
                            jika_benar(0);
                            panel_bantuan[0]->setScale(0);
                            panel_bantuan[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 2) {
                            jika_benar(1);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 3) {
                            jika_benar(2);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 4) {
                            jika_benar(3);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 5) {
                            jika_benar(0);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 6) {
                            jika_benar(1);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 7) {
                            jika_benar(2);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 8) {
                            jika_benar(3);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 9) {
                            jika_benar(0);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 10) {
                            jika_benar(1);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 11) {
                            jika_benar(2);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 12) {
                            jika_benar(3);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 13) {
                            jika_benar(0);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 14) {
                            jika_benar(1);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 15) {
                            jika_benar(2);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }





                    } else {
                        otomatis_aktif = true;
                        jika_benar(4);
                        nama_indo[0]->setScale(0);
                        nama_indo[1]->setScale(0);
                        gambar_pertama->setScale(0);
                        manggil();
                    }
                }
            });

            nama_indo[i] = Label::createWithTTF("Burung Hupu", "belajar/mengenal/Freude.otf", 55);
            nama_indo[i]->setString(
                    __String::create(indo[get_rand_hewan[i]].c_str())->getCString());
            nama_indo[i]->setPosition(Vec2(panel_bantuan[i]->getContentSize() / 2));
            nama_indo[i]->setTextColor(Color4B::BLACK);
            panel_bantuan[i]->addChild(nama_indo[i]);


        }
        gambar_pertama = Sprite::create(__String::createWithFormat("%s.png",name_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
        gambar_pertama->setPosition(Vec2(panel_besar->getContentSize() / 2));
        gambar_pertama->setScale(0);
        gambar_pertama->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
        panel_besar->addChild(gambar_pertama);

         
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3",suara_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
    }
    if (x == 3) {
//        this->removeChild(panel_kecil_2[0]);
//        this->removeChild(panel_kecil_2[1]);
//        this->removeChild(panel_bantuan[0]);
//        this->removeChild(panel_bantuan[1]);



        for (int i = 0; i < 3; ++i) {
            panel_kecil_3[i] = Sprite::create("bermain/tebak_kata/Pannel_kecil.png");
            this->addChild(panel_kecil_3[i]);
            panel_kecil_3[i]->setScale(1.2);
        }
        panel_kecil_3[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350,visibleSize.height / 2 + origin.y - 250));
        panel_kecil_3[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y - 250));
        panel_kecil_3[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350,visibleSize.height / 2 + origin.y - 250));

        for (int i = 0; i < 3; ++i) {

            get_rand_hewan[i] = RandomHelper::random_int(0, 25);

            if (get_rand_hewan[0] == get_rand_hewan[1]) {
                 get_rand_hewan[1] = RandomHelper::random_int(0, 25);
                log("ada nilai yang sama");
                random(3);
            };
            if (get_rand_hewan[1] == get_rand_hewan[2]) {
                get_rand_hewan[2] = RandomHelper::random_int(0, 25);
                log("nilai kedua ada yang sama");
                random(3);
            };
            if (get_rand_hewan[0] == get_rand_hewan[2]) {
                get_rand_hewan[2] = RandomHelper::random_int(0, 25);
                log("ada nilai ketiga yang sama");
                random(3);
            }

            hewan_yang_benar = RandomHelper::random_int(0, 2);

            this->runAction(Sequence::create(DelayTime::create(0.9), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_khusus, this)), nullptr));

            gambar_kedua[i] = Button::create(__String::createWithFormat("%s.png",arab[get_rand_hewan[i]].c_str())->getCString());
            gambar_kedua[i]->setAnchorPoint(Point(0.5, 0.5));
            gambar_kedua[i]->setOpacity(0);
            gambar_kedua[i]->setPosition(Vec2(panel_kecil_3[i]->getContentSize() / 2));
            gambar_kedua[i]->setScale(0);
            gambar_kedua[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
            panel_kecil_3[i]->addChild(gambar_kedua[i]);
            gambar_kedua[i]->setZoomScale(-0.1);
            gambar_kedua[i]->addClickEventListener([=](Ref *Sender) {
                if (otomatis_aktif == false) {
                    if (i == hewan_yang_benar) {
                        otomatis_aktif = true;
                        berhasil++;
                        i_poin++;
                        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
                        if (berhasil == 19) {
                            jika_benar(0);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 20) {
                            jika_benar(1);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 21) {
                            jika_benar(2);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();

                        }
                        if (berhasil == 22) {
                            jika_benar(3);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 23) {
                            jika_benar(0);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }

                    } else {
                        otomatis_aktif = true;
                        jika_benar(4);
                        gambar_kedua[0]->setScale(0);
                        gambar_kedua[1]->setScale(0);
                        gambar_kedua[2]->setScale(0);
                        gambar_pertama->setScale(0);
                        manggil();
                    }
                }
            });
            nama_indo_3[i] = Label::createWithTTF("Burung hupu", "belajar/mengenal/Freude.otf", 140);
            nama_indo_3[i]->setString(__String::create(indo[get_rand_hewan[i]].c_str())->getCString());
            nama_indo_3[i]->setPosition(Vec2(gambar_kedua[i]->getContentSize() / 2));
            nama_indo_3[i]->setTextColor(Color4B::BLACK);
            gambar_kedua[i]->addChild(nama_indo_3[i]);
        }


        gambar_pertama = Sprite::create(__String::createWithFormat("%s.png",name_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
        gambar_pertama->setPosition(Vec2(panel_besar->getContentSize() / 2));
        gambar_pertama->setScale(0);
        gambar_pertama->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
        panel_besar->addChild(gambar_pertama);

        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3",suara_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
    }


}
void game_tebak_kata::muncul_inggris(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if(x == 2)
    {
        for (int i = 0; i < 2; ++i) {
            panel_kecil_2[i] = Sprite::create("bermain/tebak_kata/Pannel_kecil.png");
            this->addChild(panel_kecil_2[i]);
            panel_kecil_2[i]->setScale(1.2);
        }
        panel_kecil_2[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350,visibleSize.height / 2 + origin.y - 250));
        panel_kecil_2[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350,visibleSize.height / 2 + origin.y - 250));

        for (int i = 0; i < 2; ++i) {

            get_rand_hewan[i] = RandomHelper::random_int(0, 25);

            if (get_rand_hewan[0] == get_rand_hewan[1]) {
                get_rand_hewan[1] = RandomHelper::random_int(0, 25);
                log("ada nilai yang sama");
                random(2);
            };

            hewan_yang_benar = RandomHelper::random_int(0, 1);

            this->runAction(Sequence::create(DelayTime::create(0.9), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_khusus, this)), nullptr));

            panel_bantuan[i] = Button::create("bermain/tebak_kata/Pannel_kecil.png");
            panel_bantuan[i]->setOpacity(0);
            panel_bantuan[i]->setAnchorPoint(Point(0.5, 0.5));
            panel_bantuan[i]->setPosition(Vec2(panel_kecil_2[i]->getContentSize() / 2));
            panel_bantuan[i]->setScale(0);
            panel_bantuan[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.7)));
            panel_kecil_2[i]->addChild(panel_bantuan[i]);
            panel_bantuan[i]->setZoomScale(-0.1);
            panel_bantuan[i]->addClickEventListener([=](Ref *Sender) {
                if (otomatis_aktif == false) {
                    if (i == hewan_yang_benar) {
                        otomatis_aktif = true;
                        berhasil++;
                        i_poin++;
                        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
                        if (berhasil == 8) {
                            jika_benar(0);
                            panel_bantuan[0]->setScale(0);
                            panel_bantuan[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 9) {
                            jika_benar(1);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 10) {
                            jika_benar(2);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 11) {
                            jika_benar(3);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 12) {
                            jika_benar(0);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 13) {
                            jika_benar(1);
                            nama_indo[0]->setScale(0);
                            nama_indo[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }

                    } else {
                        otomatis_aktif = true;
                        jika_benar(4);
                        nama_indo[0]->setScale(0);
                        nama_indo[1]->setScale(0);
                        gambar_pertama->setScale(0);
                        manggil();
                    }
                }
            });

            nama_indo[i] = Label::createWithTTF("Grasshoper", "belajar/mengenal/Freude.otf", 60);
            nama_indo[i]->setString(__String::create(inggris[get_rand_hewan[i]].c_str())->getCString());
            nama_indo[i]->setPosition(Vec2(panel_bantuan[i]->getContentSize() / 2));
            nama_indo[i]->setTextColor(Color4B::BLACK);
            panel_bantuan[i]->addChild(nama_indo[i]);


        }
        gambar_pertama = Sprite::create(__String::createWithFormat("%s.png",name_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
        gambar_pertama->setPosition(Vec2(panel_besar->getContentSize() / 2));
        gambar_pertama->setScale(0);
        gambar_pertama->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
        panel_besar->addChild(gambar_pertama);


        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3",suara_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
    }
    if (x == 3) {
        //        this->removeChild(panel_kecil_2[0]);
        //        this->removeChild(panel_kecil_2[1]);
        //        this->removeChild(panel_bantuan[0]);
        //        this->removeChild(panel_bantuan[1]);



        for (int i = 0; i < 3; ++i) {
            panel_kecil_3[i] = Sprite::create("bermain/tebak_kata/Pannel_kecil.png");
            this->addChild(panel_kecil_3[i]);
            panel_kecil_3[i]->setScale(1.2);
        }
        panel_kecil_3[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 250));
        panel_kecil_3[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y - 250));
        panel_kecil_3[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250));

        for (int i = 0; i < 3; ++i) {

            get_rand_hewan[i] = RandomHelper::random_int(0, 25);

            if (get_rand_hewan[0] == get_rand_hewan[1]) {
                get_rand_hewan[1] = RandomHelper::random_int(0, 25);
                log("ada nilai yang sama");
                random(3);
            };
            if (get_rand_hewan[1] == get_rand_hewan[2]) {
                get_rand_hewan[2] = RandomHelper::random_int(0, 25);
                log("nilai kedua ada yang sama");
                random(3);
            };
            if (get_rand_hewan[0] == get_rand_hewan[2]) {
                get_rand_hewan[2] = RandomHelper::random_int(0, 25);
                log("ada nilai ketiga yang sama");
                random(3);
            }

            hewan_yang_benar = RandomHelper::random_int(0, 2);
            this->runAction(Sequence::create(DelayTime::create(0.9), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_khusus, this)), nullptr));
            gambar_kedua[i] = Button::create(__String::createWithFormat("%s.png", arab[get_rand_hewan[i]].c_str())->getCString());
            gambar_kedua[i]->setAnchorPoint(Point(0.5, 0.5));
            gambar_kedua[i]->setOpacity(0);
            gambar_kedua[i]->setPosition(Vec2(panel_kecil_3[i]->getContentSize() / 2));
            gambar_kedua[i]->setScale(0);
            gambar_kedua[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
            panel_kecil_3[i]->addChild(gambar_kedua[i]);
            gambar_kedua[i]->setZoomScale(-0.1);
            gambar_kedua[i]->addClickEventListener([=](Ref* Sender) {
                if (otomatis_aktif == false) {
                    if (i == hewan_yang_benar) {
                        otomatis_aktif = true;
                        berhasil++;
                        i_poin++;
                        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
                        if (berhasil == 24) {
                            jika_benar(0);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 25) {
                            jika_benar(1);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 26) {
                            jika_benar(2);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();

                        }
                        if (berhasil == 27) {
                            jika_benar(3);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 28) {
                            jika_benar(0);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }

                    }
                    else {
                        otomatis_aktif = true;
                        jika_benar(4);
                        gambar_kedua[0]->setScale(0);
                        gambar_kedua[1]->setScale(0);
                        gambar_kedua[2]->setScale(0);
                        gambar_pertama->setScale(0);
                        manggil();
                    }
                }
                });
            nama_indo_3[i] = Label::createWithTTF("60", "belajar/mengenal/Freude.otf", 140);
            nama_indo_3[i]->setString(__String::create(inggris[get_rand_hewan[i]].c_str())->getCString());
            nama_indo_3[i]->setPosition(Vec2(gambar_kedua[i]->getContentSize() / 2));
            nama_indo_3[i]->setTextColor(Color4B::BLACK);
            gambar_kedua[i]->addChild(nama_indo_3[i]);
        }


        gambar_pertama = Sprite::create(__String::createWithFormat("%s.png", name_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
        gambar_pertama->setPosition(Vec2(panel_besar->getContentSize() / 2));
        gambar_pertama->setScale(0);
        gambar_pertama->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
        panel_besar->addChild(gambar_pertama);

        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
    }
}
void game_tebak_kata::muncul_arab(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();


    if(x == 2)
    {
        this->runAction(Sequence::create(DelayTime::create(0.9), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_khusus, this)), nullptr));

        for (int i = 0; i < 2; ++i) {
            panel_kecil_2[i] = Sprite::create("bermain/tebak_kata/Pannel_kecil.png");
            this->addChild(panel_kecil_2[i]);
            panel_kecil_2[i]->setScale(1.2);
        }
        panel_kecil_2[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350,visibleSize.height / 2 + origin.y - 250));
        panel_kecil_2[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350,visibleSize.height / 2 + origin.y - 250));

        for (int i = 0; i < 2; ++i) {

            get_rand_hewan[i] = RandomHelper::random_int(0, 25);

            if (get_rand_hewan[0] == get_rand_hewan[1])
            {
                get_rand_hewan[1] = RandomHelper::random_int(0, 25);
                log("ada nilai yang sama");
                random(2);
            };

            hewan_yang_benar = RandomHelper::random_int(0, 1);

            
            gambar_baru[i] = Button::create(__String::createWithFormat("%s.png", arab[get_rand_hewan[i]].c_str())->getCString());
            gambar_baru[i]->setAnchorPoint(Point(0.5, 0.5));
            gambar_baru[i]->setPosition(Vec2(panel_kecil_2[i]->getContentSize() / 2));
            gambar_baru[i]->setScale(0);
            gambar_baru[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.15)));
            panel_kecil_2[i]->addChild(gambar_baru[i]);
            gambar_baru[i]->setZoomScale(-0.1);
            gambar_baru[i]->addClickEventListener([=](Ref* Sender){
                if(otomatis_aktif == false)
                {
                    if(i == hewan_yang_benar){
                        otomatis_aktif = true;
                        berhasil++;
                        i_poin++;
                        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
                        if(berhasil == 14)
                        {
                            jika_benar(0);
                            gambar_baru[0]->setScale(0);
                            gambar_baru[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 15)
                        {
                            jika_benar(1);
                            gambar_baru[0]->setScale(0);
                            gambar_baru[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 16)
                        {
                            jika_benar(2);
                            gambar_baru[0]->setScale(0);
                            gambar_baru[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 17)
                        {
                            jika_benar(3);
                            gambar_baru[0]->setScale(0);
                            gambar_baru[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 18)
                        {
                            jika_benar(0);
                            gambar_baru[0]->setScale(0);
                            gambar_baru[1]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                    }
                    else
                    {
                        otomatis_aktif = true;
                        jika_benar(4);
                        gambar_baru[0]->setScale(0);
                        gambar_baru[1]->setScale(0);
                        gambar_pertama->setScale(0);
                        manggil();
                    }
                }
            });
        }



        gambar_pertama = Sprite::create(__String::createWithFormat("%s.png", name_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
        gambar_pertama->setPosition(Vec2( panel_besar->getContentSize() / 2));
        gambar_pertama->setScale(0);
        gambar_pertama->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
        panel_besar->addChild(gambar_pertama);

        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());

    }

    if(x == 3)
    {
        for (int i = 0; i < 3; ++i) {

            this->runAction(Sequence::create(DelayTime::create(0.9), CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_khusus, this)), nullptr));

            get_rand_hewan[i] = RandomHelper::random_int(0, 25);

            if (get_rand_hewan[0] == get_rand_hewan[1])
            {
                get_rand_hewan[1] = RandomHelper::random_int(0, 25);
                log("ada nilai yang sama");
                random(3);
            };
            if (get_rand_hewan[1] == get_rand_hewan[2])
            {
                get_rand_hewan[2] = RandomHelper::random_int(0, 25);
                log("nilai kedua ada yang sama");
                random(3);
            };
            if (get_rand_hewan[0] == get_rand_hewan[2])
            {
                get_rand_hewan[2] = RandomHelper::random_int(0, 25);
                log("ada nilai ketiga yang sama");
                random(3);
            }

            hewan_yang_benar = RandomHelper::random_int(0, 2);


            gambar_kedua[i] = Button::create(__String::createWithFormat("%s.png", arab[get_rand_hewan[i]].c_str())->getCString());
            gambar_kedua[i]->setAnchorPoint(Point(0.5, 0.5));
            gambar_kedua[i]->setPosition(Vec2(panel_kecil_3[i]->getContentSize() / 2));
            gambar_kedua[i]->setScale(0);
            gambar_kedua[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.15)));
            panel_kecil_3[i]->addChild(gambar_kedua[i]);
            gambar_kedua[i]->setZoomScale(-0.1);
            gambar_kedua[i]->addClickEventListener([=](Ref* Sender){
                if(otomatis_aktif == false)
                {
                    if(i == hewan_yang_benar){
                        otomatis_aktif = true;
                        berhasil++;
                        i_poin++;
                        l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
                        if(berhasil == 29)
                        {
                            jika_benar(0);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 30)
                        {
                            jika_benar(1);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 31)
                        {
                            jika_benar(2);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 32)
                        {
                            jika_benar(3);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 33)
                        {
                            jika_benar(0);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 34)
                        {
                            jika_benar(1);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if(berhasil == 35)
                        {
                            jika_benar(2);
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            manggil();
                        }
                        if (berhasil == 36)
                        {   
                            gambar_kedua[0]->setScale(0);
                            gambar_kedua[1]->setScale(0);
                            gambar_kedua[2]->setScale(0);
                            gambar_pertama->setScale(0);
                            this->stopAllActions();
                            game_selesai();
                        }
                        

                    }
                    else
                    {
                        otomatis_aktif = true;
                        jika_benar(4);
                        gambar_kedua[0]->setScale(0);
                        gambar_kedua[1]->setScale(0);
                        gambar_kedua[2]->setScale(0);
                        gambar_pertama->setScale(0);
                        manggil();
                    }
                }
            });
        }



        gambar_pertama = Sprite::create(__String::createWithFormat("%s.png", name_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
        gambar_pertama->setPosition(Vec2( panel_besar->getContentSize() / 2));
        gambar_pertama->setScale(0);
        gambar_pertama->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.25)));
        panel_besar->addChild(gambar_pertama);

        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_rand_hewan[hewan_yang_benar]].c_str())->getCString());
    }



}
void game_tebak_kata::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba_2::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}

void game_tebak_kata::jika_benar(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        bagus = Sprite::create("ekspresi/bagus.png");
        bagus->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        bagus->setScale(0);
        bagus->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                                          EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
        this->addChild(bagus, 100);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/bagus.mp3");

    }
    if (x == 1)
    {
        pintar = Sprite::create("ekspresi/pintar.png");
        pintar->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        pintar->setScale(0);
        pintar->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                                           EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
        this->addChild(pintar, 100);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pintar.mp3");

    }
    if (x == 2)
    {
        pandai = Sprite::create("ekspresi/Pandai.png");
        pandai->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        pandai->setScale(0);
        pandai->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                                           EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
        this->addChild(pandai, 100);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pndai.mp3");

    }
    if (x == 3)
    {
        berhsil = Sprite::create("ekspresi/berhasil.png");
        berhsil->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        berhsil->setScale(0);
        berhsil->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                                            EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
        this->addChild(berhsil, 100);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/berhasil.mp3");

    }
    if (x == 4)
    {
        salah = Sprite::create("ekspresi/yahh.png");
        salah->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        salah->setScale(0);
        salah->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                                          EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
        this->addChild(salah, 100);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yaaah.mp3");

    }
}
void game_tebak_kata::game_selesai()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    otomatis_aktif = true;

    resolusi = Sprite::create("final_resolusi/p.png");
    resolusi->setScale(0.8);
    resolusi->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(resolusi);

    auto poin = Label::create("", "belajar/mengenal/Freude.otf", 70);
    poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
    poin->setPosition(Vec2(resolusi->getContentSize().width / 2 + 100, resolusi->getContentSize().height / 2 - 245));
    poin->setTextColor(Color4B::WHITE);
    resolusi->addChild(poin);

    bintang_1 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_1);

    bintang_2 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_2->setPosition(Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_2);

    bintang_3 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_3);

    bintang_kuning_1 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_1->setScale(0);
    bintang_kuning_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_1);

    bintang_kuning_2 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_2->setScale(0);
    bintang_kuning_2->setPosition(Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_kuning_2);

    bintang_kuning_3 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_3->setScale(0);
    bintang_kuning_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_3);

    auto b_menu = Button::create("final_resolusi/b_menu.png");
    b_menu->setAnchorPoint(Point(0.5, 0.5));
    b_menu->setPosition(Vec2(resolusi->getContentSize().width / 2 + 270, resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_menu);
    b_menu->setZoomScale(-0.1);
    b_menu->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto b_restart = Button::create("final_resolusi/b_restart.png");
    b_restart->setAnchorPoint(Point(0.5, 0.5));
    b_restart->setPosition(Vec2(resolusi->getContentSize().width / 2 - 270, resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_restart);
    b_restart->setZoomScale(-0.1);
    b_restart->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = game_tebak_kata::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });





    if (i_poin == 0)
    {

    }
    else if (i_poin <= 5)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
                                         CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_bintang, this, 0)), nullptr));
    }
    else if (i_poin >= 10 && i_poin <= 19)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
                                         CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_bintang, this, 0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
                                         CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_bintang, this, 1)), nullptr));
    }
    else if (i_poin >= 20)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
                                         CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_bintang, this, 0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
                                         CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_bintang, this, 1)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.8),
                                         CallFunc::create(CC_CALLBACK_0(game_tebak_kata::fungsi_bintang, this, 2)), nullptr));
    }
}

void game_tebak_kata::getar()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    cocos2d::Device::vibrate(0.5f);

    float interval = 1 / 60;
    float duration = 0.5f;
    float speed = 5.0f;
    float magnitude = 5.f;

    this->runAction(ActionShake::create(duration, speed, magnitude));
}
void game_tebak_kata::fungsi_bintang(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        bintang_kuning_1->setScale(0);
        bintang_kuning_1->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_1 = ParticleSystemQuad::create("bintang_particle.plist");
        s_1->setVisible(true);
        this->addChild(s_1, 50);
        s_1->setPosition(ccp(resolusi->getPosition().x - 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");

        getar();
    }
    if (x == 1)
    {
        bintang_kuning_2->setScale(0);
        bintang_kuning_2->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_2 = ParticleSystemQuad::create("bintang_particle.plist");
        s_2->setVisible(true);
        this->addChild(s_2, 50);
        s_2->setPosition(ccp(resolusi->getPosition().x, resolusi->getPosition().y));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
    if (x == 2)
    {
        bintang_kuning_3->setScale(0);
        bintang_kuning_3->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_3 = ParticleSystemQuad::create("bintang_particle.plist");
        s_3->setVisible(true);
        this->addChild(s_3, 50);
        s_3->setPosition(ccp(resolusi->getPosition().x + 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
}