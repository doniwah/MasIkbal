/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "KAPITAL_ARAB.h"
#include "coba.h"
#include "KAPITAL_INDONESIA.h"
#include "KAPITAL_INGGRIS.h"
#include "menu_pilih.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* KAPITAL_ARAB::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = KAPITAL_ARAB::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

const std::string nama_burung[] =
{
    "hewan/singa",
    "hewan/sapi",
    "hewan/ular",
    "hewan/unta",
    "hewan/babi",
    "hewan/kuda",
    "hewan/lalat",
    "tanaman/delima",
    "tanaman/jahe",
    "hewan/katak"
};

const std::string nama_kapital[] =
{
    "A",
    "B",
    "Ts",
    "J",
    "Kh",
    "H",
    "Dz",
    "R",
    "Za",
    "Dh"
};

const std::string nama_kecil[] =
{
    "sadun",
    "aqaratun",
    "u'baanun",
    "amalun",
    "inziirun",
    "ishaanun",
    "ubaabun",
    "umman",
    "njaiilun",
    "ifda'un"
};

const std::string nama_huruf[] =
{
    "belajar/Mengenal_huruf/Huruf_hijaiyah/alif",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ba",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ta",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ja",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/kha'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ha'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/dzal",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ra'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/za'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/dad"
};

void KAPITAL_ARAB::ganti()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    log("sayur ke %i", ganti_ke);

    if (ganti_ke < 0)
    {
        ganti_ke = 9;
    }

    if (ganti_ke >= 10)
    {
        ganti_ke = 0;
    };

    if (ganti_ke == 0)
    {

        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/1.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 0)), nullptr));

    }

    if (ganti_ke == 1)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/2.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 1)), nullptr));

    }

    if (ganti_ke == 2)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/3.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 2)), nullptr));

    }

    if (ganti_ke == 3)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/5.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 3)), nullptr));

    }

    if (ganti_ke == 4)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/7.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 4)), nullptr));

    }

    if (ganti_ke == 5)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/6.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 5)), nullptr));

    }

    if (ganti_ke == 6)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/9.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 6)), nullptr));

    }

    if (ganti_ke == 7)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/10.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 7)), nullptr));

    }
    if (ganti_ke == 8)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/11.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 8)), nullptr));

    }

    if (ganti_ke == 9)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/15.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 9)), nullptr));

    }

    object_huruf->setTexture(__String::createWithFormat("%s.png", nama_huruf[ganti_ke].c_str())->getCString());
    object_huruf->setScale(0);
    object_huruf->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.3)));
    //CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[hewan_ke].c_str())->getCString());

    //if (tombol_auto_aktif == true)
    //{
    //    hewan_ke++;
    //}
}
// on "init" you need to initialize your instance
bool KAPITAL_ARAB::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/abjad/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/abjad/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    object_huruf = Sprite::create("belajar/Mengenal_huruf/Huruf_hijaiyah/alif.png");
    object_huruf->setScale(0);
    object_huruf->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
    object_huruf->setPosition(Vec2(panel->getContentSize().width / 2 - 250, panel->getContentSize().height / 2 + 30));
    panel->addChild(object_huruf);

    b_lanjut = Button::create("stage/b_next.png");
    b_lanjut->setAnchorPoint(Point(0.5, 0.5));
    b_lanjut->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_lanjut);
    b_lanjut->setZoomScale(-0.1);
    b_lanjut->addClickEventListener([=](Ref* Sender) {
        if (bisa == true)
        {
            ganti_ke++;
            ganti();
        }
        });

    b_kembali = Button::create("stage/b_next.png");
    b_kembali->setRotation(180);
    b_kembali->setAnchorPoint(Point(0.5, 0.5));
    b_kembali->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_kembali);
    b_kembali->setZoomScale(-0.1);
    b_kembali->addClickEventListener([=](Ref* Sender) {
        if (bisa == true)
        {
            ganti_ke--;
            ganti();
        }
        
        });

    auto b_inggris = Button::create("stage/b_inggris_new_off.png");
    b_inggris->setAnchorPoint(Point(1, 1));
    b_inggris->setScale(1.45);
    b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_inggris);
    b_inggris->setZoomScale(-0.1);
    b_inggris->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = KAPITAL_INGGRIS::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_indo = Button::create("stage/B_indo_new_off.png");
    b_indo->setAnchorPoint(Point(1, 1));
    b_indo->setScale(1.45);
    b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
    this->addChild(b_indo);
    b_indo->setZoomScale(-0.1);
    b_indo->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = KAPITAL_INDONESIA::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_arab = Button::create("stage/b_arab_new.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setScale(1.45);
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        //auto gr_scene = hijaiyah::createScene();
        //Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_back = Button::create("belajar/huruf_indonesia/B_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/1.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/belajar hijaiyag dan benda.mp3");

    this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_ARAB::hewan, this, 20)), nullptr));

    return true;
}
void KAPITAL_ARAB::hewan(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 20)
    {
        bisa = true;
        object_hewan = Sprite::create("hewan/singa.png");
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.27)));
        object_hewan->setPosition(Vec2(panel->getContentSize().width / 2 + 175, panel->getContentSize().height / 2 + 50));
        panel->addChild(object_hewan);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_arab/asadun.mp3");

        kapital = Label::createWithTTF("A", "belajar/mengenal/Freude.otf", 65);
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 120, panel->getContentSize().height / 2 - 120));
        kapital->setTextColor(Color4B::RED);
        kapital->setScale(0);    
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        panel->addChild(kapital);

        kecil = Label::createWithTTF("sadun", "belajar/mengenal/Freude.otf", 55);
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 215, panel->getContentSize().height / 2 - 120));
        kecil->setTextColor(Color4B::BLACK);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        panel->addChild(kecil);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/asadu.mp3");
    }


    if (x == 0)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 120, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 215, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/asadu.mp3");
    }

    if (x == 1)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 100, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/baqarotun.mp3");
    }
    if (x == 2)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 60, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 210, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/tubaanun.mp3");
    }

    if (x == 3)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 100, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 210, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/jamaalun.mp3");
    }

    if (x == 4)
    {
       
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 95, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/khinziirun.mp3");
    }

    if (x == 5)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 95, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/hishaanun.mp3");
    }

    if (x == 6)
    {
       
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 85, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/dzubaabun.mp3");
    }

    if (x == 7)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 115, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
       CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_arab/rumman.mp3");
    }

    if (x == 8)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 100, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_arab/zanjailun.mp3");
    }

    if (x == 9)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 100, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 230, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_arab/dhifdaun.mp3");
    }

    
}



void KAPITAL_ARAB::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
