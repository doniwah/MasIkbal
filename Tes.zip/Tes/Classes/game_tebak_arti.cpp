/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "game_tebak_arti.h"
#include "menu_pilih.h"
#include "coba_2.h"
#include "pilihan_belajar.h"
#include "ActionShake.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* game_tebak_arti::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = game_tebak_arti::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
void game_tebak_arti::random()
{
    get_random[3] = RandomHelper::random_int(0, 25);

    if (get_random[0] == get_random[1])
    {
        get_random[1] = RandomHelper::random_int(0, 25);
        log("ada nilai yang sama");
        random();
    };
    if (get_random[1] == get_random[2])
    {
        get_random[2] = RandomHelper::random_int(0, 25);
        log("nilai kedua ada yang sama");
        random();
    };
    if (get_random[0] == get_random[2])
    {
        get_random[2] = RandomHelper::random_int(0, 25);
        log("ada nilai ketiga yang sama");
        random();
    }
}
const std::string nama_hewan[] =
{
                "hewan/anjeng",
                "hewan/babi",
                "hewan/belalang",
                "hewan/burung",
                "hewan/domba",
                "hewan/gagak",
                "hewan/gajah",
                "hewan/ikan",
                "hewan/kambing",
                "hewan/katak",
                "hewan/keledai",
                "hewan/kera",
                "hewan/kuda",
                "hewan/kutu",
                "hewan/laba_laba",
                "hewan/lalat",
                "hewan/lebah",
                "hewan/nyamuk",
                "hewan/puyuh",
                "hewan/rayap",
                "hewan/sapi",
                "hewan/semut",
                "hewan/serigala",
                "hewan/singa",
                "hewan/ular",
                "hewan/unta"
};

const std::string indo[] =
{
                "Anjeng",
                "Babi",
                "Belalang",
                "Burung hupu",
                "Domba",
                "Gagak",
                "Gajah",
                "Ikan",
                "Kambing",
                "Katak",
                "Keledai",
                "Kera",
                "Kuda",
                "Kutu",
                "Laba-laba",
                "Lalat",
                "Lebah",
                "Nyamuk",
                "Puyuh",
                "Rayap",
                "Sapi",
                "Semut",
                "Serigala",
                "Singa",
                "Ular",
                "Unta"
};

const std::string inggris[] =
{
                "Dog",
                "Pig",
                "Grasshopper",
                "Hupu",
                "Sheep",
                "Crow",
                "Elephant",
                "Fish",
                "Goat",
                "Frog",
                "Donkey",
                "Monkey",
                "Horse",
                "Louse",
                "Spider",
                "Fly",
                "Bee",
                "Musquito",
                "Quail",
                "Termite",
                "Cow",
                "Ant",
                "Wolf",
                "Lion",
                "Snake",
                "Camel"
};

const std::string suara_hewan[] =
{
        "sound/hewan_inggris/dog",
        "sound/hewan_inggris/pig",
        "sound/hewan_inggris/grasshopper",
        "sound/hewan_inggris/hupi",
        "sound/hewan_inggris/sheep",
        "sound/hewan_inggris/crow",
        "sound/hewan_inggris/elephant",
        "sound/hewan_inggris/fish",
        "sound/hewan_inggris/goat",
        "sound/hewan_inggris/frog",
        "sound/hewan_inggris/donkey",
        "sound/hewan_inggris/monkey",
        "sound/hewan_inggris/horse",
        "sound/hewan_inggris/louse",
        "sound/hewan_inggris/spider",
        "sound/hewan_inggris/fly",
        "sound/hewan_inggris/bee",
        "sound/hewan_inggris/musquito",
        "sound/hewan_inggris/quail",
        "sound/hewan_inggris/termite",
        "sound/hewan_inggris/cow",
        "sound/hewan_inggris/ant",
        "sound/hewan_inggris/wolf",
        "sound/hewan_inggris/lion",
        "sound/hewan_inggris/snake",
        "sound/hewan_inggris/camel"
};
void game_tebak_arti::fungsi_waktu()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 1; i++)
    {
        if (waktu == 0)
        {
            pertanyaan->setScale(0);
            panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
            panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
            panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
            break;
        }
        waktu--;
        label_waktu->setString(__String::createWithFormat("%i", waktu)->getCString());

        if (waktu == 0)
        {
            deteksi_sentuh = false;
            game_selesai();
        }
    }
}
// on "init" you need to initialize your instance
bool game_tebak_arti::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("bermain/tebak_arti/bg_(sementara).png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel_pertanyaan = Sprite::create("bermain/tebak_arti/Pannel.png");
    panel_pertanyaan->setAnchorPoint(Point(0.5, 1));
    panel_pertanyaan->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height + origin.y - 150));
    this->addChild(panel_pertanyaan);

    auto hitam = Label::createWithTTF("Apakah arti kata dari:", "belajar/mengenal/Freude.otf", 50);
    hitam->setPosition(Vec2(panel_pertanyaan->getContentSize().width / 2 - 140, panel_pertanyaan->getContentSize().height / 2));
    hitam->setTextColor(Color4B::BLACK);
    panel_pertanyaan->addChild(hitam);

    gambar_waktu = Sprite::create("bermain/pasang_suara/Pannel_waktu.png");
    gambar_waktu->setAnchorPoint(Point(0.5, 1));
    gambar_waktu->setPosition(Vec2(visibleSize.width / 2 + origin.x - 450, visibleSize.height + origin.y - 30));
    this->addChild(gambar_waktu);

    gambar_poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
    gambar_poin->setAnchorPoint(Point(0.5, 1));
    gambar_poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 450, visibleSize.height + origin.y - 30));
    this->addChild(gambar_poin);

    label_waktu = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    label_waktu->setString(__String::createWithFormat("%i", waktu)->getCString());
    label_waktu->setPosition(Vec2(gambar_waktu->getContentSize().width / 2 + 40, gambar_waktu->getContentSize().height / 2));
    label_waktu->setTextColor(Color4B::BLACK);
    gambar_waktu->addChild(label_waktu);

    label_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    label_poin->setString(__String::createWithFormat("%i", poin)->getCString());
    label_poin->setPosition(Vec2(gambar_poin->getContentSize().width / 2 + 40, gambar_poin->getContentSize().height / 2));
    label_poin->setTextColor(Color4B::BLACK);
    gambar_poin->addChild(label_poin);


    b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk main tevak arti.mp3");
    this->runAction(Sequence::create(DelayTime::create(2.5), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
    this->runAction(Sequence::create(DelayTime::create(2.5), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::manggil, this)), nullptr));


    return true;
}
void game_tebak_arti::manggil()
{
    this->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_waktu, this)), nullptr)));
}
void game_tebak_arti::game_selesai()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    this->stopAllActions();

    resolusi = Sprite::create("final_resolusi/p.png");
    resolusi->setScale(0.8);
    resolusi->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(resolusi);

    auto l_poin = Label::create("", "belajar/mengenal/Freude.otf", 70);
    l_poin->setString(__String::createWithFormat("%i", poin)->getCString());
    l_poin->setPosition(Vec2(resolusi->getContentSize().width / 2 + 100, resolusi->getContentSize().height / 2 - 245));
    l_poin->setTextColor(Color4B::WHITE);
    resolusi->addChild(l_poin);

    bintang_1 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_1);

    bintang_2 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_2->setPosition(Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_2);

    bintang_3 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_3);

    bintang_kuning_1 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_1->setScale(0);
    bintang_kuning_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_1);

    bintang_kuning_2 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_2->setScale(0);
    bintang_kuning_2->setPosition(Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_kuning_2);

    bintang_kuning_3 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_3->setScale(0);
    bintang_kuning_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_3);

    auto b_menu = Button::create("final_resolusi/b_menu.png");
    b_menu->setAnchorPoint(Point(0.5, 0.5));
    b_menu->setPosition(Vec2(resolusi->getContentSize().width / 2 + 270, resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_menu);
    b_menu->setZoomScale(-0.1);
    b_menu->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_restart = Button::create("final_resolusi/b_restart.png");
    b_restart->setAnchorPoint(Point(0.5, 0.5));
    b_restart->setPosition(Vec2(resolusi->getContentSize().width / 2 - 270, resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_restart);
    b_restart->setZoomScale(-0.1);
    b_restart->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = game_tebak_arti::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    if (poin == 0)
    {

    }
    else if (poin <= 5)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
            CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_bintang, this, 0)), nullptr));
    }
    else if (poin >= 5 && poin <= 9)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
            CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_bintang, this, 0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
            CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_bintang, this, 1)), nullptr));
    }
    else if (poin >= 10)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
            CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_bintang, this, 0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
            CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_bintang, this, 1)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.8),
            CallFunc::create(CC_CALLBACK_0(game_tebak_arti::fungsi_bintang, this, 2)), nullptr));
    }
}

void game_tebak_arti::getar()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    cocos2d::Device::vibrate(0.5f);

    float interval = 1 / 60;
    float duration = 0.5f;
    float speed = 5.0f;
    float magnitude = 5.f;

    this->runAction(ActionShake::create(duration, speed, magnitude));
}
void game_tebak_arti::fungsi_bintang(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        bintang_kuning_1->setScale(0);
        bintang_kuning_1->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_1 = ParticleSystemQuad::create("bintang_particle.plist");
        s_1->setVisible(true);
        this->addChild(s_1, 50);
        s_1->setPosition(ccp(resolusi->getPosition().x - 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");

        getar();
    }
    if (x == 1)
    {
        bintang_kuning_2->setScale(0);
        bintang_kuning_2->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_2 = ParticleSystemQuad::create("bintang_particle.plist");
        s_2->setVisible(true);
        this->addChild(s_2, 50);
        s_2->setPosition(ccp(resolusi->getPosition().x, resolusi->getPosition().y));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
    if (x == 2)
    {
        bintang_kuning_3->setScale(0);
        bintang_kuning_3->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_3 = ParticleSystemQuad::create("bintang_particle.plist");
        s_3->setVisible(true);
        this->addChild(s_3, 50);
        s_3->setPosition(ccp(resolusi->getPosition().x + 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
}
void game_tebak_arti::muncul()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    deteksi_sentuh = true;

    for (int i = 0; i < 3; i++)
    {
        get_random[i] = RandomHelper::random_int(0, 25);

        if (get_random[0] == get_random[1])
        {
            get_random[1] = RandomHelper::random_int(0, 20);
            log("ada nilai yang sama");
            random();
        };
        if (get_random[1] == get_random[2])
        {
            get_random[2] = RandomHelper::random_int(0, 20);
            log("nilai kedua ada yang sama");
            random();
        };
        if (get_random[0] == get_random[2])
        {
            get_random[2] = RandomHelper::random_int(0, 20);
            log("ada nilai ketiga yang sama");
            random();
        }

        terakhir = RandomHelper::random_int(0, 2);

        panel_hewan[i] = Sprite::create("bermain/tebak_arti/button.png");

        panel_hewan[i]->setScale(0);
        panel_hewan[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1)));
        panel_hewan[i]->setAnchorPoint(Point(0.5, 0.5));
        this->addChild(panel_hewan[i]);


        object[i] = Button::create(__String::createWithFormat("%s.png", nama_hewan[get_random[i]].c_str())->getCString());
        object[i]->setAnchorPoint(Point(0.5, 0.5));
        object[i]->setScale(0.2);
        object[i]->setPosition(Vec2(panel_hewan[i]->getContentSize().width / 2, panel_hewan[i]->getContentSize().height / 2 + 30));
        panel_hewan[i]->addChild(object[i]);  
        object[i]->setZoomScale(-0.1);
        object[i]->addClickEventListener([=](Ref* Sender) {
            if (deteksi_sentuh == true)
            {
                deteksi_sentuh = false;
                if (i == terakhir)
                {
                    log("benar");
                    poin++;
                    label_poin->setString(__String::createWithFormat("%i", poin)->getCString());


                    if (poin == 1)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(0);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 2)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(1);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 3)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(2);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 4)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(3);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 5)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(0);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 6)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(1);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 7)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(2);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 8)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(3);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 9)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(0);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 10)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(1);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 11)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(2);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 12)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(3);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                        this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));
                    }
                    else if (poin == 13)
                    {
                        pertanyaan->setScale(0);
                        jika_benar(0);
                        panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                        this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::game_selesai, this)), nullptr));
  
                    }
                }
                else
                {

                    float interval = 1 / 60;
                    float duration = 0.5f;
                    float speed = 5.0f;
                    float magnitude = 8.f;

                    this->runAction(ActionShake::create(duration, speed, magnitude));
                    pertanyaan->setScale(0);
                    jika_benar(4);
                    panel_hewan[0]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                    panel_hewan[1]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                    panel_hewan[2]->runAction(EaseBackOut::create(ScaleBy::create(0.8, 0)));
                    this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::soal, this)), nullptr));
                    this->runAction(Sequence::create(DelayTime::create(4.2), CallFunc::create(CC_CALLBACK_0(game_tebak_arti::muncul, this)), nullptr));

                }
            }
            });

        nama_indo[i] = Label::createWithTTF("60", "belajar/mengenal/Freude.otf", 30);
        nama_indo[i]->setString(__String::create(indo[get_random[i]].c_str())->getCString());
        nama_indo[i]->setPosition(Vec2(panel_hewan[i]->getContentSize().width / 2, panel_hewan[i]->getContentSize().height / 2 - 100));
        nama_indo[i]->setTextColor(Color4B::BLACK);
        panel_hewan[i]->addChild(nama_indo[i]);
    }



    pertanyaan = Label::createWithTTF("Grasshoper", "belajar/mengenal/Freude.otf", 50);
    pertanyaan->setString(__String::create(inggris[get_random[terakhir]].c_str())->getCString());
    pertanyaan->setPosition(Vec2(panel_pertanyaan->getContentSize().width / 2 + 240, panel_pertanyaan->getContentSize().height / 2));
    pertanyaan->setTextColor(Color4B::RED);
    panel_pertanyaan->addChild(pertanyaan);

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_random[terakhir]].c_str())->getCString());

    panel_hewan[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 450, visibleSize.height / 2 + origin.y - 100));
    panel_hewan[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y - 100));
    panel_hewan[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 450, visibleSize.height / 2 + origin.y - 100));


}
void game_tebak_arti::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
void game_tebak_arti::soal()
{
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk main tevak arti.mp3");
}

void game_tebak_arti::jika_benar(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {

            bagus = Sprite::create("ekspresi/bagus.png");
            bagus->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            bagus->setScale(0);
            bagus->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(bagus);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/bagus.mp3");

    }
    else if (x == 1)
    {


            pintar = Sprite::create("ekspresi/pintar.png");
            pintar->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            pintar->setScale(0);
            pintar->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(pintar);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pintar.mp3");

    }
    else if (x == 2)
    {

            pandai = Sprite::create("ekspresi/Pandai.png");
            pandai->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            pandai->setScale(0);
            pandai->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(pandai);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pndai.mp3");

    }
    else if (x == 3)
    {

            berhasil = Sprite::create("ekspresi/berhasil.png");
            berhasil->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            berhasil->setScale(0);
            berhasil->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(berhasil);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/berhasil.mp3");


    }
    else  if (x == 4)
    {
            salah = Sprite::create("ekspresi/yahh.png");
            salah->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            salah->setScale(0);
            salah->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(salah);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yaaah.mp3");
    };
}
