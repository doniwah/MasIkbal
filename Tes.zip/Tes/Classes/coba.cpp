/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "coba.h"
#include "menu_pilih.h"
#include "hijaiyah.h"
#include "KAPITAL_ARAB.h"
#include "buah_arab/mengeja_anggur_arab.h"
#include "hewan_arab/mengeja_babi_arab.h"
#include "mengenal_buah_arab.h"
#include "mengenal_hewan_arab.h"
#include "pilihan_belajar.h"
#include "angka_indonesia.h"
#include "cerita/mengaji_buah.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* coba::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = coba::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

void coba::jeli(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 1)
    {
        button->setScaleX(0.7);
        jeli(2);
    }
    if (x == 2)
    {
        button->setScaleY(0.8);
        this->runAction(Sequence::create(DelayTime::create(0.1), CallFunc::create(CC_CALLBACK_0(coba::jeli, this, 3)), nullptr));
    }
    if (x == 3)
    {
        button->setScale(0.7);
        
    }

}
void coba::animasi(int x)
{
    if (x == 0)
    {
        cobacoba->setOpacity(0);
        cobacoba_2->setOpacity(100);
        this->runAction(Sequence::create(DelayTime::create(0.8), CallFunc::create(CC_CALLBACK_0(coba::animasi, this, 1)), nullptr));
    }
    if (x == 1)
    {
        cobacoba->setOpacity(200);
        cobacoba_2->setOpacity(0);
        this->runAction(Sequence::create(DelayTime::create(0.3), CallFunc::create(CC_CALLBACK_0(coba::animasi, this, 0)), nullptr));
    }
}
// on "init" you need to initialize your instance
bool coba::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto bg = CSLoader::createNode("res/stage_belajar.csb");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);
    auto anim_bg = CSLoader::createTimeline("res/stage_belajar.csb");
    bg->runAction(anim_bg);
    anim_bg->gotoFrameAndPlay(0, true);

    cobacoba = Sprite::create("bintang_kuning.png");
    cobacoba->setOpacity(0);
    cobacoba->setRotation(15);
    cobacoba->setScale(0.02);
    cobacoba->setPosition(Vec2(visibleSize.width / 2 + origin.x , visibleSize.height / 2 + origin.y + 200));
    this->addChild(cobacoba);

    cobacoba_2 = Sprite::create("Bintang_coklat.png");
    cobacoba_2->setScale(0.02);
    cobacoba_2->setRotation(15);
    cobacoba_2->setPosition(Vec2(visibleSize.width / 2 + origin.x , visibleSize.height / 2 + origin.y + 200));
    this->addChild(cobacoba_2);

    animasi(0);

    button = Button::create( "stage/pilihan_menu_belajar/button_new/b_huruf.png" );
    button->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button->setAnchorPoint(Point(0.5, 0.5));
    button->setScale(0.7);
    button->setZoomScale(-0.1);
    button->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = hijaiyah::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto scaleBy = ScaleBy::create(0.7f, 0.7f);
    auto ease = EaseElasticInOut::create(scaleBy->clone(), 0.04f);
    auto seq1 = Sequence::create(ease, nullptr);

    //this->runAction(Sequence::create(DelayTime::create(5), CallFunc::create(CC_CALLBACK_0(coba::jeli, this, 1)), nullptr));


    auto button_2 = Button::create( "stage/pilihan_menu_belajar/button_new/B_huruf_benda.png" );
    button_2->setPosition(Vec2( visibleSize.width / 2 + origin.x , visibleSize.height / 2 + origin.y));
    button_2->setAnchorPoint(Point(0.5, 0.5));
    button_2->setScale(0.7);
    button_2->setZoomScale(-0.1);
    button_2->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = KAPITAL_ARAB::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });


    auto button_5 = Button::create("stage/pilihan_menu_belajar/button_new/B_mengeja_buah.png");
    button_5->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button_5->setAnchorPoint(Point(0.5, 0.5));
    button_5->setScale(0.7);
    button_5->setZoomScale(-0.1);
    button_5->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengeja_anggur_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_6 = Button::create("stage/pilihan_menu_belajar/button_new/B_mengeja_hewan.png");
    button_6->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    button_6->setAnchorPoint(Point(0.5, 0.5));
    button_6->setScale(0.7);
    button_6->setZoomScale(-0.1);
    button_6->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengeja_babi_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_3 = Button::create("stage/pilihan_menu_belajar/button_new/B_mengenal_buah.png");
    button_3->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button_3->setAnchorPoint(Point(0.5, 0.5));
    button_3->setScale(0);
    button_3->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
    button_3->setZoomScale(-0.1);
    button_3->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengenal_buah_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_4 = Button::create("stage/pilihan_menu_belajar/button_new/B_mengenal_hewan.png");
    button_4->setPosition(Vec2( visibleSize.width / 2 + origin.x , visibleSize.height / 2 + origin.y));
    button_4->setAnchorPoint(Point(0.5, 0.5));
    button_4->setScale(0.7);
    button_4->setZoomScale(-0.1);
    button_4->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengenal_hewan_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_8 = Button::create("stage/pilihan_menu_belajar/button_new/Mengaji_Buah.png");
    button_8->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    button_8->setAnchorPoint(Point(0.5, 0.5));
    button_8->setScale(0.7);
    button_8->setEnabled(false);
//    button_8->setZoomScale(-0.1);
//    button_8->addClickEventListener([=](Ref* Sender) {
//        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
//        auto gr_scene = mengaji_buah::createScene();
//        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
//        });

    auto button_7 = Button::create("stage/pilihan_menu_belajar/button_new/B_mengenal_angka.png");
    button_7->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button_7->setAnchorPoint(Point(0.5, 0.5));
    button_7->setScale(0);
    button_7->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.7)));
    button_7->setZoomScale(-0.1);
    button_7->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = angka_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_9 = Button::create("stage/pilihan_menu_belajar/button_new/Mengaji_hewan.png");
    button_9->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    button_9->setAnchorPoint(Point(0.5, 0.5));
    button_9->setScale(0.7);
    button_9->setEnabled(false);
//    button_8->setZoomScale(-0.1);
//    button_8->addClickEventListener([=](Ref* Sender) {
//        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
//        auto gr_scene = mengaji_buah::createScene();
//        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
//        });

    auto button_10 = Button::create("stage/pilihan_menu_belajar/button_new/Sains_buah.png");
    button_10->setPosition(Vec2(visibleSize.width / 2 + origin.x- 600, visibleSize.height / 2 + origin.y));
    button_10->setAnchorPoint(Point(0.5, 0.5));
    button_10->setScale(0.7);
    button_10->setEnabled(false);
//    button_8->setZoomScale(-0.1);
//    button_8->addClickEventListener([=](Ref* Sender) {
//        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
//        auto gr_scene = mengaji_buah::createScene();
//        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
//        });

    auto button_11 = Button::create("stage/pilihan_menu_belajar/button_new/Sains_buah.png");
    button_11->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y));
    button_11->setAnchorPoint(Point(0.5, 0.5));
    button_11->setScale(0.7);
    button_11->setEnabled(false);
//    button_8->setZoomScale(-0.1);
//    button_8->addClickEventListener([=](Ref* Sender) {
//        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
//        auto gr_scene = mengaji_buah::createScene();
//        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
//        });

    auto pageView = PageView::create();
    pageView->setAnchorPoint( Point( 0.5, 0.5));
    pageView->setTouchEnabled( true );
    pageView->setContentSize( Size (1024, 1024));
    pageView->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));

    auto layout1 = Layout::create();
    layout1->setContentSize( Size (1024, 1024));
    layout1->addChild( button );
    layout1->addChild( button_2 );

    auto layout2 = Layout::create();
    layout2->setContentSize( Size (1024, 1024));
    layout2->addChild( button_7 );
    layout2->addChild( button_8 );

    auto layout3 = Layout::create();
    layout3->setContentSize( Size (1024, 1024));
    layout3->addChild( button_5 );
    layout3->addChild( button_6 );

    auto layout4 = Layout::create();
    layout4->setContentSize( Size (1024, 1024));
    layout4->addChild( button_4 );
    layout4->addChild(button_3);

    auto layout5 = Layout::create();
    layout5->setContentSize( Size (1024, 1024));
    layout5->addChild( button_9 );
    layout5->addChild( button_10);

    auto layout6 = Layout::create();
    layout6->setContentSize( Size (1024, 1024));
    layout6->addChild(button_11);

    pageView->addPage( layout1 );
    pageView->insertPage( layout3, 1);
    pageView->insertPage( layout4, 2);
    pageView->insertPage( layout2, 3);
    pageView->insertPage( layout5, 4);
    pageView->insertPage( layout6, 5);

    pageView->addEventListener( CC_CALLBACK_2( coba::pageViewEvent, this));

    this->addChild(pageView);

    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        if(pageView->getCurPageIndex() == 0)
        {
            titik[0]->setColor(Color3B(82, 93, 115));
            titik[1]->setColor(Color3B::YELLOW);
            page = 1;
            b_left->setScale(1);
            pageView->setCurPageIndex(1);
            button_5->setScale(0);
            button_5->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_6->setScale(0);
            button_6->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 1)
        {
            titik[1]->setColor(Color3B(82, 93, 115));
            titik[2]->setColor(Color3B::YELLOW);
            page = 2;
            pageView->setCurPageIndex(2);
            button_3->setScale(0);
            button_3->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_4->setScale(0);
            button_4->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 2)
        {
            titik[2]->setColor(Color3B(82, 93, 115));
            titik[3]->setColor(Color3B::YELLOW);
            page = 3;
            pageView->setCurPageIndex(3);
            button_7->setScale(0);
            button_7->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_8->setScale(0);
            button_8->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 3)
        {
            titik[2]->setColor(Color3B(82, 93, 115));
            titik[3]->setColor(Color3B::YELLOW);
            page = 3;
            pageView->setCurPageIndex(4);
            button_9->setScale(0);
            button_9->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_10->setScale(0);
            button_10->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 4)
        {
            titik[2]->setColor(Color3B(82, 93, 115));
            titik[3]->setColor(Color3B::YELLOW);
            page = 3;
            pageView->setCurPageIndex(5);
            button_11->setScale(0);
            button_11->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
            b_next->setScale(0);
        }
    });

    b_left = Button::create("stage/b_next.png");
    b_left->setRotation(180);
    b_left->setScale(0);
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        if(pageView->getCurPageIndex() == 5)
        {
            b_next->setScale(1);
            page = 2;
            titik[3]->setColor(Color3B(82, 93, 115));
            titik[2]->setColor(Color3B::YELLOW);
            pageView->setCurPageIndex(4);
            button_9->setScale(0);
            button_9->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_10->setScale(0);
            button_10->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 4)
        {
            page = 2;
            titik[3]->setColor(Color3B(82, 93, 115));
            titik[2]->setColor(Color3B::YELLOW);
            pageView->setCurPageIndex(3);
            button_8->setScale(0);
            button_8->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_7->setScale(0);
            button_7->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 3)
        {
            page = 2;
            titik[3]->setColor(Color3B(82, 93, 115));
            titik[2]->setColor(Color3B::YELLOW);
            pageView->setCurPageIndex(2);
            button_4->setScale(0);
            button_4->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_3->setScale(0);
            button_3->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 2)
        {
            titik[2]->setColor(Color3B(82, 93, 115));
            titik[1]->setColor(Color3B::YELLOW);
            page = 1;
            pageView->setCurPageIndex(1);
            button_6->setScale(0);
            button_6->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_5->setScale(0);
            button_5->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if(pageView->getCurPageIndex() == 1)
        {
            titik[1]->setColor(Color3B(82, 93, 115));
            titik[0]->setColor(Color3B::YELLOW);
            page = 0;
            pageView->setCurPageIndex(0);
            button_2->setScale(0);
            button_2->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button->setScale(0);
            button->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
            b_left->setScale(0);
        }
    });

    auto b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2( origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = menu_pilih::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });


    for (int i = 0; i < 4; i++)
    {
        titik[i] = Sprite::create("lingkaran.png");
        titik[i]->setScale(0);
        this->addChild(titik[i]);
    }
    titik[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 75, visibleSize.height / 2 + origin.y - 350));
    titik[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 25, visibleSize.height / 2 + origin.y - 350));
    titik[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 25, visibleSize.height / 2 + origin.y - 350));
    titik[3]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 75, visibleSize.height / 2 + origin.y - 350));

    //titik[0]->setColor(Color3B(82, 93, 115));

    return true;
}


void coba::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}

void coba::pageViewEvent( Ref *sender, ui::PageView::EventType type)
{
    ui::PageView *pageView = dynamic_cast<ui::PageView *>(sender);
    switch (type)
    {
        case ui::PageView::EventType::TURNING:


            log( "%i", pageView->getCurPageIndex());

            if(pageView->getCurPageIndex() == 0)
            {
                b_left->setScale(0);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 1){
                b_left->setScale(1);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 2){
                b_left->setScale(1);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 3){
                b_left->setScale(1);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 4){
                b_left->setScale(1);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 5){
                b_left->setScale(1);
                b_next->setScale(0);
            }

            break;

        default:
            break;
    }
}

