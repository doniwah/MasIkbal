/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#ifndef __game_tebak_arti_H__
#define __game_tebak_arti_H__

#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "network/HttpClient.h"
#include "cocos/platform/CCDevice.h"

USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace tinyxml2;

class game_tebak_arti : public cocos2d::Layer
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(game_tebak_arti);
private:
    Sprite* bg;
    Sprite* gambar_poin;
    Sprite* resolusi;
    Sprite* bintang_1;
    Sprite* bintang_2;
    Sprite* bintang_3;
    Sprite* bintang_kuning_1;
    Sprite* bintang_kuning_2;
    Sprite* bintang_kuning_3;
    Sprite* berhasil;
    Sprite* bagus;
    Sprite* pandai;
    Sprite* pintar;
    Sprite* salah;
    Sprite* gambar_waktu;
    Sprite* panel_pertanyaan;
    Sprite* panel_hewan[3];
    Button* object[3];
    Label* nama_indo[3];
    Label* pertanyaan;
    Label* label_poin;
    Label* label_waktu;

    void jika_benar(int x);
    void muncul();
    int get_random[3];
    int terakhir;
    int poin = 0;
    int waktu = 60;
    void soal();
    void fungsi_waktu();
    void game_selesai();
    void fungsi_bintang(int x);
    void manggil();
    void random();
    void getar();


    bool deteksi_sentuh = false;
    Button* b_suara[3];
    Button* b_back;
};

#endif // __HELLOWORLD_SCENE_H__
