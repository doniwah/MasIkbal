/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


#include "pilihan_bermain.h"
#include "menu_pilih.h"
#include "abjad.h"
#include "menghubungkan_kata.h"
#include "mengenal_hewan_arab.h"
#include "SimpleAudioEngine.h"
#include "game_pasang_suara.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* pilihan_bermain::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = pilihan_bermain::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

// Print useful error message instead of segfaulting when files are not there.


const std::string name_huruf[] =
{
    "stage/pilihan_bermain/b_menghubungkan_kata",
    "stage/pilihan_bermain/b_mewarnai",
    "stage/pilihan_bermain/b_tebak_kata",
    "stage/pilihan_bermain/b_puzzle",
    "stage/pilihan_bermain/b_tebak_arti",
    "stage/pilihan_bermain/b_pasang_suara"
};
// on "init" you need to initialize your instance
bool pilihan_bermain::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("stage/bg_baru.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/mengeja/pannel.png");
    panel->setScale(1.5);
    panel->setOpacity(0);
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    panel_2 = Sprite::create("belajar/mengeja/pannel.png");
    panel_2->setScale(1.5);
    panel_2->setOpacity(0);
    panel_2->setPosition(Vec2(visibleSize.width / 2 + origin.x + 1500, visibleSize.height / 2 + origin.y));
    this->addChild(panel_2);

    panel_3 = Sprite::create("stage/pannel.png");
    panel_3->setOpacity(0);
    panel_3->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel_3);

    scr_objek = ScrollView::create();
    scr_objek->setDirection(ScrollView::Direction::HORIZONTAL);
    scr_objek->setContentSize(Size(2000, 800));
    scr_objek->setInnerContainerSize(Size((565 * (6 + 10)) - scr_objek->getContentSize().width - 280, 0));
    scr_objek->setAnchorPoint(Point(0.5, 0.5));
    scr_objek->setPosition(Vec2(panel_3->getPosition()));
    scr_objek->setBounceEnabled(true);
    scr_objek->setClippingEnabled(true);
    scr_objek->setSwallowTouches(false);
    this->addChild(scr_objek, 99);
    scr_objek->setScrollBarOpacity(0);

    for (int i = 0; i < 6; i++)
    {
        button[i] = Button::create(__String::createWithFormat("%s.png", name_huruf[i].c_str())->getCString());
        button[i]->setPosition(Vec2(1000 + ((button[i]->getContentSize().width + 500) * i),
            (scr_objek->getInnerContainerSize().height - 400) - (i % 6)));
        scr_objek->addChild(button[i]);
        button[i]->setZoomScale(-0.1);
    }
    button[0]->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });
    button[1]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });
    button[2]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });
    button[3]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });
    button[4]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });
    button[5]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = game_pasang_suara::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });


    /*b_menghubungkan_ata = Button::create("stage/pilihan_bermain/b_menghubungkan_kata.png");
    b_menghubungkan_ata->setAnchorPoint(Point(0.5, 0.5));
    b_menghubungkan_ata->setScale(2);
    b_menghubungkan_ata->setPosition(Vec2(panel_3->getContentSize().width / 2, panel_3->getContentSize().height / 2 ));
    scr_objek->addChild(b_menghubungkan_ata);
    b_menghubungkan_ata->setZoomScale(-0.2);
    b_menghubungkan_ata->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = menghubungkan_kata::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_mewarnai = Button::create("stage/pilihan_bermain/b_mewarnai.png");
    b_mewarnai->setAnchorPoint(Point(0.5, 0.5));
    b_mewarnai->setPosition(Vec2(panel_3->getContentSize().width / 2 + 500, panel_3->getContentSize().height / 2));
    scr_objek->addChild(b_mewarnai);
    b_mewarnai->setScale(2);
    b_mewarnai->setZoomScale(-0.2);
    b_mewarnai->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });

    b_tebak_kata = Button::create("stage/pilihan_bermain/b_tebak_kata.png");
    b_tebak_kata->setAnchorPoint(Point(0.5, 0.5));
    b_tebak_kata->setPosition(Vec2(panel_3->getContentSize().width / 2 + 1000, panel_3->getContentSize().height / 2));
    scr_objek->addChild(b_tebak_kata);
    b_tebak_kata->setZoomScale(-0.2);
    b_tebak_kata->setScale(2);
    b_tebak_kata->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });

    b_tebak_arti = Button::create("stage/pilihan_bermain/b_tebak_arti.png");
    b_tebak_arti->setAnchorPoint(Point(0.5, 0.5));
    b_tebak_arti->setPosition(Vec2(panel_3->getContentSize().width / 2 + 1500, panel_3->getContentSize().height / 2));
    scr_objek->addChild(b_tebak_arti);
    b_tebak_arti->setScale(2);
    b_tebak_arti->setZoomScale(-0.2);
    b_tebak_arti->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });

    b_pasang_suara = Button::create("stage/pilihan_bermain/b_pasang_suara.png");
    b_pasang_suara->setAnchorPoint(Point(0.5, 0.5));
    b_pasang_suara->setPosition(Vec2(panel_3->getContentSize().width / 2 + 2000, panel_3->getContentSize().height / 2));
    scr_objek->addChild(b_pasang_suara);
    b_pasang_suara->setScale(2);
    b_pasang_suara->setZoomScale(-0.2);
    b_pasang_suara->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = game_pasang_suara::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_puzzle = Button::create("stage/pilihan_bermain/b_puzzle.png");
    b_puzzle->setAnchorPoint(Point(0.5, 0.5));
    b_puzzle->setPosition(Vec2(panel_3->getContentSize().width / 2 + 2500, panel_3->getContentSize().height / 2));
    scr_objek->addChild(b_puzzle);
    b_puzzle->setZoomScale(-0.2);
    b_puzzle->setScale(2);
    b_puzzle->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });*/

    b_back = Button::create("stage/menu_pilihan/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = menu_pilih::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    //next = Button::create("stage/b_next.png");
    //next->setAnchorPoint(Point(0.5, 0.5));
    //next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 650, visibleSize.height / 2 + origin.y));
    //this->addChild(next);
    //next->setZoomScale(-0.1);
    //next->addClickEventListener([=](Ref* Sender) {

    //    panel->runAction(EaseElasticOut::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x - 1500, visibleSize.height / 2 + origin.y))));
    //    panel_2->runAction(EaseElasticOut::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y))));
    //    left->setScale(1);
    //    next->setScale(0);

    //    });

    //left = Button::create("stage/b_next.png");
    //left->setAnchorPoint(Point(0.5, 0.5));
    //left->setScale(0);
    //left->setRotation(180);
    //left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 650, visibleSize.height / 2 + origin.y));
    //this->addChild(left);
    //left->setZoomScale(-0.1);
    //left->addClickEventListener([=](Ref* Sender) {
    //    panel->runAction(EaseElasticOut::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y))));
    //    panel_2->runAction(EaseElasticOut::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x + 1500, visibleSize.height / 2 + origin.y))));
    //    next->setScale(1);
    //    left->setScale(0);
    //    });



    return true;
}


void pilihan_bermain::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = menu_pilih::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
