/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "KAPITAL_INGGRIS.h"
#include "coba.h"
#include "KAPITAL_INDONESIA.h"
#include "KAPITAL_ARAB.h"
#include "menu_pilih.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* KAPITAL_INGGRIS::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = KAPITAL_INGGRIS::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

const std::string nama_burung[] =
{
    "hewan/semut",
    "hewan/lebah",
    "hewan/unta",
    "tanaman/kurma",
    "hewan/gajah",
    "hewan/lalat",
    "tanaman/jahe",
    "hewan/kuda",
    "hewan/nyamuk",
    "tanaman/zaitun",
    "tanaman/labu",
    "hewan/ular",
    "hewan/rayap",
    "hewan/serigala"
};

const std::string nama_kapital[] =
{
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "M",
    "O",
    "P",
    "S",
    "T",
    "W"
};

const std::string nama_kecil[] =
{
    "nt",
    "ee",
    "amel",
    "ate",
    "lephant",
    "ly",
    "inger",
    "orse",
    "usquito",
    "live",
    "umpkin",
    "nake",
    "ermite",
    "olf"
};

const std::string nama_huruf[] =
{
    "belajar/Mengenal_huruf/huruf_alphabet/a",
    "belajar/Mengenal_huruf/huruf_alphabet/b",
    "belajar/Mengenal_huruf/huruf_alphabet/c",
    "belajar/Mengenal_huruf/huruf_alphabet/d",
    "belajar/Mengenal_huruf/huruf_alphabet/e",
    "belajar/Mengenal_huruf/huruf_alphabet/f",
    "belajar/Mengenal_huruf/huruf_alphabet/g",
    "belajar/Mengenal_huruf/huruf_alphabet/h",
    "belajar/Mengenal_huruf/huruf_alphabet/m",
    "belajar/Mengenal_huruf/huruf_alphabet/o",
    "belajar/Mengenal_huruf/huruf_alphabet/p",
    "belajar/Mengenal_huruf/huruf_alphabet/s",
    "belajar/Mengenal_huruf/huruf_alphabet/t",
    "belajar/Mengenal_huruf/huruf_alphabet/w"
};

void KAPITAL_INGGRIS::ganti()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    log("sayur ke %i", ganti_ke);

    if (ganti_ke < 0)
    {
        ganti_ke = 13;
    }

    if (ganti_ke >= 14)
    {
        ganti_ke = 0;
    };

    if (ganti_ke == 0)
    {

        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/a.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 0)), nullptr));

    }

    if (ganti_ke == 1)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/b.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 1)), nullptr));

    }

    if (ganti_ke == 2)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/c.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 2)), nullptr));

    }

    if (ganti_ke == 3)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/d.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 3)), nullptr));

    }

    if (ganti_ke == 4)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/e.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 4)), nullptr));

    }

    if (ganti_ke == 5)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/f.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 5)), nullptr));

    }

    if (ganti_ke == 6)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/g.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 6)), nullptr));

    }

    if (ganti_ke == 7)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/h.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 7)), nullptr));

    }
    if (ganti_ke == 8)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/m.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 8)), nullptr));

    }

    if (ganti_ke == 9)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/o.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 9)), nullptr));

    }
    
    if (ganti_ke == 10)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/p.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 10)), nullptr));
    }

    if (ganti_ke == 11)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/s.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 11)), nullptr));
    }

    if (ganti_ke == 12)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/t.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 12)), nullptr));
    }
    if (ganti_ke == 13)
    {
        object_hewan->setOpacity(0);
        kapital->setOpacity(0);
        kecil->setOpacity(0);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/w.mp3");
        this->stopAllActions();
        this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 13)), nullptr));
    }

    object_huruf->setTexture(__String::createWithFormat("%s.png", nama_huruf[ganti_ke].c_str())->getCString());
    object_huruf->setScale(0);
    object_huruf->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.3)));
    //CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[hewan_ke].c_str())->getCString());

    //if (tombol_auto_aktif == true)
    //{
    //    hewan_ke++;
    //}
}
// on "init" you need to initialize your instance
bool KAPITAL_INGGRIS::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/abjad/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/abjad/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    object_huruf = Sprite::create("belajar/Mengenal_huruf/huruf_alphabet/a.png");
    object_huruf->setScale(0);
    object_huruf->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
    object_huruf->setPosition(Vec2(panel->getContentSize().width / 2 - 250, panel->getContentSize().height / 2 + 30));
    panel->addChild(object_huruf);

    b_lanjut = Button::create("stage/b_next.png");
    b_lanjut->setAnchorPoint(Point(0.5, 0.5));
    b_lanjut->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_lanjut);
    b_lanjut->setZoomScale(-0.1);
    b_lanjut->addClickEventListener([=](Ref* Sender) {
        if (bisa == true)
        {
            ganti_ke++;
            ganti();
        }
        
        });

    b_kembali = Button::create("stage/b_next.png");
    b_kembali->setAnchorPoint(Point(0.5, 0.5));
    b_kembali->setRotation(180);
    b_kembali->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_kembali);
    b_kembali->setZoomScale(-0.1);
    b_kembali->addClickEventListener([=](Ref* Sender) {
        if (bisa == true)
        {
            ganti_ke--;
            ganti();
        }

        });

    auto b_inggris = Button::create("stage/b_inggris_new.png");
    b_inggris->setAnchorPoint(Point(1, 1));
    b_inggris->setScale(1.45);
    b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_inggris);
    b_inggris->setZoomScale(-0.1);
    b_inggris->addClickEventListener([=](Ref* Sender) {
        /*auto gr_scene = hijaiyah::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));*/
        });

    auto b_arab = Button::create("stage/B_arab_new_off.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setScale(1.45);
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = KAPITAL_ARAB::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_indo = Button::create("stage/B_indo_new_off.png");
    b_indo->setAnchorPoint(Point(1, 1));
    b_indo->setScale(1.45);
    b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
    this->addChild(b_indo);
    b_indo->setZoomScale(-0.1);
    b_indo->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = KAPITAL_INDONESIA::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_back = Button::create("belajar/huruf_indonesia/B_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/a.mp3");

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/belajar hijaiyag dan benda.mp3");

    this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(KAPITAL_INGGRIS::hewan, this, 20)), nullptr));

    return true;
}
void KAPITAL_INGGRIS::hewan(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 20)
    {
        bisa = true;
        object_hewan = Sprite::create("hewan/semut.png");
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        object_hewan->setPosition(Vec2(panel->getContentSize().width / 2 + 175, panel->getContentSize().height / 2 + 50));
        panel->addChild(object_hewan);
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/ant.mp3");

        kapital = Label::createWithTTF("A", "belajar/mengenal/Freude.otf", 65);
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 150, panel->getContentSize().height / 2 - 120));
        kapital->setTextColor(Color4B::RED);
        kapital->setScale(0);    
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        panel->addChild(kapital);

        kecil = Label::createWithTTF("nt", "belajar/mengenal/Freude.otf", 65);
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 205, panel->getContentSize().height / 2 - 120));
        kecil->setTextColor(Color4B::BLACK);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        panel->addChild(kecil);

    }


    if (x == 0)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 150, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 205, panel->getContentSize().height / 2 - 120));
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/ant.mp3");
    }

    if (x == 1)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 205, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/bee.mp3");
    }
    if (x == 2)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 120, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 210, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/camel.mp3");
    }

    if (x == 3)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 140, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 210, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_inggris/date ersa.mp3");
    }

    if (x == 4)
    {
       
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 80, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 210, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/elephant.mp3");
    }

    if (x == 5)
    {
        
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 135, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 190, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/fly.mp3");
    }

    if (x == 6)
    {
       
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 100, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 200, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_inggris/ginger.mp3");
    }

    if (x == 7)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 110, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 200, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/horse.mp3");
    }

    if (x == 8)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 70, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 200, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/musquito.mp3");
    }

    if (x == 9)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 120, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 200, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_inggris/olive erza.mp3");
    }

    if (x == 10)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 70, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 200, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_inggris/pumpkin.mp3");
    }

    if (x == 11)
    {
        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 115, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 200, panel->getContentSize().height / 2 - 120));
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/snake.mp3");
    }

    if (x == 12)
    {

        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString()); 
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 105, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 220, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/termite.mp3");
    }
    if (x == 13)
    {

        object_hewan->setTexture(__String::createWithFormat("%s.png", nama_burung[ganti_ke].c_str())->getCString());
        object_hewan->setOpacity(255);
        object_hewan->setScale(0);
        object_hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.3)));
        kapital->setString(__String::create(nama_kapital[ganti_ke].c_str())->getCString());
        kapital->setOpacity(255);
        kapital->setScale(0);
        kapital->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        kapital->setPosition(Vec2(panel->getContentSize().width / 2 + 130, panel->getContentSize().height / 2 - 120));
        kecil->setPosition(Vec2(panel->getContentSize().width / 2 + 205, panel->getContentSize().height / 2 - 120));
        kecil->setString(__String::create(nama_kecil[ganti_ke].c_str())->getCString());
        kecil->setOpacity(255);
        kecil->setScale(0);
        kecil->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/wolf.mp3");
    }
}



void KAPITAL_INGGRIS::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
