/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "mengaji_buah.h"
#include "mengaji_buah_2.h"
#include "coba_2.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* mengaji_buah::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = mengaji_buah::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
// on "init" you need to initialize your instance


String narasi = __String::create("Halo teman teman namaku Tisa.")->getCString();
String narasi2 = __String::create("Halo teman teman namaku Tisa.")->getCString();

String narasi_3 = __String::create("Yuk kita belajar mengaji tentang")->getCString();
String narasi_4 = __String::create("Yuk kita belajar mengaji tentang")->getCString();

String narasi_5 = __String::create("Buah yang ada di Al-Qur'an. Mari")->getCString();
String narasi_6 = __String::create("Buah yang ada di Al-Qur'an. Mari")->getCString();

String narasi_7 = __String::create("kita mengaji bersama.")->getCString();
String narasi_8 = __String::create("kita mengaji bersama.")->getCString();
int y = 0;
int a = 0;
int b = 0;
int c = 0;
void mengaji_buah::listener_text(int x)
{
    if (x == 0)
    {
        if (y != 4 && y != 10 && y != 16 && y != 23 && y != 29)
        {
            text->getLetter(y)->setOpacity(255);
        }

        y++;
    }
    if (x == 1)
    {
        if (a != 3 && a != 8 && a != 16 && a != 24 && a != 32)
        {
            text_2->getLetter(a)->setOpacity(255);
        }

        a++;
    }
    if (x == 2)
    {
        if (b != 4 && b != 9 && b != 13 && b != 16 && b != 27 && b != 32)
        {
            text_3->getLetter(b)->setOpacity(255);
        }

        b++;
    }

    if (x == 3)
    {
        if (c != 4 && c != 12 && c != 21)
        {
            text_4->getLetter(c)->setOpacity(255);
        }

        c++;
    }

}
bool mengaji_buah::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto bg = Sprite::create("cerita/slide1/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel_1 = Sprite::create("cerita/slide1/1.png");
    panel_1->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel_1); 
    
    panel_2 = Sprite::create("cerita/slide1/2.png");
    panel_2->setPosition(Vec2(visibleSize.width / 2 + origin.x - 400, visibleSize.height / 2 + origin.y + 150));
    this->addChild(panel_2);

    cewe = CSLoader::createNode("res/bocil.csb");
    cewe->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y - 300));
    this->addChild(cewe);
    cewe->setScale(0.6);
    anim_cewe = CSLoader::createTimeline("res/bocil.csb");
    cewe->runAction(anim_cewe);
    anim_cewe->play("cerita", true);

    cowo = CSLoader::createNode("res/ustadz.csb");
    cowo->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height / 2 + origin.y - 250));
    this->addChild(cowo);
    cowo->setScale(0.48);
    anim_cowo = CSLoader::createTimeline("res/ustadz.csb");
    cowo->runAction(anim_cowo);
    anim_cowo->gotoFrameAndPlay(0, true);

    auto b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2( origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        //auto gr_scene = menu_pilih::createScene();
        //Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto text2 = Label::createWithTTF(__String::create(narasi2.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 45);
    text2->setTextColor(Color4B::BLACK);
    text2->setAnchorPoint(Point(0, 0.5));
    text2->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 80));
    panel_2->addChild(text2);

    text = Label::createWithTTF(__String::create(narasi.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 45);
    text->setTextColor(Color4B::WHITE);
    text->setAnchorPoint(Point(0, 0.5));
    text->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 80));
    panel_2->addChild(text);
    text->setAlignment(TextHAlignment::RIGHT);
    text->setOpacity(0);
    runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah::listener_text, this, 0)),
        DelayTime::create(0.10), NULL), narasi.length()));

    auto text3 = Label::createWithTTF(__String::create(narasi_4.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 45);
    text3->setTextColor(Color4B::BLACK);
    text3->setAnchorPoint(Point(0, 0.5));
    text3->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 30));
    panel_2->addChild(text3);

    auto text4 = Label::createWithTTF(__String::create(narasi_6.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 45);
    text4->setTextColor(Color4B::BLACK);
    text4->setAnchorPoint(Point(0, 0.5));
    text4->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 20));
    panel_2->addChild(text4);

    auto text5 = Label::createWithTTF(__String::create(narasi_8.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 45);
    text5->setTextColor(Color4B::BLACK);
    text5->setAnchorPoint(Point(0, 0.5));
    text5->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 70));
    panel_2->addChild(text5);
    
    this->runAction(Sequence::create(DelayTime::create(3.80), CallFunc::create(CC_CALLBACK_0(mengaji_buah::selanjutnya, this, 0)), nullptr));
    this->runAction(Sequence::create(DelayTime::create(7), CallFunc::create(CC_CALLBACK_0(mengaji_buah::selanjutnya, this, 1)), nullptr));
    this->runAction(Sequence::create(DelayTime::create(10.13), CallFunc::create(CC_CALLBACK_0(mengaji_buah::selanjutnya, this, 2)), nullptr));

    auto b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(1, 0.5));
    b_next->setPosition(Vec2(visibleSize.width + origin.x - 30, visibleSize.height / 2 + origin.y));
    b_next->runAction(RepeatForever::create(Sequence::create(ScaleTo::create(0.7, 0.6),
        (ScaleTo::create(0.7, 0.7)), nullptr)));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengaji_buah_2::createScene();
        Director::getInstance()->replaceScene(TransitionPageTurn::create(1.7, gr_scene, false));
        });

    return true;
}


void mengaji_buah::menuCloseCallback(Ref* pSender)
{
    //Director::getInstance()->end();
}
void mengaji_buah::selanjutnya(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {


        text_2 = Label::createWithTTF(__String::create(narasi_3.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 45);
        text_2->setTextColor(Color4B::WHITE);
        text_2->setAnchorPoint(Point(0, 0.5));
        text_2->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 30));
        panel_2->addChild(text_2);
        text_2->setAlignment(TextHAlignment::RIGHT);
        text_2->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah::listener_text, this, 1)),
            DelayTime::create(0.10), NULL), narasi_3.length()));
    }

    if (x == 1)
    {


        text_3 = Label::createWithTTF(__String::create(narasi_5.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 45);
        text_3->setTextColor(Color4B::WHITE);
        text_3->setAnchorPoint(Point(0, 0.5));
        text_3->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 20));
        panel_2->addChild(text_3);
        text_3->setAlignment(TextHAlignment::RIGHT);
        text_3->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah::listener_text, this, 2)),
            DelayTime::create(0.10), NULL), narasi_5.length()));
    }

    if (x == 2)
    {


        text_4 = Label::createWithTTF(__String::create(narasi_7.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 45);
        text_4->setTextColor(Color4B::WHITE);
        text_4->setAnchorPoint(Point(0, 0.5));
        text_4->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 70));
        panel_2->addChild(text_4);
        text_4->setAlignment(TextHAlignment::RIGHT);
        text_4->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah::listener_text, this, 3)),
            DelayTime::create(0.10), NULL), narasi_7.length()));
    }
}

