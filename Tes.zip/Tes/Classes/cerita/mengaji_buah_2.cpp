/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "mengaji_buah_2.h"
#include "coba.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* mengaji_buah_2::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = mengaji_buah_2::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
// on "init" you need to initialize your instance






//

//


void mengaji_buah_2::listener_text(int x)
{
    if (x == 0)
    {
        if (y != 4 && y != 12 && y != 16 && y != 21 && y != 29 && y != 36 && y != 40)
        {
            text->getLetter(y)->setOpacity(255);
        }

        y++;
    }
    if (x == 1)
    {
        if (a != 5 && a != 9 && a != 13 && a != 18 && a != 26 && a != 31 && a != 38)
        {
            text_2->getLetter(a)->setOpacity(255);
        }

        a++;
    }
    if (x == 2)
    {
        if (b != 8 && b != 15 && b != 23 && b != 27 && b != 36)
        {
            text_3->getLetter(b)->setOpacity(255);
        }

        b++;
    }

    if (x == 3)
    {
        if (c != 5 && c != 10 && c != 13 && c != 19 && c != 28 && c != 33 && c != 40)
        {
            text_4->getLetter(c)->setOpacity(255);
        }

        c++;
    }

    if (x == 4)
    {
        if (d != 7 && d != 10 && d != 16 && d != 22 && d != 27 && d != 31 && d != 36 && d != 41)
        {
            text_5->getLetter(d)->setOpacity(255);
        }

        d++;
    }

    if (x == 5)
    {
        if (e != 29 && e != 38 )
        {
            text_6->getLetter(e)->setOpacity(255);
        }

        e++;
    }
//
};
bool mengaji_buah_2::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto bg = Sprite::create("cerita/slide2/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel_1 = Sprite::create("cerita/slide2/1.png");
    panel_1->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y));
    this->addChild(panel_1);

    panel_2 = Sprite::create("cerita/slide2/2.png");
    panel_2->setScale(1.4);
    panel_2->setPosition(Vec2(visibleSize.width / 2 + origin.x + 100, visibleSize.height / 2 + origin.y + 150));
    this->addChild(panel_2);

    cewe = CSLoader::createNode("res/bocil.csb");
    cewe->setPosition(Vec2(visibleSize.width / 2 + origin.x - 700, visibleSize.height / 2 + origin.y - 300));
    this->addChild(cewe);
    cewe->setScale(0.6);
    anim_cewe = CSLoader::createTimeline("res/bocil.csb");
    cewe->runAction(anim_cewe);
    anim_cewe->play("cerita", true);

    auto b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2( origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto text2 = Label::createWithTTF(__String::create(narasi2.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text2->setTextColor(Color4B::BLACK);
    text2->setAnchorPoint(Point(0, 0.5));
    text2->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 100));
    panel_2->addChild(text2);

    text = Label::createWithTTF(__String::create(narasi.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text->setTextColor(Color4B::WHITE);
    text->setAnchorPoint(Point(0, 0.5));
    text->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 100));
    panel_2->addChild(text);
    text->setAlignment(TextHAlignment::RIGHT);
    text->setOpacity(0);
    runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::listener_text, this, 0)),
        DelayTime::create(0.10), NULL), narasi.length()));

    auto text3 = Label::createWithTTF(__String::create(narasi_4.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text3->setTextColor(Color4B::BLACK);
    text3->setAnchorPoint(Point(0, 0.5));
    text3->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 60));
    panel_2->addChild(text3);

    this->runAction(Sequence::create(DelayTime::create(3.97), CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::selanjutnya, this, 0)), nullptr));

    auto text4 = Label::createWithTTF(__String::create(narasi_6.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text4->setTextColor(Color4B::BLACK);
    text4->setAnchorPoint(Point(0, 0.5));
    text4->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 20));
    panel_2->addChild(text4);

    this->runAction(Sequence::create(DelayTime::create(7.60), CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::selanjutnya, this, 1)), nullptr));
    this->runAction(Sequence::create(DelayTime::create(11.10), CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::selanjutnya, this, 2)), nullptr));

    auto text5 = Label::createWithTTF(__String::create(narasi_8.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text5->setTextColor(Color4B::BLACK);
    text5->setAnchorPoint(Point(0, 0.5));
    text5->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 20));
    panel_2->addChild(text5);
    
    auto text6 = Label::createWithTTF(__String::create(narasi_10.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text6->setTextColor(Color4B::BLACK);
    text6->setAnchorPoint(Point(0, 0.5));
    text6->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 60));
    panel_2->addChild(text6);

    this->runAction(Sequence::create(DelayTime::create(14.90), CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::selanjutnya, this, 3)), nullptr));

    auto text7 = Label::createWithTTF(__String::create(narasi_12.getCString())->getCString(),
        "belajar/mengenal/Freude.otf", 30);
    text7->setTextColor(Color4B::BLACK);
    text7->setAnchorPoint(Point(0, 0.5));
    text7->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 100));
    panel_2->addChild(text7);

    this->runAction(Sequence::create(DelayTime::create(18.65), CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::selanjutnya, this, 4)), nullptr));

    /*auto b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {

        });*/

   // this->runAction(Sequence::create(DelayTime::create(3.80), CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::selanjutnya, this, 0)), nullptr));

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/mengaji/zaitun.mp3");

    return true;
}


void mengaji_buah_2::menuCloseCallback(Ref* pSender)
{
    //Director::getInstance()->end();
}
void mengaji_buah_2::selanjutnya(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {


        text_2 = Label::createWithTTF(__String::create(narasi_3.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 30);
        text_2->setTextColor(Color4B::WHITE);
        text_2->setAnchorPoint(Point(0, 0.5));
        text_2->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 60));
        panel_2->addChild(text_2);
        text_2->setAlignment(TextHAlignment::RIGHT);
        text_2->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::listener_text, this, 1)),
            DelayTime::create(0.10), NULL), narasi_3.length()));
    }

    if (x == 1)
    {


        text_3 = Label::createWithTTF(__String::create(narasi_5.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 30);
        text_3->setTextColor(Color4B::WHITE);
        text_3->setAnchorPoint(Point(0, 0.5));
        text_3->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 + 20));
        panel_2->addChild(text_3);
        text_3->setAlignment(TextHAlignment::RIGHT);
        text_3->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::listener_text, this, 2)),
            DelayTime::create(0.10), NULL), narasi_5.length()));
    }

    if (x == 2)
    {


        text_4 = Label::createWithTTF(__String::create(narasi_7.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 30);
        text_4->setTextColor(Color4B::WHITE);
        text_4->setAnchorPoint(Point(0, 0.5));
        text_4->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 20));
        panel_2->addChild(text_4);
        text_4->setAlignment(TextHAlignment::RIGHT);
        text_4->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::listener_text, this, 3)),
            DelayTime::create(0.10), NULL), narasi_7.length()));
    }

    if (x == 3)
    {


        text_5 = Label::createWithTTF(__String::create(narasi_9.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 30);
        text_5->setTextColor(Color4B::WHITE);
        text_5->setAnchorPoint(Point(0, 0.5));
        text_5->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 60));
        panel_2->addChild(text_5);
        text_5->setAlignment(TextHAlignment::RIGHT);
        text_5->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::listener_text, this, 4)),
            DelayTime::create(0.10), NULL), narasi_9.length()));
    }

    if (x == 4)
    {
        text_6 = Label::createWithTTF(__String::create(narasi_11.getCString())->getCString(),
            "belajar/mengenal/Freude.otf", 30);
        text_6->setTextColor(Color4B::WHITE);
        text_6->setAnchorPoint(Point(0, 0.5));
        text_6->setPosition(Vec2(panel_2->getContentSize().width / 2 - 320, panel_2->getContentSize().height / 2 - 100));
        panel_2->addChild(text_6);
        text_6->setAlignment(TextHAlignment::RIGHT);
        text_6->setOpacity(0);
        runAction(Repeat::create(Sequence::create(CallFunc::create(CC_CALLBACK_0(mengaji_buah_2::listener_text, this, 5)),
            DelayTime::create(0.10), NULL), narasi_11.length()));
    }
}

