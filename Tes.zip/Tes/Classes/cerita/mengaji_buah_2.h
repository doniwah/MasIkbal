/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#ifndef __mengaji_buah_2_H__
#define __mengaji_buah_2_H__

#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "network/HttpClient.h"
#include "cocos/platform/CCDevice.h"

USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace tinyxml2;

class mengaji_buah_2 : public cocos2d::Layer
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(mengaji_buah_2);




private:
    Sprite* panel_1;
    Sprite* panel_2;
    String narasi = __String::create("Yang pertama ada buah zaitun. Kalian tau")->getCString();
    String narasi2 = __String::create("Yang pertama ada buah zaitun. Kalian tau")->getCString();
    Node* cewe;
    int y = 0;
    cocostudio::timeline::ActionTimeline* anim_cewe; 
    Node* cowo;
    cocostudio::timeline::ActionTimeline* anim_cowo;
    String narasi_3 = __String::create("tidak apa itu buah zaitun? Buah zaitun")->getCString();
    String narasi_4 = __String::create("tidak apa itu buah zaitun? Buah zaitun")->getCString();
    int a = 0;
    int b = 0;
    String narasi_5 = __String::create("memiliki bentuk lonjong dan berwarna")->getCString();
    String narasi_6 = __String::create("memiliki bentuk lonjong dan berwarna")->getCString();
    cocos2d::Label* text;
    cocos2d::Label* text_2;
    cocos2d::Label* text_3;
    cocos2d::Label* text_4;
    cocos2d::Label* text_5;
    cocos2d::Label* text_6;
    void listener_text(int x);
    void selanjutnya(int x);
    String narasi_7 = __String::create("hijau loh. Di dalam Al-Quran buah zaitun ")->getCString();
    String narasi_8 = __String::create("hijau loh. Di dalam Al-Quran buah zaitun")->getCString();
    int c = 0;
    String narasi_9 = __String::create("disebut di surah Abasa ayat 29. Mari kita")->getCString();
    String narasi_10 = __String::create("disebut di surah Abasa ayat 29. Mari kita")->getCString();
    int d = 0;
    String narasi_11 = __String::create("                     mengaji bersama.")->getCString();
    String narasi_12 = __String::create("                     mengaji bersama.")->getCString();
    int e = 0;
};

#endif // __HELLOWORLD_SCENE_H__
