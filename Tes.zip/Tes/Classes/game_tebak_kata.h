/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#ifndef __game_tebak_kata_H__
#define __game_tebak_kata_H__

#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "network/HttpClient.h"
#include "cocos/platform/CCDevice.h"

USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace tinyxml2;

class game_tebak_kata : public cocos2d::Layer
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(game_tebak_kata);
private:
    void fungsi_khusus();
    Sprite* bg;
    Sprite* panel_besar;
    Sprite* gambar_pertama;
    Button* gambar_kedua[3];
    Button* gambar_baru[2];
    Sprite* panel_kecil_2[2];
    Sprite* panel_kecil_3[3];
    Sprite* bagus;
    Sprite* pintar;
    Sprite* pandai;
    Sprite* berhsil;
    Sprite* salah;
    Sprite* waktu;
    Sprite* poin;
    Sprite* resolusi;
    Sprite* bintang_1;
    Sprite* bintang_2;
    Sprite* bintang_3;
    Sprite* bintang_kuning_1;
    Sprite* bintang_kuning_2;
    Sprite* bintang_kuning_3;
    int get_rand_hewan[3];
    int hewan_yang_benar;
    Label* l_waktu;
    Label* nama_indo[2];
    Label* nama_indo_3[2];
    Label* l_poin;
    void muncul_indo(int x);
    void muncul_inggris(int x);
    void muncul_arab(int x);
    int i_waktu = 180;
    void random(int x);
    bool otomatis_aktif = false;
    Button* b_back;
    void jika_benar(int x);
    int berhasil = 0;
    void fungsi_waktu();
    int i_poin = 0;
    void untuk_manggil();
    Button* panel_bantuan[2];
    void getar();
    void fungsi_bintang(int x);
    void game_selesai();
    void manggil();

};

#endif // __HELLOWORLD_SCENE_H__
