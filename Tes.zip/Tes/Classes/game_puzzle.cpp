/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "game_puzzle.h"
#include "menu_pilih.h"
#include "pilihan_belajar.h"
#include "coba_2.h"
#include "ActionShake.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* game_puzzle::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = game_puzzle::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
const std::string arab[] =
{
        "teks_arab_hijau/hewan/anjing",
        "teks_arab_hijau/hewan/babi",
        "teks_arab_hijau/hewan/belalang",
        "teks_arab_hijau/hewan/burung_hupu",
        "teks_arab_hijau/hewan/domba",
        "teks_arab_hijau/hewan/gagak",
        "teks_arab_hijau/hewan/gajah",
        "teks_arab_hijau/hewan/ikan",
        "teks_arab_hijau/hewan/kambing",
        "teks_arab_hijau/hewan/katak",
        "teks_arab_hijau/hewan/keledai",
        "teks_arab_hijau/hewan/kera",
        "teks_arab_hijau/hewan/kuda",
        "teks_arab_hijau/hewan/kutu",
        "teks_arab_hijau/hewan/laba_laba",
        "teks_arab_hijau/hewan/lalat",
        "teks_arab_hijau/hewan/lebah",
        "teks_arab_hijau/hewan/nyamuk",
        "teks_arab_hijau/hewan/puyuh",
        "teks_arab_hijau/hewan/rayap",
        "teks_arab_hijau/hewan/sapi",
        "teks_arab_hijau/hewan/semut",
        "teks_arab_hijau/hewan/serigala",
        "teks_arab_hijau/hewan/singa",
        "teks_arab_hijau/hewan/ular",
        "teks_arab_hijau/hewan/unta"
};
const std::string inggris[] =
        {
                "Dog",
                "Pig",
                "Grasshopper",
                "Hupu",
                "Sheep",
                "Crow",
                "Elephant",
                "Fish",
                "Goat",
                "Frog",
                "Donkey",
                "Monkey",
                "Horse",
                "Louse",
                "Spider",
                "Fly",
                "Bee",
                "Musquito",
                "Quail",
                "Termite",
                "Cow",
                "Ant",
                "Wolf",
                "Lion",
                "Snake",
                "Camel"
        };
const std::string indonesia[] =
{
        "Anjing",
        "Babi",
        "Belalang",
        "Burung hupu",
        "Domba",
        "Gagak",
        "Gajah",
        "Ikan",
        "Kambing",
        "Katak",
        "Keledai",
        "Kera",
        "Kuda",
        "Kutu",
        "Laba-laba",
        "Lalat",
        "Lebah",
        "Nyamuk",
        "Puyuh",
        "Rayap",
        "Sapi",
        "Semut",
        "Serigala",
        "Singa",
        "Ular",
        "Unta"
};
const std::string hewann[] =
{
        "hewan/anjeng",
        "hewan/babi",
        "hewan/belalang",
        "hewan/burung",
        "hewan/domba",
        "hewan/gagak",
        "hewan/gajah",
        "hewan/ikan",
        "hewan/kambing",
        "hewan/katak",
        "hewan/keledai",
        "hewan/kera",
        "hewan/kuda",
        "hewan/kutu",
        "hewan/laba_laba",
        "hewan/lalat",
        "hewan/lebah",
        "hewan/nyamuk",
        "hewan/puyuh",
        "hewan/rayap",
        "hewan/sapi",
        "hewan/semut",
        "hewan/serigala",
        "hewan/singa",
        "hewan/ular",
        "hewan/unta"
};

void game_puzzle::random()
{
    random_huruf[3] = RandomHelper::random_int(0, 20);

    if (random_huruf[0] == random_huruf[1])
    {
        random_huruf[1] = RandomHelper::random_int(0, 20);
        log("ada nilai yang sama");
        random();
    };
    if (random_huruf[1] == random_huruf[2])
    {
        random_huruf[2] = RandomHelper::random_int(0, 20);
        log("nilai kedua ada yang sama");
        random();
    };
    if (random_huruf[0] == random_huruf[2])
    {
        random_huruf[2] = RandomHelper::random_int(0, 20);
        log("ada nilai ketiga yang sama");
        random();
    }
}

bool game_puzzle::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event)
{
    point_began = touch->getLocation();

    b_1 = panel_hijau[0]->getBoundingBox();
    b_2 = panel_hijau[1]->getBoundingBox();
    b_3 = panel_hijau[2]->getBoundingBox();


    if (b_1.containsPoint(point_began))
    {
        drag = 0;
        log("1 buah di touch began");
    }
    else if (b_2.containsPoint(point_began))
    {
        drag = 1;
        log("2 buah di touch began");
    }
    else if (b_3.containsPoint(point_began))
    {
        drag = 2;
        log("3 buah di touch began");
    }
    return true;
}
void game_puzzle::onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* event)
{
    point_moved = touch->getLocation();
    if (drag == 0) {
        panel_hijau[0]->setPosition(point_moved);
    }
    else if (drag == 1) {
        panel_hijau[1]->setPosition(point_moved);
    }
    else if (drag == 2) {
        panel_hijau[2]->setPosition(point_moved);
    };
}
void game_puzzle::fungsi_waktu()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 1; i++)
    {
        if (i_waktu == 0)
        {
            break;
        }

        i_waktu--;
        l_waktu->setString(__String::createWithFormat("%i", i_waktu)->getCString());

        if (i_waktu == 0)
        {
            /*fungsi_menang();*/
            game_selesai();
            this->stopAllActions();
        }
    }
}
void game_puzzle::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event)
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    point_ended = touch->getLocation();

    b_1 = panel_hijau[0]->getBoundingBox();
    b_2 = panel_hijau[1]->getBoundingBox();
    b_3 = panel_hijau[2]->getBoundingBox();
    // Panel
    a_1 = panel_kuning[0]->getBoundingBox();
    a_2 = panel_kuning[1]->getBoundingBox();
    a_3 = panel_kuning[2]->getBoundingBox();
    if(poin == 0)
{       if (drag == 0) {
        if (b_1.intersectsRect(a_3) && deteksi_sentuh[0] == true)
        {
            panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 250)));
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
            selesai++;
            particle(2);
            log("yang berhasil 1");
            deteksi_sentuh[0] = false;
        }
        else
        {
            panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
        };
    };
    if (drag == 1)
    {
        if (b_2.intersectsRect(a_1) && deteksi_sentuh[1] == true)
        {
            particle(0);
            panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
            selesai++;
            log("yang berhasil 2");
            deteksi_sentuh[1] = false;
        }
        else
        {
            panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
        }
    };
    if (drag == 2)
    {
        if (b_3.intersectsRect(a_2) && deteksi_sentuh[2] == true)
        {
            particle(1);
            panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 50)));
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
            selesai++;
            log("yang berhasil 3");
            deteksi_sentuh[2] = false;
        }
        else
        {
            panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
        }
    };
}
    if(poin == 1)
    {       if (drag == 0) {
            if (b_1.intersectsRect(a_1) && deteksi_sentuh[0] == true)
            {
                particle(0);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_2) && deteksi_sentuh[1] == true)
            {
                particle(1);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_3) && deteksi_sentuh[2] == true)
            {
                particle(2);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 2)
    {       if (drag == 0) {
            if (b_1.intersectsRect(a_2) && deteksi_sentuh[0] == true)
            {
                particle(1);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_3) && deteksi_sentuh[1] == true)
            {
                particle(2);

                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_1) && deteksi_sentuh[2] == true)
            {
                particle(0);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 3)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_3) && deteksi_sentuh[0] == true)
            {
                particle(2);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_1) && deteksi_sentuh[1] == true)
            {
                particle(0);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_2) && deteksi_sentuh[2] == true)
            {
                particle(1);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 4)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_1) && deteksi_sentuh[0] == true)
            {
                particle(0);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_3) && deteksi_sentuh[1] == true)
            {
                particle(2);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_2) && deteksi_sentuh[2] == true)
            {
                particle(1);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 5)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_2) && deteksi_sentuh[0] == true)
            {
                particle(1);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_1) && deteksi_sentuh[1] == true)
            {
                particle(0);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_3) && deteksi_sentuh[2] == true)
            {
                particle(2);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 6)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_3) && deteksi_sentuh[0] == true)
            {
                particle(2);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_2) && deteksi_sentuh[1] == true)
            {
                particle(1);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_1) && deteksi_sentuh[2] == true)
            {
                particle(0);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 7)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_2) && deteksi_sentuh[0] == true)
            {
                particle(1);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_3) && deteksi_sentuh[1] == true)
            {
                particle(2);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_1) && deteksi_sentuh[2] == true)
            {
                particle(0);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 8)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_1) && deteksi_sentuh[0] == true)
            {
                particle(0);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_2) && deteksi_sentuh[1] == true)
            {
                particle(1);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_3) && deteksi_sentuh[2] == true)
            {
                particle(2);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }
    if(poin == 9)
    {
        if (drag == 0) {
            if (b_1.intersectsRect(a_2) && deteksi_sentuh[0] == true)
            {
                particle(1);
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 50)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150)));
            };
        };
        if (drag == 1)
        {
            if (b_2.intersectsRect(a_1) && deteksi_sentuh[1] == true)
            {
                particle(0);
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y + 150)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50)));
            }
        };
        if (drag == 2)
        {
            if (b_3.intersectsRect(a_3) && deteksi_sentuh[2] == true)
            {
                particle(2);
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x- 50, visibleSize.height / 2 + origin.y - 250)));
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 3");
                deteksi_sentuh[2] = false;
            }
            else
            {
                panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250)));
            }
        };
    }


    if (selesai == 3)
    {
        selesai = 0;
        poin++; 
        l_poin->setString(__String::createWithFormat("%i", poin)->getCString());
        panel_hijau[0]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_hijau[1]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_hijau[2]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_kuning[0]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_kuning[1]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_kuning[2]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        if(poin <= 9){
            this->runAction(Sequence::create(DelayTime::create(2.5), CallFunc::create(CC_CALLBACK_0(game_puzzle::muncul_indonesia, this)), nullptr));
        };



        if (poin == 1)
        {
            jika_benar(0);
        }
        else if (poin == 2)
        {
            jika_benar(1);
        }
        else if (poin == 3)
        {
            jika_benar(2);
        }
        else if (poin == 4)
        {
            jika_benar(3);
        }
        else if (poin == 5)
        {
            jika_benar(0);
        }
        else if (poin == 6)
        {
            jika_benar(1);
        }
        if (poin == 7)
        {
            jika_benar(2);
        }
        else if (poin == 8)
        {
            jika_benar(3);
        }
        else if (poin == 9)
        {
            jika_benar(0);
        }
        else if (poin == 10)
        {
            this->stopAllActions();
            this->runAction(Sequence::create(DelayTime::create(1.5), CallFunc::create(CC_CALLBACK_0(game_puzzle::game_selesai, this)), nullptr));
        }
    }

   
        
    drag = 99;
    log("touch end");
};
// on "init" you need to initialize your instance
bool game_puzzle::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 3; ++i) {
        deteksi_sentuh[i] = true;
    }

    bg = Sprite::create("bermain/puzzle/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    waktu = Sprite::create("bermain/pasang_suara/Pannel_waktu.png");
    waktu->setAnchorPoint(Point(0.5, 1));
    waktu->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height + origin.y - 15));
    this->addChild(waktu);

    s_poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
    s_poin->setAnchorPoint(Point(0.5, 1));
    s_poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height + origin.y - 15));
    this->addChild(s_poin);

    l_waktu = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    l_waktu->setString(__String::createWithFormat("%i", i_waktu)->getCString());
    l_waktu->setPosition(Vec2(waktu->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
    l_waktu->setTextColor(Color4B::BLACK);
    waktu->addChild(l_waktu);

    l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    l_poin->setString(__String::createWithFormat("%i", poin)->getCString());
    l_poin->setPosition(Vec2(s_poin->getContentSize().width / 2 + 40, s_poin->getContentSize().height / 2));
    l_poin->setTextColor(Color4B::BLACK);
    s_poin->addChild(l_poin);

    b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(game_puzzle::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(game_puzzle::onTouchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(game_puzzle::onTouchEnded, this);
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk main pzzle.mp3");

    this->runAction(Sequence::create(DelayTime::create(3), CallFunc::create(CC_CALLBACK_0(game_puzzle::muncul_indonesia, this)), nullptr));
    this->runAction(Sequence::create(DelayTime::create(3), CallFunc::create(CC_CALLBACK_0(game_puzzle::khusus, this)), nullptr));

    return true;
}
void game_puzzle::khusus()
{
    this->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1), CallFunc::create(CC_CALLBACK_0(game_puzzle::fungsi_waktu, this)), nullptr)));
}
void game_puzzle::jika_benar(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
            bagus = Sprite::create("ekspresi/bagus.png");
            bagus->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            bagus->setScale(0);
            bagus->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(bagus);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/bagus.mp3");
    }
    else if (x == 1)
    {
            pintar = Sprite::create("ekspresi/pintar.png");
            pintar->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            pintar->setScale(0);
            pintar->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(pintar);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pintar.mp3");
    }
    else if (x == 2)
    {
            pandai = Sprite::create("ekspresi/Pandai.png");
            pandai->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            pandai->setScale(0);
            pandai->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(pandai);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pndai.mp3");
    }
    else if (x == 3)
    {
            berhasil = Sprite::create("ekspresi/berhasil.png");
            berhasil->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            berhasil->setScale(0);
            berhasil->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(berhasil);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/berhasil.mp3");
    }
    else  if (x == 4)
    {
            salah = Sprite::create("ekspresi/yahh.png");
            salah->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            salah->setScale(0);
            salah->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(salah);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yaaah.mp3");
    };
}
void game_puzzle::muncul_arab()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 3; ++i) {
        panel_kuning[i] = Sprite::create("bermain/puzzle/Pannel_kiri.png");
        panel_kuning[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_kuning[i]->setScale(1.1);
        this->addChild(panel_kuning[i]);

        huruf[i] = Sprite::create(__String::createWithFormat("%s.png", arab[i].c_str())->getCString());
        huruf[i]->setAnchorPoint(Point(0.5, 0.5));
        huruf[i]->setScale(0.1);
        huruf[i]->setPosition(Vec2(panel_kuning[i]->getContentSize().width / 2 - 20, panel_kuning[i]->getContentSize().height / 2));
        panel_kuning[i]->addChild(huruf[i]);

    }
    panel_kuning[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y + 200));
    panel_kuning[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y));
    panel_kuning[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y - 200));

    for (int i = 0; i < 3; ++i) {
        panel_hijau[i] = Sprite::create("bermain/puzzle/Pannel_kanan.png");
        panel_hijau[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_hijau[i]->setScale(1.1);
        this->addChild(panel_hijau[i]);

        hewan[i] = Sprite::create(__String::createWithFormat("%s.png", hewann[i].c_str())->getCString());
        hewan[i]->setAnchorPoint(Point(0.5, 0.5));
        hewan[i]->setScale(0.08);
        hewan[i]->setPosition(Vec2(panel_hijau[i]->getContentSize().width / 2 + 20, panel_hijau[i]->getContentSize().height / 2));
        panel_hijau[i]->addChild(hewan[i]);

    }
    panel_hijau[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y + 200));
    panel_hijau[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y));
    panel_hijau[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y - 200));
}

void game_puzzle::muncul_indonesia()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 3; ++i) {
        deteksi_sentuh[i] = true;
    }

    for (int i = 0; i < 3; ++i) {

        random_huruf[i] = RandomHelper::random_int(0, 25);

        if (random_huruf[0] == random_huruf[1])
        {
            random_huruf[1] = RandomHelper::random_int(0, 20);
            log("ada nilai yang sama");
            random();
        };
        if (random_huruf[1] == random_huruf[2])
        {
            random_huruf[2] = RandomHelper::random_int(0, 20);
            log("nilai kedua ada yang sama");
            random();
        };
        if (random_huruf[0] == random_huruf[2])
        {
            random_huruf[2] = RandomHelper::random_int(0, 20);
            log("ada nilai ketiga yang sama");
            random();
        }

        panel_kuning[i] = Sprite::create("bermain/puzzle/Pannel_kiri.png");
        panel_kuning[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_kuning[i]->setScale(0);
        panel_kuning[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1.5)));
        this->addChild(panel_kuning[i]);

        if(poin <= 5)
        {
            nama_hewan_indonesia[i] = Label::createWithTTF("Burung Hupu", "belajar/mengenal/Freude.otf", 40);
            nama_hewan_indonesia[i]->setString(__String::create(indonesia[random_huruf[i]].c_str())->getCString());
            nama_hewan_indonesia[i]->setPosition(Vec2(panel_kuning[i]->getContentSize().width / 2 - 30, panel_kuning[i]->getContentSize().height / 2));
            nama_hewan_indonesia[i]->setColor(Color3B(93, 111, 118));
            nama_hewan_indonesia[i]->setScale(0.7);
            panel_kuning[i]->addChild(nama_hewan_indonesia[i]);
        }
        else if(poin >= 6)
        {
            nama_hewan_indonesia[i] = Label::createWithTTF("Anjing", "belajar/mengenal/Freude.otf", 40);
            nama_hewan_indonesia[i]->setString(__String::create(inggris[random_huruf[i]].c_str())->getCString());
            nama_hewan_indonesia[i]->setPosition(Vec2(panel_kuning[i]->getContentSize().width / 2 - 30, panel_kuning[i]->getContentSize().height / 2));
            nama_hewan_indonesia[i]->setColor(Color3B(93, 111, 118));
            nama_hewan_indonesia[i]->setScale(0.7);
            panel_kuning[i]->addChild(nama_hewan_indonesia[i]);
        }


    }
    panel_kuning[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y + 150));
    panel_kuning[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 50));
    panel_kuning[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 250));

    for (int i = 0; i < 3; ++i) {


        panel_hijau[i] = Sprite::create("bermain/puzzle/Pannel_kanan.png");
        panel_hijau[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_hijau[i]->setScale(0);
        panel_hijau[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1.5)));
        this->addChild(panel_hijau[i]);
    }
    for (int i = 0; i < 3; ++i) {
        hewan[i] = Sprite::create(__String::createWithFormat("%s.png", hewann[random_huruf[i]].c_str())->getCString());
        hewan[i]->setAnchorPoint(Point(0.5, 0.5));
        hewan[i]->setScale(0.09);
        if(poin == 0)
             {
                 if(i == 0){
                     hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                     panel_hijau[1]->addChild(hewan[i]);
                 }
                 else if(i == 1)
                 {
                     hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                     panel_hijau[2]->addChild(hewan[i]);
                 }
                 else if(i == 2)
                 {
                     hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                     panel_hijau[0]->addChild(hewan[i]);
                 }
             };
        if(poin == 1)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
        };
        if(poin == 2)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
        };
        if(poin == 3)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
        };
        if(poin == 4)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
        };
        if(poin == 5)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
        };
        if(poin == 6)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
        };
        if(poin == 7)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
        };
        if(poin == 8)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
        };
        if(poin == 9)
        {
            if(i == 0){
                hewan[i]->setPosition(Vec2(panel_hijau[1]->getContentSize().width / 2 + 10, panel_hijau[1]->getContentSize().height / 2));
                panel_hijau[1]->addChild(hewan[i]);
            }
            else if(i == 1)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[0]->getContentSize().width / 2 + 10, panel_hijau[0]->getContentSize().height / 2));
                panel_hijau[0]->addChild(hewan[i]);
            }
            else if(i == 2)
            {
                hewan[i]->setPosition(Vec2(panel_hijau[2]->getContentSize().width / 2 + 10, panel_hijau[2]->getContentSize().height / 2));
                panel_hijau[2]->addChild(hewan[i]);
            }
        };
    }
    panel_hijau[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 150));
    panel_hijau[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 50));
    panel_hijau[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 250));
}
void game_puzzle::game_selesai() {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();


    this->stopAllActions();

    resolusi = Sprite::create("final_resolusi/p.png");
    resolusi->setScale(0.8);
    resolusi->setPosition(
            Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(resolusi);

    auto l_poin = Label::create("", "belajar/mengenal/Freude.otf", 70);
    l_poin->setString(__String::createWithFormat("%i", poin)->getCString());
    l_poin->setPosition(Vec2(resolusi->getContentSize().width / 2 + 100,
                             resolusi->getContentSize().height / 2 - 245));
    l_poin->setTextColor(Color4B::WHITE);
    resolusi->addChild(l_poin);

    bintang_1 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120,
                                resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_1);

    bintang_2 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_2->setPosition(
            Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_2);

    bintang_3 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120,
                                resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_3);

    bintang_kuning_1 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_1->setScale(0);
    bintang_kuning_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120,
                                       resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_1);

    bintang_kuning_2 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_2->setScale(0);
    bintang_kuning_2->setPosition(
            Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_kuning_2);

    bintang_kuning_3 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_3->setScale(0);
    bintang_kuning_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120,
                                       resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_3);

    auto b_menu = Button::create("final_resolusi/b_menu.png");
    b_menu->setAnchorPoint(Point(0.5, 0.5));
    b_menu->setPosition(Vec2(resolusi->getContentSize().width / 2 + 270,
                             resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_menu);
    b_menu->setZoomScale(-0.1);
    b_menu->addClickEventListener([=](Ref *Sender) {
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(
                TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto b_restart = Button::create("final_resolusi/b_restart.png");
    b_restart->setAnchorPoint(Point(0.5, 0.5));
    b_restart->setPosition(Vec2(resolusi->getContentSize().width / 2 - 270,
                                resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_restart);
    b_restart->setZoomScale(-0.1);
    b_restart->addClickEventListener([=](Ref *Sender) {
        auto gr_scene = game_puzzle::createScene();
        Director::getInstance()->replaceScene(
                TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    if (poin == 0) {

    } else if (poin <= 3) {
        this->runAction(Sequence::create(DelayTime::create(0.6),
                                         CallFunc::create(
                                                 CC_CALLBACK_0(game_puzzle::fungsi_bintang, this,
                                                               0)), nullptr));
    } else if (poin >= 5 && poin <= 7) {
        this->runAction(Sequence::create(DelayTime::create(0.6),
                                         CallFunc::create(
                                                 CC_CALLBACK_0(game_puzzle::fungsi_bintang, this,
                                                               0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
                                         CallFunc::create(
                                                 CC_CALLBACK_0(game_puzzle::fungsi_bintang, this,
                                                               1)), nullptr));
    } else if (poin >= 8) {
        this->runAction(Sequence::create(DelayTime::create(0.6),
                                         CallFunc::create(
                                                 CC_CALLBACK_0(game_puzzle::fungsi_bintang, this,
                                                               0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
                                         CallFunc::create(
                                                 CC_CALLBACK_0(game_puzzle::fungsi_bintang, this,
                                                               1)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.8),
                                         CallFunc::create(
                                                 CC_CALLBACK_0(game_puzzle::fungsi_bintang, this,
                                                               2)), nullptr));
    }


}
void game_puzzle::getar()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    cocos2d::Device::vibrate(0.5f);

    float interval = 1 / 60;
    float duration = 0.5f;
    float speed = 5.0f;
    float magnitude = 5.f;

    this->runAction(ActionShake::create(duration, speed, magnitude));
};
void game_puzzle::particle(int x)
{
        auto visibleSize = Director::getInstance()->getVisibleSize();
        Vec2 origin = Director::getInstance()->getVisibleOrigin();

        if (x == 0)
        {

            auto m_emitter = ParticleSystemQuad::create("bintang_particle.plist");
            m_emitter->setVisible(true);
            m_emitter->setPosition(Vec2(visibleSize.width / 2 + origin.x - 220, visibleSize.height / 2 + origin.y + 150));
            this->addChild(m_emitter, 50);
            m_emitter->setScale(0.9);
        };
        if (x == 1)
        {

            auto m_emitter = ParticleSystemQuad::create("bintang_particle.plist");
            m_emitter->setVisible(true);
            m_emitter->setPosition(Vec2(visibleSize.width / 2 + origin.x - 220, visibleSize.height / 2 + origin.y - 50));
            this->addChild(m_emitter, 50);
            m_emitter->setScale(0.9);
        };
        if (x == 2)
        {

            auto m_emitter = ParticleSystemQuad::create("bintang_particle.plist");
            m_emitter->setVisible(true);
            m_emitter->setPosition(Vec2(visibleSize.width / 2 + origin.x - 220, visibleSize.height / 2 + origin.y - 250));
            this->addChild(m_emitter, 50);
            m_emitter->setScale(0.9);
        };


    };
void game_puzzle::fungsi_bintang(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        bintang_kuning_1->setScale(0);
        bintang_kuning_1->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_1 = ParticleSystemQuad::create("bintang_particle.plist");
        s_1->setVisible(true);
        this->addChild(s_1, 50);
        s_1->setPosition(ccp(resolusi->getPosition().x - 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");

        getar();
    }
    if (x == 1)
    {
        bintang_kuning_2->setScale(0);
        bintang_kuning_2->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_2 = ParticleSystemQuad::create("bintang_particle.plist");
        s_2->setVisible(true);
        this->addChild(s_2, 50);
        s_2->setPosition(ccp(resolusi->getPosition().x, resolusi->getPosition().y));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
    if (x == 2)
    {
        bintang_kuning_3->setScale(0);
        bintang_kuning_3->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_3 = ParticleSystemQuad::create("bintang_particle.plist");
        s_3->setVisible(true);
        this->addChild(s_3, 50);
        s_3->setPosition(ccp(resolusi->getPosition().x + 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
}
void game_puzzle::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
