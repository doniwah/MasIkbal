/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "homeplay.h"
#include "menu_pilih.h"
#include "pilihan_belajar.h"
#include "SimpleAudioEngine.h"
//code_tambahan
#if CC_TARGET_PLATFORM == CC_PLATFORM_IOS || CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
#include "cocos/platform/android/jni/JniLink.h"
#endif

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* homeplay::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = homeplay::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
void homeplay::untuk_bool()
{
    aktif = true;
}
bool homeplay::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event) {
    Point point_began = touch->getLocation();
    Rect rect_cowok = b_guru->getBoundingBox();

    if (aktif == true) {
        if (rect_cowok.containsPoint(point_began)) {
            aktif = false;
            anim_b_guru->play("Interaksi", true);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/erza/intro.mp3");
            this->runAction(Sequence::create(DelayTime::create(4.34),
                                             CallFunc::create(CC_CALLBACK_0(homeplay::diam, this)),
                                             nullptr));
            this->runAction(Sequence::create(DelayTime::create(4.34),
                                             CallFunc::create(CC_CALLBACK_0(homeplay::untuk_bool, this)),nullptr));
        }
    }
    return true;
}
void homeplay::diam()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    anim_b_guru->play("gerak", true);
}

void homeplay::bg_diam()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    anim_bg->play("diam", true);
}
// on "init" you need to initialize your instance
bool homeplay::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    aktif = true;

    bg = CSLoader::createNode("res/bg.csb");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 +  origin.y));
    this->addChild(bg);
    anim_bg = CSLoader::createTimeline("res/bg.csb");
    bg->runAction(anim_bg);
    anim_bg->play("buka_tutup", true);

    judul = Sprite::create("homeplay/judul_new.png");
    judul->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y + 150));
//    judul->runAction(RepeatForever::create(Sequence::create(MoveTo::create(2, Vec2(visibleSize.width / 2 + origin.x - 25, visibleSize.height / 2 + origin.y + 130)),
//        MoveTo::create(2, Vec2(visibleSize.width / 2 + origin.x + 25, visibleSize.height / 2 + origin.y + 130)), MoveTo::create(2, Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y + 150)), nullptr)));
    judul->runAction(RepeatForever::create(Sequence::create(RotateTo::create(3, 6),
                                           RotateTo::create(3, -6), nullptr)));
    this->addChild(judul);

    b_guru = CSLoader::createNode("res/bocil.csb");
    b_guru->setPosition(Vec2(visibleSize.width / 2 + origin.x - 800, visibleSize.height / 2 + origin.y - 200));
    this->addChild(b_guru);
    b_guru->setScale(0.7);
    anim_b_guru = CSLoader::createTimeline("res/bocil.csb");
    b_guru->runAction(anim_b_guru);
    anim_b_guru->play("gerak", true);

    b_play = Button::create("homeplay/button.png");
    b_play->setAnchorPoint(Point(0.5, 0));
    b_play->setPosition(Vec2(visibleSize.width / 2 + origin.x, origin.y + 50));
    b_play->setScale(1.1);
    b_play->runAction(RepeatForever::create(Sequence::create(ScaleTo::create(1.3, 1.3, 1.1),
                                            ScaleTo::create(1.3, 1.1, 1.3), nullptr)));
    this->addChild(b_play);
    b_play->setZoomScale(-0.1);
    b_play->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = menu_pilih::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.1, gr_scene, Color3B::WHITE));
        });



    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(homeplay::onTouchBegan, this);
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
    this->runAction(Sequence::create(DelayTime::create(1.65), CallFunc::create(CC_CALLBACK_0(homeplay::bg_diam, this)), nullptr));

    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/backsound.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intro.mp3");




    return true;
}

void homeplay::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
