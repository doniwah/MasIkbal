/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


#include "mengenal_hewan_inggris.h"
#include "mengenal_hewan_indonesia.h"
#include "mengenal_hewan_arab.h"
#include "coba.h"
#include "menu_pilih.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* mengenal_hewan_inggris::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = mengenal_hewan_inggris::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

const std::string name_hewan[] =
        {
                "hewan/anjeng",
                "hewan/babi",
                "hewan/belalang",
                "hewan/burung",
                "hewan/domba",
                "hewan/gagak",
                "hewan/gajah",
                "hewan/ikan",
                "hewan/kambing",
                "hewan/katak",
                "hewan/keledai",
                "hewan/kera",
                "hewan/kuda",
                "hewan/kutu",
                "hewan/laba_laba",
                "hewan/lalat",
                "hewan/lebah",
                "hewan/nyamuk",
                "hewan/puyuh",
                "hewan/rayap",
                "hewan/sapi",
                "hewan/semut",
                "hewan/serigala",
                "hewan/singa",
                "hewan/ular",
                "hewan/unta"
        };

const std::string indonesia[] =
        {
                "Anjing",
                "Babi",
                "Belalang",
                "Burung",
                "Domba",
                "Gagak",
                "Gajah",
                "Ikan",
                "Kambing",
                "Katak",
                "Keledai",
                "Kera",
                "Kuda",
                "Kutu",
                "Laba_laba",
                "Lalat",
                "Lebah",
                "Nyamuk",
                "Puyuh",
                "Rayap",
                "Sapi",
                "Semut",
                "Serigala",
                "Singa",
                "Ular",
                "Unta"
        };

const std::string inggris[] =
        {
                "dog",
                "pig",
                "grasshopper",
                "hupu",
                "sheep",
                "crow",
                "elephant",
                "fish",
                "goat",
                "frog",
                "donkey",
                "monkey",
                "horse",
                "louse",
                "spider",
                "fly",
                "bee",
                "musquito",
                "quail",
                "termite",
                "cow",
                "ant",
                "wolf",
                "lion",
                "snake",
                "camel"
        };
const std::string arab[] =
        {
                "teks_arab_hijau/hewan/anjing",
                "teks_arab_hijau/hewan/babi",
                "teks_arab_hijau/hewan/belalang",
                "teks_arab_hijau/hewan/burung_hupu",
                "teks_arab_hijau/hewan/domba",
                "teks_arab_hijau/hewan/gagak",
                "teks_arab_hijau/hewan/gajah",
                "teks_arab_hijau/hewan/ikan",
                "teks_arab_hijau/hewan/kambing",
                "teks_arab_hijau/hewan/katak",
                "teks_arab_hijau/hewan/keledai",
                "teks_arab_hijau/hewan/kera",
                "teks_arab_hijau/hewan/kuda",
                "teks_arab_hijau/hewan/kutu",
                "teks_arab_hijau/hewan/laba_laba",
                "teks_arab_hijau/hewan/lalat",
                "teks_arab_hijau/hewan/lebah",
                "teks_arab_hijau/hewan/nyamuk",
                "teks_arab_hijau/hewan/puyuh",
                "teks_arab_hijau/hewan/rayap",
                "teks_arab_hijau/hewan/sapi",
                "teks_arab_hijau/hewan/semut",
                "teks_arab_hijau/hewan/serigala",
                "teks_arab_hijau/hewan/singa",
                "teks_arab_hijau/hewan/ular",
                "teks_arab_hijau/hewan/unta"
        };

const std::string latin[] =
        {
                "kalbun",
                "khinziirun",
                "jaraadun",
                "hudhud",
                "maa'izun",
                "grab",
                "fiilun",
                "samakatun",
                "ghanamun",
                "dhifda'un",
                "himaarun",
                "qirdu",
                "hishaanun",
                "kamala",
                "‘ankabuutun",
                "dzubaabun",
                "nahlatun",
                "ba’uudhatun",
                "somani",
                "ardah",
                "baqaratun",
                "namlatun",
                "dzi`bun",
                "asadun",
                "tsu'baanun",
                "jamalun"
        };

const std::string sound[] =
        {
                "sound/hewan_inggris/dog",
                "sound/hewan_inggris/pig",
                "sound/hewan_inggris/grasshopper",
                "sound/hewan_inggris/hupi",
                "sound/hewan_inggris/sheep",
                "sound/hewan_inggris/crow",
                "sound/hewan_inggris/elephant",
                "sound/hewan_inggris/fish",
                "sound/hewan_inggris/goat",
                "sound/hewan_inggris/frog",
                "sound/hewan_inggris/donkey",
                "sound/hewan_inggris/monkey",
                "sound/hewan_inggris/horse",
                "sound/hewan_inggris/louse",
                "sound/hewan_inggris/spider",
                "sound/hewan_inggris/fly",
                "sound/hewan_inggris/bee",
                "sound/hewan_inggris/musquito",
                "sound/hewan_inggris/quail",
                "sound/hewan_inggris/termite",
                "sound/hewan_inggris/cow",
                "sound/hewan_inggris/ant",
                "sound/hewan_inggris/wolf",
                "sound/hewan_inggris/lion",
                "sound/hewan_inggris/snake",
                "sound/hewan_inggris/camel"
        };
// Print useful error message instead of segfaulting when files are not there.

void mengenal_hewan_inggris::ganti_hewan()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    log("sayur ke %i", hewan_ke);

    if (hewan_ke < 0)
    {
        hewan_ke = 25;
    }

    if (hewan_ke >= 26)
    {
        hewan_ke = 0;
    };

    hewan->setTexture(__String::createWithFormat("%s.png", name_hewan[hewan_ke].c_str())->getCString());
    hewan->setScale(0);
    hewan->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.35)));
    nama_hewan_indonesia->setString(__String::create(indonesia[hewan_ke].c_str())->getCString());
    nama_hewan_inggris->setString(__String::create(inggris[hewan_ke].c_str())->getCString());
    nama_hewan_arab->setTexture(__String::createWithFormat("%s.png", arab[hewan_ke].c_str())->getCString());
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[hewan_ke].c_str())->getCString());

    if (tombol_auto_aktif == true)
    {
        hewan_ke++;
    }

}
// on "init" you need to initialize your instance
bool mengenal_hewan_inggris::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/bg_hewan.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/mengenal_new/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    hewan = Sprite::create("hewan/anjeng.png");
    hewan->setScale(0);
    hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.35)));
    hewan->setPosition(Vec2(panel->getContentSize().width / 2 + 300, panel->getContentSize().height / 2));
    panel->addChild(hewan);

    panel_kecil_1 = Sprite::create("belajar/mengenal_new/abu_abu.png");
    panel_kecil_1->setPosition(Vec2(panel->getContentSize().width / 2 - 205, panel->getContentSize().height / 2 - 190));
    panel->addChild(panel_kecil_1);

    nama_hewan_inggris = Label::createWithTTF("Dog", "belajar/mengenal/Freude.otf", 80);
    nama_hewan_inggris->setScale(0);
    nama_hewan_inggris->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
    nama_hewan_inggris->setPosition(Vec2(panel->getContentSize().width / 2 - 220, panel->getContentSize().height / 2 + 20));
    nama_hewan_inggris->setColor(Color3B(87, 45, 255));
    nama_hewan_inggris->setScale(0.8);
    panel_kecil_1->addChild(nama_hewan_inggris);

    nama_hewan_indonesia = Label::createWithTTF("Anjing", "belajar/mengenal/Freude.otf", 50);
    nama_hewan_indonesia->setPosition(Vec2(panel_kecil_1->getContentSize().width / 2 - 150, panel_kecil_1->getContentSize().height / 2));
    nama_hewan_indonesia->setColor(Color3B(93, 111, 118));
    nama_hewan_indonesia->setScale(0.7);
    panel_kecil_1->addChild(nama_hewan_indonesia);

    nama_hewan_arab = Sprite::create("teks_arab_hijau/hewan/anjing.png");
    nama_hewan_arab->setPosition(Vec2(panel_kecil_1->getContentSize().width / 2 + 150, panel_kecil_1->getContentSize().height / 2));
    nama_hewan_arab->setColor(Color3B(93, 111, 150));
    nama_hewan_arab->setScale(0.15);
    panel_kecil_1->addChild(nama_hewan_arab);

    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        hewan_ke++;
        ganti_hewan();
        });

    b_left = Button::create("stage/b_next.png");
    b_left->setRotation(180);
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        hewan_ke--;
        ganti_hewan();
        });


    auto b_inggris = Button::create("stage/b_inggris_new.png");
    b_inggris->setAnchorPoint(Point(1, 1));
    b_inggris->setScale(1.45);
    b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_inggris);
    b_inggris->setZoomScale(-0.1);
    b_inggris->addClickEventListener([=](Ref* Sender) {
        /*auto gr_scene = hijaiyah::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));*/
        });

    auto b_arab = Button::create("stage/B_arab_new_off.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setScale(1.45);
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = mengenal_hewan_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_indo = Button::create("stage/B_indo_new_off.png");
    b_indo->setAnchorPoint(Point(1, 1));
    b_indo->setScale(1.45);
    b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
    this->addChild(b_indo);
    b_indo->setZoomScale(-0.1);
    b_indo->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = mengenal_hewan_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });


    b_back = Button::create("stage/menu_pilihan/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hewan_inggris/dog.mp3");

    return true;
}
void mengenal_hewan_inggris::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}

