/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "mengeja_nyamuk_inggris.h"
#include "mengeja_lebah_inggris.h"
#include "mengeja_rayap_inggris.h"
#include "menu_pilih.h"
#include "coba.h"
#include "hewan_arab/mengeja_burung_arab.h"
#include "SimpleAudioEngine.h"
//code_tambahan

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;



Scene* mengeja_nyamuk_inggris::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = mengeja_nyamuk_inggris::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
const std::string nama_burung[] =
{
    "belajar/huruf_indonesia/merah/m",
    "belajar/huruf_indonesia/merah/u",
    "belajar/huruf_indonesia/ijo/s",
    "belajar/huruf_indonesia/ijo/q",
    "belajar/huruf_indonesia/merah/u",
    "belajar/huruf_indonesia/merah/i",
    "belajar/huruf_indonesia/ijo/t",
    "belajar/huruf_indonesia/ijo/o"
};
// on "init" you need to initialize your instance
bool mengeja_nyamuk_inggris::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    langit = Sprite::create("belajar/mengenal/bg.png");
    langit->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(langit, -1);

    panel = Sprite::create("belajar/mengeja/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    gambar = Sprite::create("hewan/nyamuk.png");
    gambar->setScale(0.35);
    gambar->setPosition(Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2));
    gambar->runAction(Sequence::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2 + 30)),
        EaseBounceOut::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2))), nullptr));

    panel->addChild(gambar);

    b_kanan = Button::create("belajar/mengenal/b_next.png");
    b_kanan->setAnchorPoint(Point(0.5, 0.5));
    b_kanan->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_kanan);
    b_kanan->setZoomScale(-0.1);
    b_kanan->addClickEventListener([=](Ref*Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        this->stopAllActions();
        this->removeAllChildren();
        auto shopLayer = mengeja_rayap_inggris::create();
        this->addChild(shopLayer);
    });

    auto b_arab = Button::create("belajar/mengenal/b_arab.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 20, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengeja_burung_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_kiri = Button::create("belajar/mengenal/B_preview.png");
    b_kiri->setAnchorPoint(Point(0.5, 0.5));
    b_kiri->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_kiri);
    b_kiri->setZoomScale(-0.1);
    b_kiri->addClickEventListener([=](Ref* Sender) {
        this->stopAllActions();
        this->removeAllChildren();
        auto shopLayer = mengeja_lebah_inggris::create();
        this->addChild(shopLayer);
        });

    b_back = Button::create("belajar/mengenal/B_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    burung();

    return true;
}


void mengeja_nyamuk_inggris::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
void mengeja_nyamuk_inggris::burung()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 8; i++)
    {
        domba[i] = Sprite::create(__String::createWithFormat("%s.png", nama_burung[i].c_str())->getCString());
        this->addChild(domba[i]);
    }
    domba[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 300));
    domba[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 250, visibleSize.height / 2 + origin.y - 300));
    domba[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 150, visibleSize.height / 2 + origin.y - 300));
    domba[3]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 300));
    domba[4]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 50, visibleSize.height / 2 + origin.y - 300));
    domba[5]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 150, visibleSize.height / 2 + origin.y - 300));
    domba[6]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 250, visibleSize.height / 2 + origin.y - 300));
    domba[7]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 300));
    this->runAction(Sequence::create(DelayTime::create(1.5),
        CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 0)), nullptr));
}
void mengeja_nyamuk_inggris::animasi_burung(int x) {
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        domba[0]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/m.mp3");

        s_1 = ParticleSystemQuad::create("bintang_particle.plist");
        s_1->setVisible(true);
        this->addChild(s_1, 50);
        s_1->setPosition(ccp(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 1)), nullptr));
    }
    if (x == 1)
    {
        domba[1]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x - 250, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x - 250, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/u.mp3");
        
        s_2 = ParticleSystemQuad::create("bintang_particle.plist");
        s_2->setVisible(true);
        this->addChild(s_2, 50);
        s_2->setPosition(ccp(visibleSize.width / 2 + origin.x - 250, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 2)), nullptr));
    }
    if (x == 2)
    {
        domba[2]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x - 150, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x - 150, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/s.mp3");
        
        s_3 = ParticleSystemQuad::create("bintang_particle.plist");
        s_3->setVisible(true);
        this->addChild(s_3, 50);
        s_3->setPosition(ccp(visibleSize.width / 2 + origin.x - 150, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 3)), nullptr));
    }
    if (x == 3)
    {
        domba[3]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/q.mp3");
       
        s_4 = ParticleSystemQuad::create("bintang_particle.plist");
        s_4->setVisible(true);
        this->addChild(s_4, 50);
        s_4->setPosition(ccp(visibleSize.width / 2 + origin.x - 50, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 4)), nullptr));
    }
    if (x == 4)
    {
        domba[4]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x + 50, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x + 50, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/u.mp3");

        s_5 = ParticleSystemQuad::create("bintang_particle.plist");
        s_5->setVisible(true);
        this->addChild(s_5, 50);
        s_5->setPosition(ccp(visibleSize.width / 2 + origin.x + 50, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 5)), nullptr));
    }
    if (x == 5)
    {
        domba[5]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x + 150, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x + 150, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/i.mp3");

        s_6 = ParticleSystemQuad::create("bintang_particle.plist");
        s_6->setVisible(true);
        this->addChild(s_6, 50);
        s_6->setPosition(ccp(visibleSize.width / 2 + origin.x + 150, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 6)), nullptr));
    }
    if (x == 6)
    {
        domba[6]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x + 250, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x + 250, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/t.mp3");

        s_7 = ParticleSystemQuad::create("bintang_particle.plist");
        s_7->setVisible(true);
        this->addChild(s_7, 50);
        s_7->setPosition(ccp(visibleSize.width / 2 + origin.x + 250, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_nyamuk_inggris::animasi_burung, this, 7)), nullptr));
    }
    if (x == 7)
    {
        domba[7]->runAction(Sequence::create(MoveTo::create(0.5, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 280)),
            EaseBounceOut::create(MoveTo::create(1, Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 300))), nullptr));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/o.mp3");

        s_8 = ParticleSystemQuad::create("bintang_particle.plist");
        s_8->setVisible(true);
        this->addChild(s_8, 50);
        s_8->setPosition(ccp(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 290));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        /*this->runAction(Sequence::create(DelayTime::create(1.5),
            CallFunc::create(CC_CALLBACK_0(mengeja_gajah_inggris::animasi_burung, this, 7)), nullptr));*/
    }
}