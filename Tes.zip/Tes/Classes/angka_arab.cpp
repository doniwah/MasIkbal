﻿/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


#include "angka_arab.h"
#include "angka_indonesia.h"
#include "angka_inggris.h"
#include "mengenal_buah_inggris.h"
#include "mengenal_buah_arab.h"
#include "mengenal_hewan_inggris.h"
#include "pilihan_belajar.h"
#include "menu_pilih.h"
#include "coba.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* angka_arab::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = angka_arab::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

const std::string name_buah[] =
{
        "belajar/angka/1",
        "belajar/angka/2",
        "belajar/angka/3",
        "belajar/angka/4",
        "belajar/angka/5",
        "belajar/angka/6",
        "belajar/angka/7",
        "belajar/angka/8",
        "belajar/angka/9",
        "belajar/angka/10"
};

const std::string indonesia[] =
{
        "Satu",
        "Dua",
        "Tiga",
        "Empat",
        "Lima",
        "Enam",
        "Tujuh",
        "Delapan",
        "Sembilan",
        "Sepuluh",
};
const std::string angka[] =
        {
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
        };
const std::string inggris[] =
{
                "One",
                "Two ",
                "Three",
                "Four",
                "Five ",
                "Six",
                "Seven",
                "Eight ",
                "Nine",
                "Ten"
};
const std::string latin[] =
{
        "Waahidun",
        "Itsnaani",
        "Tsalaatsatun",
        "Arba'atun",
        "Khamsatun",
        "Sittatun",
        "Sab'atun",
        "Tsamaaniyatun",
        "Tis'atun",
        "'asyratu",
};

const std::string sound[] =
{
        "sound/angka/arab/wahidun",
        "sound/angka/arab/itsnani",
        "sound/angka/arab/salasatun",
        "sound/angka/arab/arbaatun",
        "sound/angka/arab/arbaatun",
        "sound/angka/arab/khamsatun",
        "sound/angka/arab/sittatun",
        "sound/angka/arab/sab'atun",
        "sound/angka/arab/samaniatun",
        "sound/angka/arab/tis'atun",
        "sound/angka/arab/asyiratun"
};
// Print useful error message instead of segfaulting when files are not there.

void angka_arab::ganti_hewan()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    log("sayur ke %i", hewan_ke);

    if (hewan_ke < 0)
    {
        hewan_ke = 9;
    }

    if (hewan_ke >= 10)
    {
        hewan_ke = 0;
    };


    hewan->setTexture(__String::createWithFormat("%s.png", name_buah[hewan_ke].c_str())->getCString());
    hewan->setScale(0);
    hewan->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1)));
    nama_hewan_indonesia->setString(__String::create(indonesia[hewan_ke].c_str())->getCString());
    l_angka->setString(__String::create(angka[hewan_ke].c_str())->getCString());
    nama_hewan_inggris->setString(__String::create(inggris[hewan_ke].c_str())->getCString());
    nama_hewan_arab->setString(__String::create(latin[hewan_ke].c_str())->getCString());
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[hewan_ke].c_str())->getCString());

    if (tombol_auto_aktif == true)
    {
        hewan_ke++;
    }
}
// on "init" you need to initialize your instance
bool angka_arab::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/bg_buah.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/mengenal_new/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    hewan = Sprite::create("belajar/angka/1.png");
    hewan->setScale(0);
    hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.9)));
    hewan->setPosition(Vec2(panel->getContentSize().width / 2 + 300, panel->getContentSize().height / 2));
    panel->addChild(hewan);

    panel_kecil_1 = Sprite::create("belajar/mengenal_new/abu_abu.png");
    panel_kecil_1->setPosition(Vec2(panel->getContentSize().width / 2 - 205, panel->getContentSize().height / 2 - 190));
    panel->addChild(panel_kecil_1);

    l_angka = Label::createWithTTF("1", "belajar/mengenal/Freude.otf", 230);
    l_angka->setScale(0);
    l_angka->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
    l_angka->setPosition(Vec2(panel->getContentSize().width / 2 - 220, panel->getContentSize().height / 2 + 65));
    l_angka->setColor(Color3B(5, 77, 40));
    panel_kecil_1->addChild(l_angka);

    nama_hewan_arab = Label::createWithTTF("Waahidun", "belajar/mengenal/Freude.otf", 50);
    nama_hewan_arab->setPosition(Vec2(panel->getContentSize().width / 2 - 220, panel->getContentSize().height / 2 - 70));
    nama_hewan_arab->setColor(Color3B(5, 77, 40));
    nama_hewan_arab->setScale(0.7);
    panel_kecil_1->addChild(nama_hewan_arab);

    nama_hewan_inggris = Label::createWithTTF("One", "belajar/mengenal/Freude.otf", 50);
    nama_hewan_inggris->setPosition(Vec2(panel_kecil_1->getContentSize().width / 2 + 150, panel_kecil_1->getContentSize().height / 2));
    nama_hewan_inggris->setColor(Color3B(93, 111, 118));
    nama_hewan_inggris->setScale(0.7);
    panel_kecil_1->addChild(nama_hewan_inggris);

    nama_hewan_indonesia = Label::createWithTTF("Satu", "belajar/mengenal/Freude.otf", 40);
    nama_hewan_indonesia->setPosition(Vec2(panel_kecil_1->getContentSize().width / 2 - 150, panel_kecil_1->getContentSize().height / 2));
    nama_hewan_indonesia->setColor(Color3B(93, 111, 118));
    panel_kecil_1->addChild(nama_hewan_indonesia);




    

    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        hewan_ke++;
        ganti_hewan();
        });

    b_left = Button::create("stage/b_next.png");
    b_left->setRotation(180);
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        hewan_ke--;
        ganti_hewan();
        });

    //b_auto = Button::create("belajar/huruf_indonesia/b_auto_off.png");
    //b_auto->setAnchorPoint(Point(1, 1));
    //b_auto->setPosition(Vec2(visibleSize.width + origin.x - 20, visibleSize.height + origin.y - 35));
    //this->addChild(b_auto);
    //b_auto->setZoomScale(-0.1);
    //b_auto->addClickEventListener([=](Ref* Sender) {
        //CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        //if (tombol_auto_aktif == false) {
            //tombol_auto_aktif = true;
            //b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_on.png");
            //this->runAction(RepeatForever::create(Sequence::create(
                //CallFunc::create(CC_CALLBACK_0(mengenal_buah_indonesia::ganti_hewan, this)), DelayTime::create(1.5), nullptr)));
       // }
        //else if (tombol_auto_aktif == true)
        {
            //tombol_auto_aktif = false;
            //b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_off.png");
            //this->stopAllActions();
        //}
        //});

            auto b_inggris = Button::create("stage/b_inggris_new_off.png");
            b_inggris->setAnchorPoint(Point(1, 1));
            b_inggris->setScale(1.45);
            b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
            this->addChild(b_inggris);
            b_inggris->setZoomScale(-0.1);
            b_inggris->addClickEventListener([=](Ref* Sender) {
                auto gr_scene = angka_inggris::createScene();
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
            });

            auto b_indo = Button::create("stage/B_indo_new_off.png");
            b_indo->setAnchorPoint(Point(1, 1));
            b_indo->setScale(1.45);
            b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
            this->addChild(b_indo);
            b_indo->setZoomScale(-0.1);
            b_indo->addClickEventListener([=](Ref* Sender) {
                auto gr_scene = angka_indonesia::createScene();
                Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
            });

            auto b_arab = Button::create("stage/b_arab_new.png");
            b_arab->setAnchorPoint(Point(1, 1));
            b_arab->setScale(1.45);
            b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
            this->addChild(b_arab);
            b_arab->setZoomScale(-0.1);
            b_arab->addClickEventListener([=](Ref* Sender) {
                //auto gr_scene = hijaiyah::createScene();
                //Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
            });


    b_back = Button::create("stage/menu_pilihan/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    //CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_indonesia/anggur.mp3");

    return true;
}}
void angka_arab::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
};