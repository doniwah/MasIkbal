﻿/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


#include "mengenal_buah_inggris.h"
#include "mengenal_buah_indonesia.h"
#include "mengenal_buah_arab.h"
#include "mengenal_hewan_inggris.h"
#include "pilihan_belajar.h"
#include "menu_pilih.h"
#include "coba.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* mengenal_buah_inggris::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = mengenal_buah_inggris::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

const std::string name_buah[] =
        {
                "tanaman/anggur",
                "tanaman/basil",
                "tanaman/bawang_merah",
                "tanaman/bawang_putih",
                "tanaman/buah_sidr",
                "tanaman/buah_tin",
                "tanaman/delima",
                "tanaman/gandum",
                "tanaman/jahe",
                "tanaman/kurma",
                "tanaman/labu",
                "tanaman/sawi",
                "tanaman/siwak",
                "tanaman/timun",
                "tanaman/zaitun"
        };

const std::string indonesia[] =
        {
                "Anggur",
                "Basil",
                "Bawang Merah",
                "Bawang Putih",
                "Buah Sidr",
                "Buah Tin",
                "Delima",
                "Gandum",
                "Jahe",
                "Kurma",
                "Labu",
                "Sawi",
                "Siwak",
                "Timun",
                "Zaitun"
        };

const std::string inggris[] =
        {
                "grape",
                "basil ",
                "Shallot",
                "onion",
                "Sidr ",
                "figs",
                "pomegranate",
                "Wheat ",
                "ginger",
                "date",
                "pumpkin",
                "mustard",
                "miswak",
                "cucumber",
                "olive"
        };
const std::string latin[] =
        {
                "teks_arab_hijau/tanaman/anggur",
                "teks_arab_hijau/tanaman/basil",
                "teks_arab_hijau/tanaman/bawang_merah",
                "teks_arab_hijau/tanaman/bawang_putih",
                "teks_arab_hijau/tanaman/widara",
                "teks_arab_hijau/tanaman/tin",
                "teks_arab_hijau/tanaman/delima",
                "teks_arab_hijau/tanaman/gandum",
                "teks_arab_hijau/tanaman/jahe",
                "teks_arab_hijau/tanaman/kurma",
                "teks_arab_hijau/tanaman/labu",
                "teks_arab_hijau/tanaman/sawi",
                "teks_arab_hijau/tanaman/miswak",
                "teks_arab_hijau/tanaman/timun",
                "teks_arab_hijau/tanaman/zaitun"
        };

const std::string sound[] =
        {
                "sound/buah_inggris/grape",
                "sound/buah_inggris/basil",
                "sound/buah_inggris/shallot",
                "sound/buah_inggris/garlic",
                "sound/buah_inggris/sidr",
                "sound/buah_inggris/figs",
                "sound/buah_inggris/pormagranate",
                "sound/buah_inggris/weth",
                "sound/buah_inggris/ginger",
                "sound/buah_inggris/date ersa",
                "sound/buah_inggris/pumpkin",
                "sound/buah_inggris/mustard",
                "sound/buah_inggris/miswak_nggris",
                "sound/buah_inggris/cucumber",
                "sound/buah_inggris/olive erza"
        };
// Print useful error message instead of segfaulting when files are not there.

void mengenal_buah_inggris::ganti_hewan()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    log("sayur ke %i", hewan_ke);

    if (hewan_ke < 0)
    {
        hewan_ke = 14;
    }

    if (hewan_ke >= 15)
    {
        hewan_ke = 0;
    };


    hewan->setTexture(__String::createWithFormat("%s.png", name_buah[hewan_ke].c_str())->getCString());
    hewan->setScale(0);
    hewan->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.35)));
    nama_hewan_indonesia->setString(__String::create(indonesia[hewan_ke].c_str())->getCString());
    nama_hewan_inggris->setString(__String::create(inggris[hewan_ke].c_str())->getCString());
    nama_hewan_arab->setTexture(__String::createWithFormat("%s.png", latin[hewan_ke].c_str())->getCString());
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[hewan_ke].c_str())->getCString());


    if (tombol_auto_aktif == true)
    {
        hewan_ke++;
    }
}
// on "init" you need to initialize your instance
bool mengenal_buah_inggris::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/bg_buah.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/mengenal_new/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    hewan = Sprite::create("hewan/anjeng.png");
    hewan->setScale(0);
    hewan->runAction(EaseBackOut::create(ScaleTo::create(1, 0.35)));
    hewan->setPosition(Vec2(panel->getContentSize().width / 2 + 300, panel->getContentSize().height / 2));
    panel->addChild(hewan);

    panel_kecil_1 = Sprite::create("belajar/mengenal_new/abu_abu.png");
    panel_kecil_1->setPosition(Vec2(panel->getContentSize().width / 2 - 205, panel->getContentSize().height / 2 - 190));
    panel->addChild(panel_kecil_1);

    nama_hewan_inggris = Label::createWithTTF("grape", "belajar/mengenal/Freude.otf", 80);
    nama_hewan_inggris->setScale(0);
    nama_hewan_inggris->runAction(EaseBackOut::create(ScaleTo::create(1, 1)));
    nama_hewan_inggris->setPosition(Vec2(panel->getContentSize().width / 2 - 220, panel->getContentSize().height / 2 + 20));
    nama_hewan_inggris->setColor(Color3B(87, 45, 255));
    nama_hewan_inggris->setScale(0.8);
    panel_kecil_1->addChild(nama_hewan_inggris);

    nama_hewan_indonesia = Label::createWithTTF("Anggur", "belajar/mengenal/Freude.otf", 50);
    nama_hewan_indonesia->setPosition(Vec2(panel_kecil_1->getContentSize().width / 2 - 150, panel_kecil_1->getContentSize().height / 2));
    nama_hewan_indonesia->setColor(Color3B(93, 111, 118));
    nama_hewan_indonesia->setScale(0.7);
    panel_kecil_1->addChild(nama_hewan_indonesia);

    nama_hewan_arab = Sprite::create("teks_arab_hijau/tanaman/anggur.png");
    nama_hewan_arab->setPosition(Vec2(panel_kecil_1->getContentSize().width / 2 + 150, panel_kecil_1->getContentSize().height / 2));
    nama_hewan_arab->setColor(Color3B(93, 111, 150));
    nama_hewan_arab->setScale(0.15);
    panel_kecil_1->addChild(nama_hewan_arab);

    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        hewan_ke++;
        ganti_hewan();
        });

    b_left = Button::create("stage/b_next.png");
    b_left->setRotation(180);
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        hewan_ke--;
        ganti_hewan();
        });

    //b_auto = Button::create("belajar/huruf_indonesia/b_auto_off.png");
    //b_auto->setAnchorPoint(Point(1, 1));
    //b_auto->setPosition(Vec2(visibleSize.width + origin.x - 20, visibleSize.height + origin.y - 35));
    //this->addChild(b_auto);
    //b_auto->setZoomScale(-0.1);
    //b_auto->addClickEventListener([=](Ref* Sender) {
    //    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
    //    if (tombol_auto_aktif == false) {
    //        tombol_auto_aktif = true;
    //        b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_on.png");
    //        this->runAction(RepeatForever::create(Sequence::create(
    //            CallFunc::create(CC_CALLBACK_0(mengenal_buah_inggris::ganti_hewan, this)), DelayTime::create(1.5), nullptr)));
    //    }
    //    else if (tombol_auto_aktif == true)
    //    {
    //        tombol_auto_aktif = false;
    //        b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_off.png");
    //        this->stopAllActions();
    //    }
    //    });

    auto b_inggris = Button::create("stage/b_inggris_new.png");
    b_inggris->setAnchorPoint(Point(1, 1));
    b_inggris->setScale(1.45);
    b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_inggris);
    b_inggris->setZoomScale(-0.1);
    b_inggris->addClickEventListener([=](Ref* Sender) {
        /*auto gr_scene = hijaiyah::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));*/
        });

    auto b_arab = Button::create("stage/B_arab_new_off.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setScale(1.45);
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = mengenal_buah_arab::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_indo = Button::create("stage/B_indo_new_off.png");
    b_indo->setAnchorPoint(Point(1, 1));
    b_indo->setScale(1.45);
    b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
    this->addChild(b_indo);
    b_indo->setZoomScale(-0.1);
    b_indo->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = mengenal_buah_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });


    b_back = Button::create("stage/menu_pilihan/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/buah_inggris/grape.mp3");



    return true;
}
void mengenal_buah_inggris::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}

