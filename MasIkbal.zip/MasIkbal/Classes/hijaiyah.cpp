/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "hijaiyah.h"
#include "abjad.h"
#include "indonesia.h"
#include "coba.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* hijaiyah::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = hijaiyah::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
const std::string name_huruf[] =
{
    "belajar/Mengenal_huruf/Huruf_hijaiyah/alif",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ba",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ta",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/sa",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ja",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ha'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/kha'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/dal",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/dzal",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ra'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/za'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/sin",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/syin",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/shad",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/dad",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/tha",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/zha",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ain",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ghain",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/fa'",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/qaf",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/kaf",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/lam",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/mim",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/nun",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/waw",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ha",
    "belajar/Mengenal_huruf/Huruf_hijaiyah/ya"
};

const std::string sound[] =
{
    "sound/hijaiyah/1",
    "sound/hijaiyah/2",
    "sound/hijaiyah/3",
    "sound/hijaiyah/4",
    "sound/hijaiyah/5",
    "sound/hijaiyah/6",
    "sound/hijaiyah/7",
    "sound/hijaiyah/8",
    "sound/hijaiyah/9",
    "sound/hijaiyah/10",
    "sound/hijaiyah/11",
    "sound/hijaiyah/12",
    "sound/hijaiyah/13",
    "sound/hijaiyah/14",
    "sound/hijaiyah/15",
    "sound/hijaiyah/16",
    "sound/hijaiyah/17",
    "sound/hijaiyah/18",
    "sound/hijaiyah/19",
    "sound/hijaiyah/20",
    "sound/hijaiyah/21",
    "sound/hijaiyah/22",
    "sound/hijaiyah/23",
    "sound/hijaiyah/24",
    "sound/hijaiyah/25",
    "sound/hijaiyah/26",
    "sound/hijaiyah/27",
    "sound/hijaiyah/28"
};

void hijaiyah::ganti_huruf()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (huruf_ke < 0)
    {
        huruf_ke = 27;
    }

    if (huruf_ke >= 28)
    {
        huruf_ke = 0;
    };

    if (huruf_ke == 0)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 1)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 2)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 3)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 4)
    {
        object->setScale(0.25);
    }
    if (huruf_ke == 5)
    {
        object->setScale(0.25);
    }
    if (huruf_ke == 6)
    {
        object->setScale(0.25);
    }
    if (huruf_ke == 7)
    {
        object->setScale(0.45);
    }
    if (huruf_ke == 8)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 9)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 10)
    {
        object->setScale(0.35);
    }
    if (huruf_ke == 11)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 12)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 13)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 14)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 15)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 16)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 17)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 18)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 19)
    {
        object->setScale(0.35);
    }
    if (huruf_ke == 20)
    {
        object->setScale(0.35);
    }
    if (huruf_ke == 21)
    {
        object->setScale(0.35);
    }  
    if (huruf_ke == 22)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 23)
    {
        object->setScale(0.3);
    }
    if (huruf_ke == 24)
    {
        object->setScale(0.35);
    }
    if (huruf_ke == 25)
    {
        object->setScale(0.4);
    }
    if (huruf_ke == 26)
    {
        object->setScale(0.5);
    }
    if (huruf_ke == 27)
    {
        object->setScale(0.4);
    }

    object->setTexture(__String::createWithFormat("%s.png", name_huruf[huruf_ke].c_str())->getCString());
    object->setPosition(Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2));
    object->runAction(Sequence::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2 + 30)),
        EaseBounceOut::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2))), nullptr));
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[huruf_ke].c_str())->getCString());

    if (tombol_auto_aktif == true)
    {
        huruf_ke++;
    }


}
// on "init" you need to initialize your instance
bool hijaiyah::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/huruf_indonesia/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/huruf_indonesia/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    object = Sprite::create("belajar/Mengenal_huruf/Huruf_hijaiyah/alif.png");
    object->setPosition(Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2));
    object->setScale(0.4);
    object->runAction(Sequence::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2 + 30)),
        EaseBounceOut::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2))), nullptr));
    panel->addChild(object);

    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        huruf_ke++;
        ganti_huruf();
        });

    b_left = Button::create("stage/b_next.png");
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setRotation(180);
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        huruf_ke--;
        ganti_huruf();
        });

    b_auto = Button::create("belajar/huruf_indonesia/b_auto_off.png");
    b_auto->setAnchorPoint(Point(1, 1));
    b_auto->setPosition(Vec2(visibleSize.width + origin.x - 20, visibleSize.height + origin.y - 35));
    this->addChild(b_auto);
    b_auto->setZoomScale(-0.1);
    b_auto->addClickEventListener([=](Ref* Sender) {
        if (tombol_auto_aktif == false) {
            tombol_auto_aktif = true;
            b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_on.png");
            this->runAction(RepeatForever::create(Sequence::create(
                CallFunc::create(CC_CALLBACK_0(hijaiyah::ganti_huruf, this)), DelayTime::create(1.5), nullptr)));
        }
        else if (tombol_auto_aktif == true)
        {
            tombol_auto_aktif = false;
            b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_off.png");
            this->stopAllActions();
        }
        });


    b_inggris = Button::create("stage/b_inggris_new_off.png");
    b_inggris->setAnchorPoint(Point(1, 1));
    b_inggris->setScale(1.45);
    b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_inggris);
    b_inggris->setZoomScale(-0.1);
    b_inggris->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = abjad::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_indo = Button::create("stage/B_indo_new_off.png");
    b_indo->setAnchorPoint(Point(1, 1));
    b_indo->setScale(1.45);
    b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
    this->addChild(b_indo);
    b_indo->setZoomScale(-0.1);
    b_indo->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_arab = Button::create("stage/b_arab_new.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setScale(1.45);
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        //auto gr_scene = hijaiyah::createScene();
        //Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });



    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/hijaiyah/1.mp3");
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk belajar hijaiyah.mp3");

    b_back = Button::create("belajar/huruf_indonesia/B_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    
    return true;
}


void hijaiyah::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
