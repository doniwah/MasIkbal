/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


#include "pilihan_belajar.h"
#include "KAPITAL_ARAB.h"
#include "buah_indonesia/mengeja_anggur_indonesia.h"
#include "menu_pilih.h"
#include "abjad.h"
#include "indonesia.h"
#include "mengenal_buah_indonesia.h"
#include "mengenal_hewan_indonesia.h"
#include "hijaiyah.h"
#include "hewan_indonesia/mengeja_babi_indonesia.h"
#include "mengenal_hewan_arab.h"
#include "mengenal_buah_arab.h"
#include "KAPITAL_INGGRIS.h"
#include "SimpleAudioEngine.h"
#include "homeplay.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* pilihan_belajar::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = pilihan_belajar::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

// Print useful error message instead of segfaulting when files are not there.

const std::string name_huruf[] =
{
    "stage/pilihan_menu_belajar/button_new/b_huruf",
    "stage/pilihan_menu_belajar/button_new/B_huruf_benda",
    "stage/pilihan_menu_belajar/button_new/B_mengeja_hewan",
    "stage/pilihan_menu_belajar/button_new/B_mengeja_buah",
    "stage/pilihan_menu_belajar/button_new/B_mengenal_hewan",
    "stage/pilihan_menu_belajar/button_new/B_mengenal_buah"
};
// on "init" you need to initialize your instance
bool pilihan_belajar::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("stage/bg_baru.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/mengeja/pannel.png");
    panel->setScale(1.5);
    panel->setOpacity(0);
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

 
    auto panel_3 = Sprite::create("stage/pannel.png");
    panel_3->setOpacity(0);
    panel_3->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel_3);

    auto scr_objek = ScrollView::create();
    scr_objek->setDirection(ScrollView::Direction::HORIZONTAL);
    scr_objek->setContentSize(Size(2000, 800));
    scr_objek->setInnerContainerSize(Size((565 * (6 + 10)) - scr_objek->getContentSize().width - 280, 0));
    scr_objek->setAnchorPoint(Point(0.5, 0.5));
    scr_objek->setPosition(Vec2(panel_3->getPosition()));
    scr_objek->setBounceEnabled(true);
    scr_objek->setClippingEnabled(true);
    scr_objek->setSwallowTouches(false);
    this->addChild(scr_objek, 99);
    scr_objek->setScrollBarOpacity(0);

    for (int i = 0; i < 6; i++)
    {
        button[i] = Button::create(__String::createWithFormat("%s.png", name_huruf[i].c_str())->getCString());
        button[i]->setPosition(Vec2(1000 + ((button[i]->getContentSize().width + 500) * i),
            (scr_objek->getInnerContainerSize().height - 400) - (i % 6)));
        scr_objek->addChild(button[i]);
        button[i]->setZoomScale(-0.1);
    }
    button[0]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = abjad::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));        });
    button[1]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = KAPITAL_ARAB::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    button[2]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");

        auto gr_scene = mengeja_babi_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    button[3]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengeja_anggur_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    button[4]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengenal_hewan_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    button[5]->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = mengenal_buah_indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    b_back = Button::create("stage/menu_pilihan/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = menu_pilih::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    return true;
}


void pilihan_belajar::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = menu_pilih::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
