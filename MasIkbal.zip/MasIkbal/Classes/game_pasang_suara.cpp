/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "game_pasang_suara.h"
#include "menu_pilih.h"
#include "cocos/platform/CCDevice.h"
#include "ActionShake.h"
#include "pilihan_belajar.h"
#include "SimpleAudioEngine.h"
#include "coba_2.h"
#include "pilihan_bermain.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* game_pasang_suara::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = game_pasang_suara::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
void game_pasang_suara::random()
{
    get_rand_hewan[3] = RandomHelper::random_int(0, 20);

    if (get_rand_hewan[0] == get_rand_hewan[1])
    {
        get_rand_hewan[1] = RandomHelper::random_int(0, 20);
        log("ada nilai yang sama");
        random();
    };
    if (get_rand_hewan[1] == get_rand_hewan[2])
    {
        get_rand_hewan[2] = RandomHelper::random_int(0, 20);
        log("nilai kedua ada yang sama");
        random();
    };
    if (get_rand_hewan[0] == get_rand_hewan[2])
    {
        get_rand_hewan[2] = RandomHelper::random_int(0, 20);
        log("ada nilai ketiga yang sama");
        random();
    }
}

const std::string nama_hewan[] =
{
    "hewan/babi",
    "hewan/belalang",
    "hewan/burung",
    "hewan/domba",
    "hewan/gagak",
    "hewan/gajah",
    "hewan/ikan",
    "hewan/katak",
    "hewan/keledai",
    "hewan/kera",
    "hewan/kuda",
    "hewan/laba_laba",
    "hewan/lalat",
    "hewan/lebah",
    "hewan/nyamuk",
    "hewan/rayap",
    "hewan/sapi",
    "hewan/semut",
    "hewan/serigala",
    "hewan/singa",
    "hewan/ular",
    "hewan/unta"
};

const std::string suara_hewan[] =
{
    "sound/hewan_indonesia/babi",
    "sound/hewan_indonesia/belalang",
    "sound/hewan_indonesia/burung hupu",
    "sound/hewan_indonesia/domba",
    "sound/hewan_indonesia/gagak",
    "sound/hewan_indonesia/gajah",
    "sound/hewan_indonesia/ikan",
    "sound/hewan_indonesia/katak",
    "sound/hewan_indonesia/keledai",
    "sound/hewan_indonesia/kera",
    "sound/hewan_indonesia/kuda",
    "sound/hewan_indonesia/labalaba",
    "sound/hewan_indonesia/lalat",
    "sound/hewan_indonesia/lebah",
    "sound/hewan_indonesia/nyamuk",
    "sound/hewan_indonesia/rayap",
    "sound/hewan_indonesia/sapi",
    "sound/hewan_indonesia/semut",
    "sound/hewan_indonesia/serigala",
    "sound/hewan_indonesia/singa",
    "sound/hewan_indonesia/ular",
    "sound/hewan_indonesia/unta"
};

bool game_pasang_suara::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event)
{
    point_began = touch->getLocation();

    b_1 = b_suara[0]->getBoundingBox();
    b_2 = b_suara[1]->getBoundingBox();
    b_3 = b_suara[2]->getBoundingBox();

    if (deteksi == 1)
    {
        if (b_1.containsPoint(point_began))
        {
            b_berhasil = false;
            drag = 0;
            b_suara[0]->setScale(0.9);
            b_suara[0]->runAction(ScaleTo::create(0.08, 1));
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_rand_hewan[0]].c_str())->getCString());
            log("buah di touch began");
        }
        else if (b_2.containsPoint(point_began))
        {
            b_berhasil = false;
            b_suara[1]->setScale(0.9);
            b_suara[1]->runAction(ScaleTo::create(0.08, 1));
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_rand_hewan[1]].c_str())->getCString());
            drag = 1;
            log("buah di touch began");
        }
        else if (b_3.containsPoint(point_began))
        {
            b_berhasil = false;
            b_suara[2]->setScale(0.9);
            b_suara[2]->runAction(ScaleTo::create(0.08, 1));
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", suara_hewan[get_rand_hewan[2]].c_str())->getCString());
            drag = 2;
            log("buah di touch began");
        }
    }
    return true;
}

void game_pasang_suara::onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* event)
{
    point_moved = touch->getLocation();
        if (drag == 0) {
            b_suara[0]->setPosition(point_moved);
        }
        else if (drag == 1) {
            b_suara[1]->setPosition(point_moved);
        }
        else if (drag == 2) {
            b_suara[2]->setPosition(point_moved);
        };
}

void game_pasang_suara::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event)
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    //Button
    b_1 = b_suara[0]->getBoundingBox();
    b_2 = b_suara[1]->getBoundingBox();
    b_3 = b_suara[2]->getBoundingBox();
    // Panel
    r_panel = panel_2->getBoundingBox();

    if (deteksi == 1)
    {
        if (b_1.intersectsRect(r_panel) && deteksi == 1)
        {
            Size visibleSize = Director::getInstance()->getVisibleSize();
            Vec2 origin = Director::getInstance()->getVisibleOrigin();
            if (0 == jawaban_benar) {
                deteksi = 0;
                deteksi_sentuh = false;
                log("%b", deteksi_sentuh);
                object->setScale(0);
                b_suara[0]->setScale(0);
                b_suara[1]->setScale(0);
                b_suara[2]->setScale(0);
                berhasil++;
                b_suara[0]->runAction(EaseBackOut::create(MoveTo::create(1, Vec2(panel->getPosition().x, panel->getPosition().y))));
            }
            else {
                deteksi_sentuh = false;
                deteksi = 0;
                object->setScale(0);
                b_suara[0]->setScale(0);
                b_suara[1]->setScale(0);
                b_suara[2]->setScale(0);
                jika_benar(4);
            }
        }
        else {
            b_suara[0]->runAction(EaseBackOut::create(MoveTo::create(0.6, Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y + 200))));
        }
        if (b_2.intersectsRect(r_panel) && deteksi == 1)
        {
            Size visibleSize = Director::getInstance()->getVisibleSize();
            Vec2 origin = Director::getInstance()->getVisibleOrigin();
            if (1 == jawaban_benar) {
                deteksi_sentuh = false;
                deteksi = 0;
                log("ini %i", deteksi);
                object->setScale(0);
                b_suara[0]->setScale(0);
                b_suara[1]->setScale(0);
                b_suara[2]->setScale(0);
                b_suara[1]->runAction(EaseBackOut::create(MoveTo::create(1, Vec2(panel->getPosition().x, panel->getPosition().y))));
                berhasil++;
            }
            else {
                deteksi_sentuh = false;
                deteksi = 0;
                object->setScale(0);
                b_suara[0]->setScale(0);
                b_suara[1]->setScale(0);
                b_suara[2]->setScale(0);

                jika_benar(4);
            }
        }
        else {
            b_suara[1]->runAction(EaseBackOut::create(MoveTo::create(0.6, Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y))));
        }
        if (b_3.intersectsRect(r_panel) && deteksi == 1)
        {
            Size visibleSize = Director::getInstance()->getVisibleSize();
            Vec2 origin = Director::getInstance()->getVisibleOrigin();
            if (2 == jawaban_benar) {
                deteksi_sentuh = false;
                deteksi = 0;
                berhasil++;
                log("ini %i", deteksi);
                object->setScale(0);
                b_suara[0]->setScale(0);
                b_suara[1]->setScale(0);
                b_suara[2]->setScale(0);
                b_suara[2]->runAction(EaseBackOut::create(MoveTo::create(1, Vec2(panel->getPosition().x, panel->getPosition().y))));
            }
            else {
                deteksi_sentuh = false;
                deteksi = 0;
                object->setScale(0);
                b_suara[0]->setScale(0);
                b_suara[1]->setScale(0);
                b_suara[2]->setScale(0);

                jika_benar(4);
            }
        }
        else {
            b_suara[2]->runAction(EaseBackOut::create(MoveTo::create(0.6, Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y - 200))));
        }
    }
    if (deteksi == 0) {
        if (berhasil == 1) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
            this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
        }
        else if (berhasil == 2) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else if (berhasil == 3) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
        else  if (berhasil == 4) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(3);
        }
        else if (berhasil == 5) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
        }
        else  if (berhasil == 6) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else if (berhasil == 7) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
        else   if (berhasil == 8) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(3);
        }
        else   if (berhasil == 9) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
        }
        else  if (berhasil == 10) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else  if (berhasil == 11) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
        else if (berhasil == 12) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(3);
        }
        else if (berhasil == 13) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
        }
        else if (berhasil == 14) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else  if (berhasil == 15) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
        else if (berhasil == 16) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(3);
        }
        else  if (berhasil == 17) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
        }
        else  if (berhasil == 18) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else if (berhasil == 19) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
        else if (berhasil == 20) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(3);
        }
        else  if (berhasil == 21) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
        }
        else if (berhasil == 22) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else if (berhasil == 23) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
        else  if (berhasil == 24) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(3);
        }
        else if (berhasil == 25) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(0);
        }
        else if (berhasil == 26) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(1);
        }
        else if (berhasil == 27) {
            i_poin++;
            l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
            jika_benar(2);
        }
    }
    

    drag = 99;
    log("touch end");
};
// on "init" you need to initialize your instance
void game_pasang_suara::untuk_manggil()
{
    this->runAction(RepeatForever::create(Sequence::create(DelayTime::create(1),
        CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_waktu, this)), nullptr)));

}
void game_pasang_suara::khusus()
{
    deteksi = 1;
}
bool game_pasang_suara::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("bermain/pasang_suara/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("bermain/pasang_suara/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x - 200, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    panel_2 = Sprite::create("stage/kotakdalem.png");
    panel_2->setColor(Color3B::BLACK);
    panel_2->setScaleX(1.8);
    panel_2->setOpacity(0);
    panel_2->setPosition(Vec2(panel->getPosition().x,panel->getPosition().y));
    this->addChild(panel_2);

    waktu = Sprite::create("bermain/pasang_suara/Pannel_waktu.png");
    waktu->setAnchorPoint(Point(0.5, 1));
    waktu->setPosition(Vec2(visibleSize.width / 2 + origin.x - 150, visibleSize.height + origin.y - 30));
    this->addChild(waktu);

    poin = Sprite::create("bermain/pasang_suara/Pannel_bintang.png");
    poin->setAnchorPoint(Point(0.5, 1));
    poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 150, visibleSize.height + origin.y - 30));
    this->addChild(poin);

    l_waktu = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    l_waktu->setString(__String::createWithFormat("%i", i_waktu)->getCString());
    l_waktu->setPosition(Vec2(waktu->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
    l_waktu->setTextColor(Color4B::BLACK);
    waktu->addChild(l_waktu);

    l_poin = Label::createWithTTF("60", "fonts/notif.ttf", 30);
    l_poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
    l_poin->setPosition(Vec2(poin->getContentSize().width / 2 + 40, waktu->getContentSize().height / 2));
    l_poin->setTextColor(Color4B::BLACK);
    poin->addChild(l_poin);

    b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk pasangkan suara yg ssuaj.mp3");

    this->runAction(Sequence::create(DelayTime::create(3), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
    this->runAction(Sequence::create(DelayTime::create(3), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::untuk_manggil, this)), nullptr));

    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(game_pasang_suara::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(game_pasang_suara::onTouchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(game_pasang_suara::onTouchEnded, this);
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);


    return true;
}
void game_pasang_suara::jika_benar(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        if (deteksi_sentuh == false)
        {
            bagus = Sprite::create("ekspresi/bagus.png");
            bagus->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            bagus->setScale(0);
            bagus->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(bagus);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/bagus.mp3");
            this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
            deteksi_sentuh = true;
        }
    }
    else if (x == 1)
    {
        if (deteksi_sentuh == false) {

            pintar = Sprite::create("ekspresi/pintar.png");
            pintar->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            pintar->setScale(0);
            pintar->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(pintar);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pintar.mp3");
            this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
            deteksi_sentuh = true;
        }
    }
    else if (x == 2)
    {
        if (deteksi_sentuh == false)
        {
            pandai = Sprite::create("ekspresi/Pandai.png");
            pandai->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            pandai->setScale(0);
            pandai->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(pandai);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/pndai.mp3");
            this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
            deteksi_sentuh = true;
        }
    }
    else if (x == 3)
    {
        if (deteksi_sentuh == false) {
            berhsil = Sprite::create("ekspresi/berhasil.png");
            berhsil->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            berhsil->setScale(0);
            berhsil->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(berhsil);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/berhasil.mp3");
            this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
            deteksi_sentuh = true;
        }

    }
    else  if (x == 4)
    {
        if (deteksi_sentuh == false) {


            salah = Sprite::create("ekspresi/yahh.png");
            salah->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
            salah->setScale(0);
            salah->runAction(Sequence::create(EaseBackOut::create(ScaleTo::create(0.8, 0.45)),
                EaseBackIn::create(ScaleTo::create(0.8, 0)), nullptr));
            this->addChild(salah);
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yaaah.mp3");
            this->runAction(Sequence::create(DelayTime::create(1.7), CallFunc::create(CC_CALLBACK_0(game_pasang_suara::muncul, this)), nullptr));
            deteksi_sentuh = true;
        }
    };
}
void game_pasang_suara::muncul(){
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    log("nilai deteksi = %i", deteksi);
    if (deteksi == 0)
    {

    
    for (int i = 0; i < 3; i++)
    {

        get_rand_hewan[i] = RandomHelper::random_int(0, 20);

        if (get_rand_hewan[0] == get_rand_hewan[1])
        {
            get_rand_hewan[1] = RandomHelper::random_int(0, 20);
            log("ada nilai yang sama");
            random();
        };
        if (get_rand_hewan[1] == get_rand_hewan[2])
        {
            get_rand_hewan[2] = RandomHelper::random_int(0, 20);
            log("nilai kedua ada yang sama");
            random();
        };
        if (get_rand_hewan[0] == get_rand_hewan[2])
        {
            get_rand_hewan[2] = RandomHelper::random_int(0, 20);
            log("ada nilai ketiga yang sama");
            random();
        }

        b_suara[i] = Sprite::create("bermain/pasang_suara/b_suara.png");
        b_suara[i]->setAnchorPoint(Point(0.5, 0.5));
        b_suara[i]->setScale(0);
        b_suara[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1)));
        this->addChild(b_suara[i]);

    }       

    jawaban_benar = RandomHelper::random_int(0, 2);

    object = Sprite::create(__String::createWithFormat("%s.png", nama_hewan[get_rand_hewan[jawaban_benar]].c_str())->getCString());
    object->setScale(0);
    object->runAction(EaseBackOut::create(ScaleTo::create(0.8, 0.3)));
    object->setPosition(Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2 + 30));
    panel->addChild(object);

    b_suara[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y + 200));
    b_suara[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y));
    b_suara[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y - 200));
    log("jawaban_benar %i", jawaban_benar);
    log("jawaban_benar %i", get_rand_hewan[0]);
    log("jawaban_benar %i", get_rand_hewan[1]);
    log("jawaban_benar %i", get_rand_hewan[2]);
    deteksi = 1;
    }


}

void game_pasang_suara::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
void game_pasang_suara::fungsi_waktu()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 1; i++)
    {
        if (i_waktu == 0)
        {
            b_suara[0]->setScale(0);
            b_suara[1]->setScale(0);
            b_suara[2]->setScale(0);
            object->setScale(0);
            break;
        }
        i_waktu--;
        l_waktu->setString(__String::createWithFormat("%i", i_waktu)->getCString());

        if (i_waktu == 0)
        {
            /*fungsi_menang();*/
            game_selesai();
        }
    }
}
void game_pasang_suara::game_selesai()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    resolusi = Sprite::create("final_resolusi/p.png");
    resolusi->setScale(0.8);
    resolusi->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(resolusi);

    auto poin = Label::create("", "belajar/mengenal/Freude.otf", 70);
    poin->setString(__String::createWithFormat("%i", i_poin)->getCString());
    poin->setPosition(Vec2(resolusi->getContentSize().width / 2 + 100, resolusi->getContentSize().height / 2 - 245));
    poin->setTextColor(Color4B::WHITE);
    resolusi->addChild(poin);

    bintang_1 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_1);

    bintang_2 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_2->setPosition(Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_2);

    bintang_3 = Sprite::create("final_resolusi/bintang_abu.png");
    bintang_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_3);

    bintang_kuning_1 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_1->setScale(0);
    bintang_kuning_1->setPosition(Vec2(resolusi->getContentSize().width / 2 - 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_1);

    bintang_kuning_2 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_2->setScale(0);
    bintang_kuning_2->setPosition(Vec2(resolusi->getContentSize().width / 2, resolusi->getContentSize().height / 2));
    resolusi->addChild(bintang_kuning_2);

    bintang_kuning_3 = Sprite::create("final_resolusi/bintang.png");
    bintang_kuning_3->setScale(0);
    bintang_kuning_3->setPosition(Vec2(resolusi->getContentSize().width / 2 + 120, resolusi->getContentSize().height / 2 - 50));
    resolusi->addChild(bintang_kuning_3);

    auto b_menu = Button::create("final_resolusi/b_menu.png");
    b_menu->setAnchorPoint(Point(0.5, 0.5));
    b_menu->setPosition(Vec2(resolusi->getContentSize().width / 2 + 270, resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_menu);
    b_menu->setZoomScale(-0.1);
    b_menu->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_restart = Button::create("final_resolusi/b_restart.png");
    b_restart->setAnchorPoint(Point(0.5, 0.5));
    b_restart->setPosition(Vec2(resolusi->getContentSize().width / 2 - 270, resolusi->getContentSize().height / 2 - 300));
    resolusi->addChild(b_restart);
    b_restart->setZoomScale(-0.1);
    b_restart->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = game_pasang_suara::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    if (i_poin == 0)
    {

    }
    else if (i_poin <= 5)
    {
    this->runAction(Sequence::create(DelayTime::create(0.6),
        CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_bintang, this, 0)), nullptr));
    }
    else if (i_poin >= 5)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
            CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_bintang, this, 0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
            CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_bintang, this, 1)), nullptr));
    }
    else if (i_poin >= 10)
    {
        this->runAction(Sequence::create(DelayTime::create(0.6),
            CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_bintang, this, 0)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(1.2),
            CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_bintang, this, 1)), nullptr));
        this->runAction(Sequence::create(DelayTime::create(2.4),
            CallFunc::create(CC_CALLBACK_0(game_pasang_suara::fungsi_bintang, this, 2)), nullptr));
    }
}
void game_pasang_suara::getar()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    cocos2d::Device::vibrate(0.5f);

    float interval = 1 / 60;
    float duration = 0.5f;
    float speed = 5.0f;
    float magnitude = 5.f;

    this->runAction(ActionShake::create(duration, speed, magnitude));
}
void game_pasang_suara::fungsi_bintang(int x)
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (x == 0)
    {
        bintang_kuning_1->setScale(0);
        bintang_kuning_1->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_1 = ParticleSystemQuad::create("bintang_particle.plist");
        s_1->setVisible(true);
        this->addChild(s_1, 50);
        s_1->setPosition(ccp(resolusi->getPosition().x - 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");

        getar();
    }   
    if (x == 1)
    {
        bintang_kuning_2->setScale(0);
        bintang_kuning_2->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_2 = ParticleSystemQuad::create("bintang_particle.plist");
        s_2->setVisible(true);
        this->addChild(s_2, 50);
        s_2->setPosition(ccp(resolusi->getPosition().x, resolusi->getPosition().y));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }  
    if (x == 2)
    {
        bintang_kuning_3->setScale(0);
        bintang_kuning_3->runAction(EaseBackOut::create(ScaleTo::create(0.08, 1)));

        auto s_3 = ParticleSystemQuad::create("bintang_particle.plist");
        s_3->setVisible(true);
        this->addChild(s_3, 50);
        s_3->setPosition(ccp(resolusi->getPosition().x + 120, resolusi->getPosition().y - 50));
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("cring.mp3");
        getar();
    }
}