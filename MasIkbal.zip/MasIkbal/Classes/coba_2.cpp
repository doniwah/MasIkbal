/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "coba_2.h"
#include "menu_pilih.h"
#include "pilihan_belajar.h"
#include "game_pasang_suara.h"
#include "game_tebak_kata.h"
#include "game_puzzle.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* coba_2::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = coba_2::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
// on "init" you need to initialize your instance
bool coba_2::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto bg = Sprite::create("stage/bg_baru.png");
    bg->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    auto button = Button::create( "stage/pilihan_bermain/b_menghubungkan_kata.png" );
    button->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button->setAnchorPoint(Point(0.5, 0.5));
    button->setScale(0.7);

    auto button_2 = Button::create( "stage/pilihan_bermain/b_pasang_suara.png" );
    button_2->setPosition(Vec2( visibleSize.width / 2 + origin.x , visibleSize.height / 2 + origin.y));
    button_2->setAnchorPoint(Point(0.5, 0.5));
    button_2->setScale(0.7);
    button_2->setZoomScale(-0.1);
    button_2->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = game_pasang_suara::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_3 = Button::create("stage/pilihan_bermain/b_puzzle.png");
    button_3->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button_3->setAnchorPoint(Point(0.5, 0.5));
    button_3->setScale(0.7);
    button_3->setZoomScale(-0.1);
    button_3->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = game_puzzle::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });


    auto button_4 = Button::create("stage/pilihan_bermain/b_tebak_arti.png");
    button_4->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    button_4->setAnchorPoint(Point(0.5, 0.5));
    button_4->setScale(0.7);

    auto button_5 = Button::create("stage/pilihan_bermain/b_tebak_kata.png");
    button_5->setPosition(Vec2( visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    button_5->setAnchorPoint(Point(0.5, 0.5));
    button_5->setScale(0.7);
    button_5->setZoomScale(-0.1);
    button_5->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = game_tebak_kata::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto button_6 = Button::create("stage/pilihan_bermain/b_mewarnai.png");
    button_6->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    button_6->setAnchorPoint(Point(0.5, 0.5));
    button_6->setScale(0.7);

    auto pageView = PageView::create();
    pageView->setAnchorPoint( Point( 0.5, 0.5));
    pageView->setTouchEnabled( true );
    pageView->setContentSize( Size (1024, 1024));
    pageView->setPosition(Vec2( visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));

    auto layout1 = Layout::create();
    layout1->setContentSize( Size (1024, 1024));
    layout1->addChild( button );
    layout1->addChild( button_2 );

    auto layout2 = Layout::create();
    layout2->setContentSize( Size (1024, 1024));
    layout2->addChild( button_3 );
    layout2->addChild( button_4 );

    auto layout3 = Layout::create();
    layout3->setContentSize( Size (1024, 1024));
    layout3->addChild( button_5 );
    layout3->addChild( button_6 );

    pageView->addPage( layout1 );
    pageView->insertPage( layout3, 1);
    pageView->insertPage( layout2, 2);

    pageView->addEventListener(CC_CALLBACK_2(coba_2::pageViewEvent, this));

    this->addChild(pageView);


    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        if (pageView->getCurPageIndex() == 0)
        {
            page = 1;
            b_left->setScale(1);
            pageView->setCurPageIndex(1);
            button_5->setScale(0);
            button_5->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_6->setScale(0);
            button_6->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if (pageView->getCurPageIndex() == 1)
        {
            page = 2;
            pageView->setCurPageIndex(2);
            button_3->setScale(0);
            button_3->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_4->setScale(0);
            button_4->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
            b_next->setScale(0);
        }
        });

    b_left = Button::create("stage/b_next.png");
    b_left->setRotation(180);
    b_left->setScale(0);
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        if (pageView->getCurPageIndex() == 2)
        {
            b_next->setScale(1);
            page = 1;
            pageView->setCurPageIndex(1);
            button_6->setScale(0);
            button_6->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button_5->setScale(0);
            button_5->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
        }
        else if (pageView->getCurPageIndex() == 1)
        {
            page = 0;
            pageView->setCurPageIndex(0);
            button_2->setScale(0);
            button_2->runAction(EaseBackOut::create(ScaleTo::create(0.2, 0.7)));
            button->setScale(0);
            button->runAction(EaseBackOut::create(ScaleTo::create(0.4, 0.7)));
            log("%i", pageView->getCurPageIndex());
            b_left->setScale(0);
        }
        });

    auto b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2( origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender){
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = menu_pilih::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });


    return true;
}


void coba_2::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}

void coba_2::pageViewEvent(Ref* sender, ui::PageView::EventType type)
{
    ui::PageView* pageView = dynamic_cast<ui::PageView*>(sender);
    switch (type)
    {
    case ui::PageView::EventType::TURNING:


        log("%i", pageView->getCurPageIndex());

            if(pageView->getCurPageIndex() == 0)
            {
                b_left->setScale(0);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 1){
                b_left->setScale(1);
                b_next->setScale(1);
            }
            else if(pageView->getCurPageIndex() == 2){
                b_left->setScale(1);
                b_next->setScale(0);
            }

        break;

    default:
        break;
    }
}

