/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "menghubungkan_kata.h"
#include "menu_pilih.h"
#include "pilihan_bermain.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* menghubungkan_kata::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = menghubungkan_kata::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

// on "init" you need to initialize your instance
bool menghubungkan_kata::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Layer::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/mengenal/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    b_waktu = Sprite::create("bermain/tarik_garis/Pannel_waktu.png");
    b_waktu->setAnchorPoint(Point(0.5, 1));
    b_waktu->setPosition(Vec2(visibleSize.width / 2 + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_waktu);

    b_poin = Sprite::create("bermain/tarik_garis/Pannel_bintang.png");
    b_poin->setAnchorPoint(Point(0.5, 1));
    b_poin->setPosition(Vec2(visibleSize.width / 2 + origin.x + 250, visibleSize.height + origin.y - 20));
    this->addChild(b_poin);

    panel_kiri = Sprite::create("bermain/tarik_garis/pannel_biru.png");
    panel_kiri->setScale(1.3);
    panel_kiri->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y + 200));
    this->addChild(panel_kiri);

    panel_kiri_1 = Sprite::create("bermain/tarik_garis/pannel_biru.png");
    panel_kiri_1->setScale(1.3);
    panel_kiri_1->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y));
    this->addChild(panel_kiri_1);

    panel_kiri_2 = Sprite::create("bermain/tarik_garis/pannel_biru.png");
    panel_kiri_2->setScale(1.3);
    panel_kiri_2->setPosition(Vec2(visibleSize.width / 2 + origin.x - 350, visibleSize.height / 2 + origin.y - 200));
    this->addChild(panel_kiri_2);

    panel_kanan = Sprite::create("bermain/tarik_garis/pannel_hijau.png");
    panel_kanan->setScale(1.3);
    panel_kanan->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y + 200));
    this->addChild(panel_kanan);

    panel_kanan_1 = Sprite::create("bermain/tarik_garis/pannel_hijau.png");
    panel_kanan_1->setScale(1.3);
    panel_kanan_1->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y));
    this->addChild(panel_kanan_1);

    panel_kanan_2 = Sprite::create("bermain/tarik_garis/pannel_hijau.png");
    panel_kanan_2->setScale(1.3);
    panel_kanan_2->setPosition(Vec2(visibleSize.width / 2 + origin.x + 350, visibleSize.height / 2 + origin.y - 200));
    this->addChild(panel_kanan_2);

    b_back = Button::create("bermain/tarik_garis/B_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = pilihan_bermain::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    
    return true;
}


void menghubungkan_kata::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = pilihan_bermain::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
