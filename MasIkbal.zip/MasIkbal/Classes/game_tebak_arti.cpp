/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "game_tebak_arti.h"
#include "menu_pilih.h"
#include "pilihan_belajar.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* game_tebak_arti::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = game_tebak_arti::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

const std::string nama_hewan[] =
{
    "hewan/babi",
    "hewan/belalang",
    "hewan/burung",
    "hewan/domba",
    "hewan/gagak",
    "hewan/gajah",
    "hewan/ikan",
    "hewan/katak",
    "hewan/keledai",
    "hewan/kera",
    "hewan/kuda",
    "hewan/laba_laba",
    "hewan/lalat",
    "hewan/lebah",
    "hewan/nyamuk",
    "hewan/rayap",
    "hewan/sapi",
    "hewan/semut",
    "hewan/serigala",
    "hewan/singa",
    "hewan/ular",
    "hewan/unta"
};

const std::string suara_hewan[] =
{
    "sound/hewan_indonesia/babi",
    "sound/hewan_indonesia/belalang",
    "sound/hewan_indonesia/burung hupu",
    "sound/hewan_indonesia/domba",
    "sound/hewan_indonesia/gagak",
    "sound/hewan_indonesia/gajah",
    "sound/hewan_indonesia/ikan",
    "sound/hewan_indonesia/katak",
    "sound/hewan_indonesia/keledai",
    "sound/hewan_indonesia/kera",
    "sound/hewan_indonesia/kuda",
    "sound/hewan_indonesia/labalaba",
    "sound/hewan_indonesia/lalat",
    "sound/hewan_indonesia/lebah",
    "sound/hewan_indonesia/nyamuk",
    "sound/hewan_indonesia/rayap",
    "sound/hewan_indonesia/sapi",
    "sound/hewan_indonesia/semut",
    "sound/hewan_indonesia/serigala",
    "sound/hewan_indonesia/singa",
    "sound/hewan_indonesia/ular",
    "sound/hewan_indonesia/unta"
};

// on "init" you need to initialize your instance
bool game_tebak_arti::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("bermain/pasang_suara/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("bermain/pasang_suara/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x - 200, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    object = Sprite::create("hewan/babi.png");
    object->setPosition(Vec2(panel->getContentSize() / 2));
    panel->addChild(object);

    for (int i = 0; i < 3; i++)
    {
        b_suara[i] = Button::create("bermain/pasang_suara/b_suara.png");
        b_suara[i]->setAnchorPoint(Point(0.5, 0.5));
        this->addChild(b_suara[i]);
        b_suara[i]->setZoomScale(0.1);
        b_suara[i]->addClickEventListener([=](Ref* Sender) {


            });
 

    }       b_suara[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y + 200));
    b_suara[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y));
    b_suara[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 400, visibleSize.height / 2 + origin.y - 200));

    b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        });

    return true;
}


void game_tebak_arti::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
