/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "game_puzzle.h"
#include "menu_pilih.h"
#include "pilihan_belajar.h"
#include "coba_2.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* game_puzzle::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = game_puzzle::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
const std::string arab[] =
{
        "teks_arab_hijau/hewan/anjing",
        "teks_arab_hijau/hewan/babi",
        "teks_arab_hijau/hewan/belalang",
        "teks_arab_hijau/hewan/burung_hupu",
        "teks_arab_hijau/hewan/domba",
        "teks_arab_hijau/hewan/gagak",
        "teks_arab_hijau/hewan/gajah",
        "teks_arab_hijau/hewan/ikan",
        "teks_arab_hijau/hewan/kambing",
        "teks_arab_hijau/hewan/katak",
        "teks_arab_hijau/hewan/keledai",
        "teks_arab_hijau/hewan/kera",
        "teks_arab_hijau/hewan/kuda",
        "teks_arab_hijau/hewan/kutu",
        "teks_arab_hijau/hewan/laba_laba",
        "teks_arab_hijau/hewan/lalat",
        "teks_arab_hijau/hewan/lebah",
        "teks_arab_hijau/hewan/nyamuk",
        "teks_arab_hijau/hewan/puyuh",
        "teks_arab_hijau/hewan/rayap",
        "teks_arab_hijau/hewan/sapi",
        "teks_arab_hijau/hewan/semut",
        "teks_arab_hijau/hewan/serigala",
        "teks_arab_hijau/hewan/singa",
        "teks_arab_hijau/hewan/ular",
        "teks_arab_hijau/hewan/unta"
};
const std::string indonesia[] =
{
        "Anjing",
        "Babi",
        "Belalang",
        "Burung",
        "Domba",
        "Gagak",
        "Gajah",
        "Ikan",
        "Kambing",
        "Katak",
        "Keledai",
        "Kera",
        "Kuda",
        "Kutu",
        "Laba-laba",
        "Lalat",
        "Lebah",
        "Nyamuk",
        "Puyuh",
        "Rayap",
        "Sapi",
        "Semut",
        "Serigala",
        "Singa",
        "Ular",
        "Unta"
};
const std::string hewann[] =
{
        "hewan/anjeng",
        "hewan/babi",
        "hewan/belalang",
        "hewan/burung",
        "hewan/domba",
        "hewan/gagak",
        "hewan/gajah",
        "hewan/ikan",
        "hewan/kambing",
        "hewan/katak",
        "hewan/keledai",
        "hewan/kera",
        "hewan/kuda",
        "hewan/kutu",
        "hewan/laba_laba",
        "hewan/lalat",
        "hewan/lebah",
        "hewan/nyamuk",
        "hewan/puyuh",
        "hewan/rayap",
        "hewan/sapi",
        "hewan/semut",
        "hewan/serigala",
        "hewan/singa",
        "hewan/ular",
        "hewan/unta"
};

bool game_puzzle::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event)
{
    point_began = touch->getLocation();

    b_1 = panel_hijau[0]->getBoundingBox();
    b_2 = panel_hijau[1]->getBoundingBox();
    b_3 = panel_hijau[2]->getBoundingBox();


    if (b_1.containsPoint(point_began))
    {
        drag = 0;
        log("1 buah di touch began");
    }
    else if (b_2.containsPoint(point_began))
    {
        drag = 1;
        log("2 buah di touch began");
    }
    else if (b_3.containsPoint(point_began))
    {
        drag = 2;
        log("3 buah di touch began");
    }
    return true;
}
void game_puzzle::onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* event)
{
    point_moved = touch->getLocation();
    if (drag == 0) {
        panel_hijau[0]->setPosition(point_moved);
    }
    else if (drag == 1) {
        panel_hijau[1]->setPosition(point_moved);
    }
    else if (drag == 2) {
        panel_hijau[2]->setPosition(point_moved);
    };
}
void game_puzzle::onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event)
{
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    point_ended = touch->getLocation();

    b_1 = panel_hijau[0]->getBoundingBox();
    b_2 = panel_hijau[1]->getBoundingBox();
    b_3 = panel_hijau[2]->getBoundingBox();
    // Panel
    a_1 = panel_kuning[0]->getBoundingBox();
    a_2 = panel_kuning[1]->getBoundingBox();
    a_3 = panel_kuning[2]->getBoundingBox();

    if (poin <= 3)
    {
        if (deteksi_sentuh[0] == true) {
            if (a_1.intersectsRect(b_1) && deteksi_sentuh[0] == true)
            {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 1");
                deteksi_sentuh[0] = false;
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 80, visibleSize.height / 2 + origin.y + 200)));
            }
            else
            {
                panel_hijau[0]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y + 200)));
            };
        }
        if (deteksi_sentuh[1] == true)
        {
            if (a_2.intersectsRect(b_2) && deteksi_sentuh[1] == true)
            {
                CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
                selesai++;
                log("yang berhasil 2");
                deteksi_sentuh[1] = false;
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 80, visibleSize.height / 2 + origin.y)));
            }
            else
            {
                panel_hijau[1]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y)));
            }
        };
        if (deteksi_sentuh[2] == true)
        {
        if (a_3.intersectsRect(b_3) && deteksi_sentuh[2] == true)
        {
            CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/star.mp3");
            selesai++;
            log("yang berhasil 3");
            deteksi_sentuh[2] = false;
            panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x - 80, visibleSize.height / 2 + origin.y - 200)));
        }
        else
        {
            panel_hijau[2]->runAction(MoveTo::create(0.4, Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y - 200)));
        }
        }
    };

    if (selesai == 3)
    {
        selesai = 0;
        panel_hijau[0]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_hijau[1]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_hijau[2]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_kuning[0]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_kuning[1]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        panel_kuning[2]->runAction(EaseBackIn::create(ScaleTo::create(0.8, 0)));
        this->runAction(Sequence::create(DelayTime::create(1), CallFunc::create(CC_CALLBACK_0(game_puzzle::muncul_indonesia, this)), nullptr));
    }

   
        
    drag == 99;
    log("touch end");
};
// on "init" you need to initialize your instance
bool game_puzzle::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 3; ++i) {
        deteksi_sentuh[i] = true;
    }


    bg = Sprite::create("bermain/puzzle/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    b_back = Button::create("stage/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
    });

    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(game_puzzle::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(game_puzzle::onTouchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(game_puzzle::onTouchEnded, this);
    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk main pzzle.mp3");

    this->runAction(Sequence::create(DelayTime::create(3), CallFunc::create(CC_CALLBACK_0(game_puzzle::muncul_indonesia, this)), nullptr));

    return true;
}
void game_puzzle::muncul_arab()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 3; ++i) {
        panel_kuning[i] = Sprite::create("bermain/puzzle/Pannel_kiri.png");
        panel_kuning[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_kuning[i]->setScale(1.1);
        this->addChild(panel_kuning[i]);

        huruf[i] = Sprite::create(__String::createWithFormat("%s.png", arab[i].c_str())->getCString());
        huruf[i]->setAnchorPoint(Point(0.5, 0.5));
        huruf[i]->setScale(0.1);
        huruf[i]->setPosition(Vec2(panel_kuning[i]->getContentSize().width / 2 - 20, panel_kuning[i]->getContentSize().height / 2));
        panel_kuning[i]->addChild(huruf[i]);

    }
    panel_kuning[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y + 200));
    panel_kuning[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y));
    panel_kuning[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y - 200));

    for (int i = 0; i < 3; ++i) {
        panel_hijau[i] = Sprite::create("bermain/puzzle/Pannel_kanan.png");
        panel_hijau[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_hijau[i]->setScale(1.1);
        this->addChild(panel_hijau[i]);

        hewan[i] = Sprite::create(__String::createWithFormat("%s.png", hewann[i].c_str())->getCString());
        hewan[i]->setAnchorPoint(Point(0.5, 0.5));
        hewan[i]->setScale(0.08);
        hewan[i]->setPosition(Vec2(panel_hijau[i]->getContentSize().width / 2 + 20, panel_hijau[i]->getContentSize().height / 2));
        panel_hijau[i]->addChild(hewan[i]);

    }
    panel_hijau[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y + 200));
    panel_hijau[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y));
    panel_hijau[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y - 200));
}

void game_puzzle::muncul_indonesia()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    for (int i = 0; i < 3; ++i) {
        deteksi_sentuh[i] = true;
    }

    for (int i = 0; i < 3; ++i) {

        random_huruf[i] = RandomHelper::random_int(0, 25);

        panel_kuning[i] = Sprite::create("bermain/puzzle/Pannel_kiri.png");
        panel_kuning[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_kuning[i]->setScale(0);
        panel_kuning[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1.1)));
        this->addChild(panel_kuning[i]);

        nama_hewan_indonesia[i] = Label::createWithTTF("Anjing", "belajar/mengenal/Freude.otf", 50);
        nama_hewan_indonesia[i]->setString(__String::create(indonesia[random_huruf[i]].c_str())->getCString());
        nama_hewan_indonesia[i]->setPosition(Vec2(panel_kuning[i]->getContentSize().width / 2 - 20, panel_kuning[i]->getContentSize().height / 2));
        nama_hewan_indonesia[i]->setColor(Color3B(93, 111, 118));
        nama_hewan_indonesia[i]->setScale(0.7);
        panel_kuning[i]->addChild(nama_hewan_indonesia[i]);

    }
    panel_kuning[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y + 200));
    panel_kuning[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y));
    panel_kuning[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y - 200));

    for (int i = 0; i < 3; ++i) {

        random_huruf[i] = random_huruf[i];

        panel_hijau[i] = Sprite::create("bermain/puzzle/Pannel_kanan.png");
        panel_hijau[i]->setAnchorPoint(Point(0.5, 0.5));
        panel_hijau[i]->setScale(0);
        panel_hijau[i]->runAction(EaseBackOut::create(ScaleTo::create(0.8, 1.1)));
        this->addChild(panel_hijau[i]);

        hewan[i] = Sprite::create(__String::createWithFormat("%s.png", hewann[random_huruf[i]].c_str())->getCString());
        hewan[i]->setAnchorPoint(Point(0.5, 0.5));
        hewan[i]->setScale(0.08);
        hewan[i]->setPosition(Vec2(panel_hijau[i]->getContentSize().width / 2 + 20, panel_hijau[i]->getContentSize().height / 2));
        panel_hijau[i]->addChild(hewan[i]);

    }
    panel_hijau[0]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y + 200));
    panel_hijau[1]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y));
    panel_hijau[2]->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y - 200));
}
    


void game_puzzle::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->end();
}
