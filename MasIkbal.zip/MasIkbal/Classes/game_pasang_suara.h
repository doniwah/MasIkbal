/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#ifndef __game_pasang_suara_H__
#define __game_pasang_suara_H__

#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "network/HttpClient.h"
#include "cocos/platform/CCDevice.h"

USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace tinyxml2;

class game_pasang_suara : public cocos2d::Layer
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(game_pasang_suara);
private:
    Sprite* bg;
    Sprite* panel;
    Sprite* object;
    Sprite* panel_2;
    Sprite* bagus;
    Sprite* pintar;
    Sprite* pandai;
    Sprite* berhsil;
    Sprite* salah;
    Sprite* waktu;
    Sprite* poin;
    Sprite* bintang_1;
    Sprite* bintang_2;
    Sprite* bintang_3;
    Sprite* bintang_kuning_1;
    Sprite* bintang_kuning_2;
    Sprite* bintang_kuning_3;

    Sprite* b_suara[3];
    Button* b_back;
    Label* l_waktu;
    Label* l_poin;

    int get_rand_hewan[3];
    int jawaban_benar;
    int drag;
    int berhasil;
    int i_waktu = 120;
    int i_poin = 0;
    int deteksi = 0;


    Sprite* resolusi;

    void random();
    void jika_benar(int x);
    void fungsi_bintang(int x);
    void getar();
    void khusus();

    bool onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event);
    void onTouchMoved(cocos2d::Touch* touch, cocos2d::Event* event);
    void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event);

    Point point_began;
    Point point_moved;
    Point point_ended;

    Rect b_1;
    Rect b_2;
    Rect b_3;
    Rect r_panel;

    bool deteksi_sentuh = false;
    bool b_berhasil = false;

    void untuk_manggil();
    void game_selesai();
    void muncul();
    void fungsi_waktu();

};

#endif // __HELLOWORLD_SCENE_H__
