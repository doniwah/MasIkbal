/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "abjad.h"
#include "indonesia.h"
#include "hijaiyah.h"
#include "coba.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* abjad::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = abjad::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}
const std::string name_huruf[] =
{
    "belajar/Mengenal_huruf/huruf_alphabet/a",
    "belajar/Mengenal_huruf/huruf_alphabet/b",
    "belajar/Mengenal_huruf/huruf_alphabet/c",
    "belajar/Mengenal_huruf/huruf_alphabet/d",
    "belajar/Mengenal_huruf/huruf_alphabet/e",
    "belajar/Mengenal_huruf/huruf_alphabet/f",
    "belajar/Mengenal_huruf/huruf_alphabet/g",
    "belajar/Mengenal_huruf/huruf_alphabet/h",
    "belajar/Mengenal_huruf/huruf_alphabet/i",
    "belajar/Mengenal_huruf/huruf_alphabet/j",
    "belajar/Mengenal_huruf/huruf_alphabet/k",
    "belajar/Mengenal_huruf/huruf_alphabet/l",
    "belajar/Mengenal_huruf/huruf_alphabet/m",
    "belajar/Mengenal_huruf/huruf_alphabet/n",
    "belajar/Mengenal_huruf/huruf_alphabet/o",
    "belajar/Mengenal_huruf/huruf_alphabet/p",
    "belajar/Mengenal_huruf/huruf_alphabet/q",
    "belajar/Mengenal_huruf/huruf_alphabet/r",
    "belajar/Mengenal_huruf/huruf_alphabet/s",
    "belajar/Mengenal_huruf/huruf_alphabet/t",
    "belajar/Mengenal_huruf/huruf_alphabet/u",
    "belajar/Mengenal_huruf/huruf_alphabet/v",
    "belajar/Mengenal_huruf/huruf_alphabet/w",
    "belajar/Mengenal_huruf/huruf_alphabet/x",
    "belajar/Mengenal_huruf/huruf_alphabet/y",
    "belajar/Mengenal_huruf/huruf_alphabet/z"
};

const std::string sound[] =
{
    "sound/alfabet/a",
    "sound/alfabet/b",
    "sound/alfabet/c",
    "sound/alfabet/d",
    "sound/alfabet/e",
    "sound/alfabet/f",
    "sound/alfabet/g",
    "sound/alfabet/h",
    "sound/alfabet/i",
    "sound/alfabet/j",
    "sound/alfabet/k",
    "sound/alfabet/l",
    "sound/alfabet/m",
    "sound/alfabet/n",
    "sound/alfabet/o",
    "sound/alfabet/p",
    "sound/alfabet/q",
    "sound/alfabet/r",
    "sound/alfabet/s",
    "sound/alfabet/t",
    "sound/alfabet/u",
    "sound/alfabet/v",
    "sound/alfabet/w",
    "sound/alfabet/x",
    "sound/alfabet/y",
    "sound/alfabet/z"
};
void abjad::ganti_huruf()
{
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    if (huruf_ke < 0)
    {
        huruf_ke = 25;
    }

    if (huruf_ke >= 26)
    {
        huruf_ke = 0;
    };

    object->setTexture(__String::createWithFormat("%s.png", name_huruf[huruf_ke].c_str())->getCString());
    object->runAction(Sequence::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2 + 30)),
        EaseBounceOut::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2))), nullptr));
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(__String::createWithFormat("%s.mp3", sound[huruf_ke].c_str())->getCString());
    if (tombol_auto_aktif == true)
    {
        huruf_ke++;
    }
}
// on "init" you need to initialize your instance
bool abjad::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("belajar/huruf_indonesia/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    panel = Sprite::create("belajar/huruf_indonesia/pannel.png");
    panel->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(panel);

    object = Sprite::create("belajar/Mengenal_huruf/huruf_alphabet/a.png");
    object->setScale(0.3);
    object->setPosition(Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2));
    object->runAction(Sequence::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2 + 30)),
        EaseBounceOut::create(MoveTo::create(0.5, Vec2(panel->getContentSize().width / 2, panel->getContentSize().height / 2))), nullptr));
    panel->addChild(object);

    b_next = Button::create("stage/b_next.png");
    b_next->setAnchorPoint(Point(0.5, 0.5));
    b_next->setPosition(Vec2(visibleSize.width / 2 + origin.x + 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_next);
    b_next->setZoomScale(-0.1);
    b_next->addClickEventListener([=](Ref* Sender) {
        huruf_ke++;
        ganti_huruf();
        });

    b_left = Button::create("stage/b_next.png");
    b_left->setAnchorPoint(Point(0.5, 0.5));
    b_left->setRotation(180);
    b_left->setPosition(Vec2(visibleSize.width / 2 + origin.x - 500, visibleSize.height / 2 + origin.y));
    this->addChild(b_left);
    b_left->setZoomScale(-0.1);
    b_left->addClickEventListener([=](Ref* Sender) {
        huruf_ke--;
        ganti_huruf();
        });

    auto b_inggris = Button::create("stage/b_inggris_new.png");
    b_inggris->setAnchorPoint(Point(1, 1));
    b_inggris->setScale(1.45);
    b_inggris->setPosition(Vec2(visibleSize.width + origin.x - 250, visibleSize.height + origin.y - 20));
    this->addChild(b_inggris);
    b_inggris->setZoomScale(-0.1);
    b_inggris->addClickEventListener([=](Ref* Sender) {
        /*auto gr_scene = hijaiyah::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));*/
        });

    auto b_arab = Button::create("stage/B_arab_new_off.png");
    b_arab->setAnchorPoint(Point(1, 1));
    b_arab->setScale(1.45);
    b_arab->setPosition(Vec2(visibleSize.width + origin.x - 350, visibleSize.height + origin.y - 20));
    this->addChild(b_arab);
    b_arab->setZoomScale(-0.1);
    b_arab->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = hijaiyah::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    auto b_indo = Button::create("stage/B_indo_new_off.png");
    b_indo->setAnchorPoint(Point(1, 1));
    b_indo->setScale(1.45);
    b_indo->setPosition(Vec2(visibleSize.width + origin.x - 460, visibleSize.height + origin.y - 20));
    this->addChild(b_indo);
    b_indo->setZoomScale(-0.1);
    b_indo->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = indonesia::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });



    b_auto = Button::create("belajar/huruf_indonesia/b_auto_off.png");
    b_auto->setAnchorPoint(Point(1, 1));
    b_auto->setPosition(Vec2(visibleSize.width + origin.x - 20, visibleSize.height + origin.y - 35));
    this->addChild(b_auto);
    b_auto->setZoomScale(-0.1);
    b_auto->addClickEventListener([=](Ref* Sender) {
        if (tombol_auto_aktif == false) {
            tombol_auto_aktif = true;
            b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_on.png");
            this->runAction(RepeatForever::create(Sequence::create(
                CallFunc::create(CC_CALLBACK_0(abjad::ganti_huruf, this)), DelayTime::create(1.5), nullptr)));
        }
        else if (tombol_auto_aktif == true)
        {
            tombol_auto_aktif = false;
            b_auto->loadTextureNormal("belajar/huruf_indonesia/b_auto_off.png");
            this->stopAllActions();
        }
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/alfabet/a.mp3");

    b_back = Button::create("belajar/huruf_indonesia/B_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });
    
    return true;
}


void abjad::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = coba::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
