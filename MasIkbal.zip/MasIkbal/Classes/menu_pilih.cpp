/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

#include "menu_pilih.h"
#include "homeplay.h"
#include "pilihan_belajar.h"
#include "pilihan_bermain.h"
#include "coba.h"
#include "coba_2.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocos2d::network;
using namespace ui;


Scene* menu_pilih::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    // 'layer' is an autorelease object
    auto layer = menu_pilih::create();
    // add layer as a child to scene
    scene->addChild(layer);

    return  scene;
}

// Print useful error message instead of segfaulting when files are not there.


// on "init" you need to initialize your instance
bool menu_pilih::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    bg = Sprite::create("stage/menu_pilihan/bg.png");
    bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
    this->addChild(bg);

    b_belajar = Button::create("stage/menu_pilihan/b_belajar.png");
    b_belajar->setAnchorPoint(Point(0.5, 0.5));
    b_belajar->setScale(1.35);
    b_belajar->setPosition(Vec2(visibleSize.width / 2 + origin.x - 300, visibleSize.height / 2 + origin.y));
    this->addChild(b_belajar);
    b_belajar->setZoomScale(-0.1);
    b_belajar->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba::createScene();
        Director::getInstance()->replaceScene(TransitionProgressHorizontal::create(0.5, gr_scene));
        });

    b_bermain = Button::create("stage/menu_pilihan/b_bermain.png");
    b_bermain->setAnchorPoint(Point(0.5, 0.5));
    b_bermain->setScale(1.35);
    b_bermain->setPosition(Vec2(visibleSize.width / 2 + origin.x + 300, visibleSize.height / 2 + origin.y));
    this->addChild(b_bermain);
    b_bermain->setZoomScale(-0.1);
    b_bermain->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = coba_2::createScene();
        Director::getInstance()->replaceScene(TransitionProgressHorizontal::create(0.5, gr_scene));
        });

    b_back = Button::create("stage/menu_pilihan/b_back.png");
    b_back->setAnchorPoint(Point(0, 1));
    b_back->setPosition(Vec2(origin.x + 20, visibleSize.height + origin.y - 20));
    this->addChild(b_back);
    b_back->setZoomScale(-0.1);
    b_back->addClickEventListener([=](Ref* Sender) {
        CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/touch.mp3");
        auto gr_scene = homeplay::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
        });

    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("sound/intrumen/yuk pilih.mp3");


    return true;
}


void menu_pilih::menuCloseCallback(Ref* pSender)
{
    auto gr_scene = homeplay::createScene();
    Director::getInstance()->replaceScene(TransitionFade::create(0.5, gr_scene, Color3B::WHITE));
}
